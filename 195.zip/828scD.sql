-----------------------------------
-- Appendix D - Ownership Chains --
-----------------------------------

-- Listing D-1: Using Dynamic Execution
DECLARE @cmd AS varchar(100)
SET @cmd = 'DELETE FROM T1'
EXECUTE (@cmd)
