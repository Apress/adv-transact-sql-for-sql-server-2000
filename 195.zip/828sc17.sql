----------------------------------
-- Chapter 17 - Tips and Tricks --
----------------------------------

-- Listing 17-1: Query Using MIN() and MAX() on Same Column
SELECT
  MIN (OrderDate),
  MAX (OrderDate)
FROM
  Orders

-- Listing 17-2: Using a Nested Subquery to Use an Index
SELECT
  MIN (OrderDate),
  (SELECT MAX (OrderDate) FROM Orders)
FROM
  Orders

-- Listing 17-3: NULLs Sort First
SELECT
  *
FROM
  Customers
ORDER BY
  Region

-- Listing 17-4: NULLs Sort Last
SELECT
  *
FROM
  Customers
ORDER BY
  CASE
    WHEN Region IS NULL THEN 1
    ELSE 0
  END,
  Region

-- Listing 17-5: Adding a Computed Column and an Index on it to the Customers Table
ALTER TABLE Customers
  ADD RegionNullOrder AS
    CASE
      WHEN region IS NULL THEN 1
      ELSE 0
    END
GO

CREATE INDEX idx_nci_RegionNullOrder_Region ON
  Customers (RegionNullOrder, Region)
GO

-- Listing 17-6: NULLs Sort Last and an Index Is Used
SET SHOWPLAN_TEXT ON
GO

SELECT
  *
FROM
  Customers
ORDER BY
  RegionNullOrder,
  Region
GO

-- Listing 17-7: SHOWPLAN�s Output, the Index on the Computed Column is Used
|--Bookmark Lookup(BOOKMARK:([Bmk1000]),
     OBJECT:([Northwind].[dbo].[Customers]))
   |--Index Scan(OBJECT:(
     [Northwind].[dbo].[Customers].[idx_nci_RegionNullOrder_Region]),
       ORDERED FORWARD)

-- Listing 17-8: Passing the ORDER BY Column as a Parameter, Using a Column Number, First Try
CREATE PROC GetAuthors1
  @colnum AS int
AS

SELECT
  *
FROM
  authors
ORDER BY
  CASE @colnum
    WHEN 1 THEN au_id
    WHEN 2 THEN au_lname
    WHEN 3 THEN au_fname
    WHEN 4 THEN phone
    WHEN 5 THEN address
    WHEN 6 THEN city
    WHEN 7 THEN state
    WHEN 8 THEN zip
    WHEN 9 THEN contract
    ELSE NULL
  END
GO

-- Listing 17-9: Error when Trying to Invoke the GetAuthors1 Stored Procedure
EXEC GetAuthors1
  @colnum = 1

Server: Msg 245, Level 16, State 1, Procedure GetAuthors1, Line 5
Syntax error converting the varchar value '172-32-1176'
to a column of data type bit.

-- Listing 17-10: Passing the ORDER BY Column as a Parameter, Using a Column Number, Second Try
ALTER PROC GetAuthors1
  @colnum AS int
AS

SELECT
  *
FROM
  authors
ORDER BY
  CASE @colnum
    WHEN 1 THEN au_id
    WHEN 2 THEN au_lname
    WHEN 3 THEN au_fname
    WHEN 4 THEN phone
    WHEN 5 THEN address
    WHEN 6 THEN city
    WHEN 7 THEN state
    WHEN 8 THEN zip
    WHEN 9 THEN CAST(contract AS CHAR(1))
    ELSE NULL
  END
GO

-- Listing 17-11: Prefixing a Numeric Value with Zeros
RIGHT (REPLICATE ('0', 10) + CAST (qty AS varchar (10)), 10)

-- Listing 17-12: Passing the ORDER BY Column as a Parameter, Using Dynamic Execution
CREATE PROC GetAuthors2
  @colnum AS int
AS

DECLARE
  @cmd AS varchar (8000)

SET @cmd =
  'SELECT *'     + CHAR (13) + CHAR(10) +
  'FROM authors' + CHAR (13) + CHAR(10) +
  'ORDER BY '    + CAST (@colnum AS varchar (4))

EXEC(@cmd)
GO

-- Listing 17-13: Passing the ORDER BY Column as a Parameter, Using a Column Name
CREATE PROC GetAuthors3
  @colname AS sysname
AS

SELECT
  *
FROM
  authors
ORDER BY
  CASE @colname
    WHEN 'au_id' THEN au_id
    WHEN 'au_lname' THEN au_lname
    WHEN ...
    WHEN 'contract' THEN CAST (contract AS CHAR (1))
    ELSE NULL
  END
GO

-- Listing 17-14: A View to Build a String and Handle NULL�s
CREATE VIEW MailingList
AS
SELECT
  CustomerID,
  CompanyName + CHAR (13) + CHAR (10) +
  Address     + CHAR (13) + CHAR (10) +
  City        + CHAR (13) + CHAR (10) +
  CASE WHEN Region IS NOT NULL THEN Region + CHAR (13) + CHAR (10)
       ELSE ''
  END +  Country AS ContactAddress
FROM
  Customers

-- Listing 17-15: Creation Script for Stored Procedure AuthorsInState
USE pubs
GO

CREATE PROC AuthorsInState
  @state char(2)
AS

SELECT
  * 
FROM
  authors
WHERE
  state = @state
GO

-- Listing 17-16: Schema Creation Script for the #TmpAuthors Table
CREATE TABLE #TmpAuthors
(
  au_id    varchar(11) NOT NULL,
  au_lname varchar(40) NOT NULL,
  au_fname varchar(20) NOT NULL,
  phone    char(12)    NOT NULL,
  address  varchar(40) NULL,
  city     varchar(20) NULL,
  state    char(2)     NULL,
  zip      char(5)     NULL,
  contract bit         NOT NULL
)

-- Listing 17-17: Using the INSERT EXEC Statement
INSERT INTO #TmpAuthors
  EXEC AuthorsInState 'CA'

-- Listing 17-18: Embedding the Result of the INSERT EXEC Statement in a SELECT Statement
SELECT
  *
FROM
  #TmpAuthors
GO

-- Listing 17-19: Embedding the Result of the INSERT EXEC Statement in a SELECT INTO Statement
SELECT
  *
INTO
  #TmpAuthors2
FROM
  #TmpAuthors  
GO

-- Listing 17-20: Embedding the Result of the OPENROWSET Function in a SELECT Statement
SELECT
  T1.*
FROM
  OPENROWSET('SQLOLEDB','<server>';'<user>';'<pass>',
             'EXEC pubs..AuthorsInState ''CA''') AS T1

-- Listing 17-21: Embedding the Result of the OPENROWSET Function in a SELECT INTO Statement
SELECT
  *
INTO
  #TmpAuthors
FROM
  OPENROWSET('SQLOLEDB', <server>';'<user>';'<pass>,
             'EXEC pubs..AuthorsInState ''CA''') AS T1

-- Listing 17-22: Turning On the 'Data Access' Server Option
EXEC sp_serveroption '<server>', 'Data Access', 'true'

-- Listing 17-23: Embedding the Result of the OPENQUERY Function in a SELECT Statement
SELECT
  T1.*
FROM
  OPENQUERY([<server>],
            'EXEC pubs..AuthorsInState ''CA''') AS T1

-- Listing 17-24: Embedding the Result of the OPENQUERY Function in a SELECT INTO Statement
SELECT
  *
INTO
  #TmpAuthors
FROM OPENQUERY([<server>],
               'EXEC pubs..AuthorsInState ''CA''')

-- Listing 17-25: Creating a View on a Stored Procedure Call
CREATE VIEW StoredProcWrapper
AS
SELECT
  *
FROM
    OPENROWSET
    (
      'SQLOLEDB',
      'SERVER=.;Trusted_Connection=yes',
      'SET FMTONLY OFF EXEC sp_who2'
    )

-- Listing 17-26: Using Remote Tables with the Four-Part Naming Convention
SELECT
  C.CustomerID,
  SUM (OD.Quantity) AS Quantity
FROM
    Customers                            C
  JOIN
    Remote.Northwind.dbo.Orders          O  ON O.CustomerID = C.CustomerID
  JOIN
    Remote.Northwind.dbo.[Order Details] OD ON OD.OrderID   = O.OrderID
WHERE
    C.Country    = 'Canada'
  AND
    OD.ProductID = 17
GROUP BY
  C.CustomerID

-- Listing 17-27: Using OPENQUERY() to Do the Majority of the Work on the Remote Server
SELECT
  C.CustomerID,
  O.Quantity
FROM
    Customers                   C
  JOIN
    OPENQUERY
    (
      Remote,
      'SELECT
         O.CustomerID,
         SUM (OD.Quantity) AS Quantity
       FROM
           Northwind..Orders          O
         JOIN
           Northwind..[Order Details] OD ON OD.OrderID = O.OrderID
       WHERE
           OD.ProductID = 17
       GROUP BY
         O.CustomerID'
    )                           O ON O.CustomerID = C.CustomerID
WHERE
    C.Country = 'Canada'

-- Listing 17-28: Running the Query on the Remote Server
SELECT
  C.CustomerID,
  SUM (OD.Quantity) AS Quantity
FROM
    Local.Northwind.dbo.Customers C
  JOIN
    Orders                        O  ON O.CustomerID = C.CustomerID
  JOIN
    [Order Details]               OD ON OD.OrderID   = O.OrderID
WHERE
    C.Country    = 'Canada'
  AND
    OD.ProductID = 17
GROUP BY
  C.CustomerID

-- Listing 17-29: Using CASE in a JOIN
USE RiskNet

-- GET INSTITUTION CHILDREN
SELECT
  v.InstitutionID, 
  v.Name, 
  v.HierarchyLevelID, 
  v.HierarchyLevelName, 
  v.Disabled, 
  v.CompanyID, 
  v.ParentInstitutionID
FROM
    vInstitution v 
  JOIN
    Security.dbo.AccountInstSecurityRole s 
  ON s.InstitutionID = 
     CASE -- If count is 1 or less, then is unrestricted,
          -- otherwise, different join
       WHEN (SELECT
               COUNT(*) 
             FROM
                 vInstitution v 
               JOIN
                 Security.dbo.AccountInstSecurityRole s 
               ON (v.InstitutionID = s.InstitutionID) 
             WHERE
                 v.ParentInstitutionID = @ProviderInstitution
               AND
                 s.AccountID = @LoginID
               AND
                 v.HierarchyLevelID > 1
               AND
                 v.Disabled = 0 
            ) <= 1
         THEN v.ParentInstitutionID
       ELSE v.InstitutionID
     END
WHERE
    v.ParentInstitutionID = @ProviderInstitution
  AND
    s.AccountID = @LoginID
  AND
    v.HierarchyLevelID > 1
  AND
    v.Disabled = 0 
ORDER BY
   v.Name

-- Listing 17-30: Tables and Sample Data for the Phone List
CREATE TABLE Customers
(
  CustomerNo int          NOT NULL
                          PRIMARY KEY,
  LastName   varchar (10) NOT NULL,
  FirstName  varchar (10) NOT NULL
)
GO

INSERT Customers VALUES (1, 'Smith', 'John')
INSERT Customers VALUES (2, 'Jones', 'Jim')
INSERT Customers VALUES (3, 'Stockwell', 'Mary')
INSERT Customers VALUES (4, 'Harris', 'Mike')
GO

CREATE TABLE Telephones
(
  CustomerNo  int      NOT NULL
                       REFERENCES Customers (CustomerNo),
  TelType     char (1) NOT NULL
                       CHECK (TelType IN ('H', 'B')),
  TelephoneNo int      NOT NULL,
                       PRIMARY KEY (CustomerNo, TelType)
)
GO

INSERT Telephones VALUES (1, 'H', 5550000)
INSERT Telephones VALUES (1, 'B', 5550001)
INSERT Telephones VALUES (2, 'H', 5550002)
INSERT Telephones VALUES (3, 'H', 5550003)
INSERT Telephones VALUES (3, 'B', 5550004)
GO

-- Listing 17-31: Generating the Phone List
SELECT
  C.CustomerNo,
  C.LastName,
  C.FirstName,
  COALESCE (TB.TelephoneNo, TH.TelephoneNo) AS TelephoneNo,
  COALESCE (TB.TelType, TH.TelType)         AS TelType
FROM
    Customers  C
  LEFT JOIN
    Telephones TB ON  C.CustomerNo = TB.CustomerNo
                  AND TB.TelType   = 'B'
  LEFT JOIN
    Telephones TH ON  C.CustomerNo = TH.CustomerNo
                  AND TH.TelType   = 'H'
WHERE
    COALESCE (TB.TelephoneNo, TH.TelephoneNo) IS NOT NULL

-- Listing 17-32: Authors with the Last Name �green�, Case-Insensitive Search
SELECT
  *
FROM
  Authors
WHERE
  au_lname = 'green'

-- Listing 17-33: Authors with the Last Name �green�, Case-Sensitive Search
SELECT
  *
FROM
  Authors
WHERE
  CAST (au_lname AS varbinary (40)) = CAST ('green' AS varbinary(40))

-- Listing 17-34: Authors with the Last Name �green�, Case-Sensitive Search Using an Index 
SELECT
  *
FROM
  Authors
WHERE
    au_lname = 'green'
  AND
    CAST (au_lname AS varbinary (40)) = CAST ('green' AS varbinary (40))

-- Listing 17-37: Schema Creation Script for the T1 Table
CREATE TABLE T1
(
  pk_col    int NOT NULL PRIMARY KEY CHECK (pk_col > 0),
  ident_col int NOT NULL IDENTITY (1,1)
)

-- Listing 17-38: Unsuccessful Attempt to Trap both Primary Key and CHECK Constraint Violations 
INSERT INTO T1 VALUES(0) -- violate the check constraint

IF @@error = 2627
  PRINT 'PRIMARY KEY constraint violation'
ELSE IF @@error = 547
  PRINT 'CHECK constraint violation'
GO

-- Listing 17-39: Successful Attempt to Trap both Primary Key and CHECK Constraint Violations 
DECLARE
  @myerror    AS int

INSERT INTO T1 VALUES(0) -- violate the check constraint

SET @myerror = @@error

IF @myerror = 2627
  PRINT 'PRIMARY KEY constraint violation'
ELSE IF @myerror = 547
  PRINT 'CHECK constraint violation'
GO

-- Listing 17-40: Unsuccessful Attempt to Capture @@IDENTITY, @@ROWCOUNT, and @@ERROR 
DECLARE
  @myerror    AS int,
  @myrowcount AS int,
  @myidentity AS int

INSERT INTO T1 VALUES(10) -- used to make the next statement cause a PK violation
INSERT INTO T1 VALUES(10) -- PK violation

SET @myidentity = @@IDENTITY 
SET @myrowcount = @@ROWCOUNT
SET @myerror    = @@ERROR

PRINT '@myidentity: ' + CAST(@myidentity AS varchar)
PRINT '@myrowcount: ' + CAST(@myrowcount AS varchar)
PRINT '@myerror   : ' + CAST(@myerror AS varchar)
GO

-- Listing 17-41: Output of Unsuccessful Attempt to Capture @@IDENTITY, @@ROWCOUNT, and @@ERROR 
@myidentity: 2
@myrowcount: 1
@myerror   : 0

-- Listing 17-42: Successful Attempt to Capture @@IDENTITY, @@ROWCOUNT, and @@ERROR 
DECLARE
  @myerror    AS int,
  @myrowcount AS int,
  @myidentity AS int

INSERT INTO T1 VALUES(10) -- PK violation

SELECT @myidentity = @@IDENTITY, 
       @myrowcount = @@ROWCOUNT,
       @myerror    = @@ERROR

PRINT '@myidentity: ' + CAST(@myidentity AS varchar)
PRINT '@myrowcount: ' + CAST(@myrowcount AS varchar)
PRINT '@myerror   : ' + CAST(@myerror AS varchar)
GO

-- Listing 17-43: Output of Successful Attempt to Capture @@IDENTITY, @@ROWCOUNT, and @@ERROR 
@myidentity: 2
@myrowcount: 0
@myerror   : 2627

-- Listing 17-44: Excerpt from sp_addlogin
else if @encryptopt = 'skip_encryption_old'
begin
    select @xstatus = @xstatus | 0x800,    -- old-style encryption
    @passwd = convert(sysname,convert(varbinary(30),
                        convert(varchar(30), @passwd)))

-- Listing 17-45: Excerpt from sp_password
PWDCOMPARE(@old, password,
           (CASE WHEN xstatus&2048 = 2048 THEN 1 ELSE 0 END))

-- Listing 17-46: Creation Script for the CompareSQL65EncryptedString Stored Procedure
CREATE PROCEDURE CompareSQL65EncryptedString
(
  @SSN char(9),
  @pin  char(4),
  @return int OUTPUT)
AS
IF EXISTS 
(
SELECT
  *
FROM MyTable (NOLOCK)
WHERE
    SSN = @ssn
  AND
    PWDCOMPARE(@pin,
      CONVERT(sysname,
        CONVERT(varbinary(30),CONVERT(varchar(30),pin))),
      1) = 1
)
  SELECT @return = 1
ELSE
  SELECT @return = 0
GO

-- Listing 17-47: Using the PWDENCRYPT() and PWDCOMPARE() Functions
DECLARE
  @ClearPIN     varchar (255),
  @EncryptedPin varbinary(255)

SELECT
  @ClearPin = 'test'

SELECT
  @EncryptedPin = CONVERT (varbinary(255), PWDENCRYPT (@ClearPin))

SELECT
  PWDCOMPARE (@ClearPin, @EncryptedPin, 0)

-- Listing 17-48: Creating a Sorted View
CREATE VIEW SortedView
AS
SELECT TOP 100 PERCENT
  C.CompanyName,
  O.OrderDate
FROM
    Customers C
  JOIN
    Orders    O ON O.CustomerID = C.CustomerID
ORDER BY
  O.OrderDate
GO

-- Listing 17-49: Getting Rows m to n in One Query 
SELECT
  *
FROM
  Authors AS A1
WHERE
  (
    SELECT
      COUNT(*)
    FROM
      Authors AS A2
    WHERE
      A2.au_id <= A1.au_id
  ) BETWEEN 6 AND 10
ORDER BY
  au_id

-- Listing 17-50: Placing the Authors in a Temporary Table Along with Their Ordinal Positions 
SELECT
  IDENTITY (int, 1, 1) AS rownum,
  *
INTO
  #TmpAuthors
FROM
  Authors
ORDER BY
  au_id

-- Listing 17-51: Retrieving Authors Six to Ten from the Temporary Table
SELECT
  *
FROM
  #TmpAuthors
WHERE
  rownum BETWEEN 6 AND 10

-- Listing 17-52: Retrieving Authors Six through Ten
SELECT
  *
FROM
(
  SELECT TOP 5
    *
  FROM
  (
    SELECT TOP 10
      *
    FROM
      Authors
    ORDER BY
      au_id ASC
  ) X
  ORDER BY
    au_id DESC
) Y
ORDER BY
  au_id ASC

-- Listing 17-53: Getting the First Three Orders for Each US Customer in One Query 
SELECT
  *
FROM
  Orders AS O1
WHERE
    ShipCountry = 'USA'
  AND
    (
      SELECT
        COUNT(*)
      FROM
        Orders AS O2
      WHERE
          ShipCountry = 'USA'
        AND
          O2.CustomerID = O1.CustomerID
        AND
          O2.OrderID <= O1.OrderID
    ) <= 3
ORDER BY
  CustomerID,
  OrderID

-- Listing 17-54: Getting the First Three Orders for Each Customer, for a Known List of Customers 
SELECT
  *
FROM
  (
    SELECT TOP 3
      *
    FROM
      Orders
    WHERE
        ShipCountry = 'USA'
      AND
        CustomerID = <first_cust>
    ORDER BY
      CustomerID,
      OrderID
  ) AS T1

UNION ALL

SELECT
  *
FROM
  (
    SELECT TOP 3
      *
    FROM
      Customers
    WHERE
        ShipCountry = 'USA'
      AND
        CustomerID = <second_cust>
    ORDER BY
      CustomerID,
      OrderID
  ) AS T2

UNION ALL
...
UNION ALL

SELECT
  *
FROM
  (
    SELECT TOP 3
      *
    FROM
      Customers
    WHERE
        ShipCountry = 'USA'
      AND
        CustomerID = <last_cust>
    ORDER BY
      CustomerID,
      OrderID
  ) AS Tn

-- Listing 17-55: Getting the First Three Orders for Each Customer, for an Unknown List of Customers 
DECLARE
  @lastindid AS char (5),
  @i         AS int,
  @cmd       AS varchar (8000)

SET @cmd = ''
SET @i = 1

SELECT
  @lastindid = MIN (CustomerID) 
FROM
  Orders
WHERE
  ShipCountry = 'USA'

WHILE @lastindid IS NOT NULL
BEGIN
  SET @cmd = @cmd +
  'SELECT * FROM ' +
    '(SELECT TOP 3 * FROM Orders ' +
     'WHERE ShipCountry = ''USA'' AND CustomerID = ''' + @lastindid + ''' ' + 
     'ORDER BY CustomerID,OrderID) AS T' +
     CAST(@i AS varchar) + CHAR (13) + CHAR(10)

  SELECT
    @lastindid = MIN (CustomerID),
    @i         = @i + 1
  FROM
    Orders
  WHERE
      ShipCountry = 'USA'
    AND
      CustomerID > @lastindid

  IF @lastindid IS NOT NULL
    SET @cmd = @cmd + 'UNION ALL' + CHAR (13) + CHAR(10)

END

PRINT @cmd -- just for debug
EXEC (@cmd)

-- Listing 17-56: Getting the First Three Orders for Each Customer, for an Unknown List of Customers, Using a Correlated Subquery
SELECT
  O1.*
FROM
  Orders O1
WHERE
    O1.ShipCountry = 'USA'
  AND
    O1.OrderID IN
(
  SELECT TOP 3
    O2.OrderID
  FROM
    Orders    O2
  WHERE
      O2.ShipCountry = 'USA'
    AND
      O2.CustomerID  = O1.CustomerID
  ORDER BY
    O2.OrderID
)
ORDER BY
  O1.CustomerID,
  O1.OrderID

-- Listing 17-57: Determining the Country That Keeps Each Employee the Busiest
SELECT
  O1.EmployeeID,
  O1.ShipCountry,
  COUNT (*) AS Orders
FROM
    Orders O1
GROUP BY
    O1.EmployeeID,
    O1.ShipCountry
  HAVING
    COUNT (*) =
(
  SELECT TOP 1
    COUNT (*) AS Orders
  FROM
    Orders O2
  WHERE
    O2.EmployeeID = O1.EmployeeID
  GROUP BY
    O2.EmployeeID,
    O2.ShipCountry
  ORDER BY
    Orders DESC
)
ORDER BY
  O1.EmployeeID

-- Listing 17-58: Employee Who Serves Each Country the Most, First Try
SELECT
  O1.ShipCountry,
  O1.EmployeeID,
  COUNT (*) AS Orders
FROM
    Orders O1
GROUP BY
    O1.ShipCountry,
    O1.EmployeeID
  HAVING
    COUNT (*) =
(
  SELECT TOP 1
    COUNT (*) AS Orders
  FROM
    Orders O2
  WHERE
    O2.ShipCountry = O1.ShipCountry
  GROUP BY
    O2.ShipCountry,
    O2.EmployeeID
  ORDER BY
    Orders DESC
)
ORDER BY
  O1.ShipCountry

-- Listing 17-59: Employee Who Serves Each Country the Most, Second Try
SELECT
  O1.ShipCountry,
  O1.EmployeeID,
  COUNT (*) AS Orders
INTO
  #Temp
FROM
    Orders O1
GROUP BY
    O1.ShipCountry,
    O1.EmployeeID

SELECT
  T1.*
FROM
  #Temp T1
WHERE
  T1.Orders =
(
  SELECT
    MAX (T2.Orders)
  FROM
    #Temp T2
  WHERE
      T2.ShipCountry = T1.ShipCountry
)
ORDER BY
  T1.ShipCountry

-- Listing 17-60: Employee Who Serves Each Country the Most, Third Try
SELECT
  T1.*
FROM
  (SELECT
     O1.ShipCountry,
     O1.EmployeeID,
     COUNT (*) AS Orders
   FROM
     Orders O1
   GROUP BY
     O1.ShipCountry,
     O1.EmployeeID) T1
WHERE
  T1.Orders =
(
  SELECT
    MAX (T2.Orders)
  FROM
    (SELECT
       O1.ShipCountry,
       O1.EmployeeID,
       COUNT (*) AS Orders
     FROM
       Orders O1
     GROUP BY
       O1.ShipCountry,
       O1.EmployeeID) T2
  WHERE
      T2.ShipCountry = T1.ShipCountry
)
ORDER BY
  T1.ShipCountry
