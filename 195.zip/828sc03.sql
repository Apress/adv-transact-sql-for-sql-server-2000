-----------------------------------
-- Chapter 3 - Populating Tables --
-----------------------------------

-- Listing 3-1: Syntax for the INSERT Statement
INSERT [INTO]
 { 
  table_name WITH ( <table_hint_limited> [...n])
  | view_name
  | rowset_function_limited
 }

 { [(column_list)]
  { VALUES ( { DEFAULT
      | NULL
      | expression
      }[,...n]
   )
  | derived_table
  | execute_statement
  }
 }
 | DEFAULT VALUES

<table_hint_limited> ::=
 { INDEX(index_val [,...n])
  | FASTFIRSTROW
  | HOLDLOCK
  | PAGLOCK
  | READCOMMITTED
  | REPEATABLEREAD
  | ROWLOCK
  | SERIALIZABLE
  | TABLOCK
  | TABLOCKX
  | UPDLOCK
 }

-- Listing 3-2: Example of an INSERT DEFAULT VALUES Statement
CREATE TABLE MyTable
(
  ID           int          NOT NULL
                            IDENTITY (1, 1),
  EntryDate    datetime     NOT NULL
                            DEFAULT (GETDATE ()),
  Description  varchar (20) NULL
)
GO

INSERT MyTable DEFAULT VALUES

-- Listing 3-3: Example of INSERT VALUES
INSERT Mytable
(
  ID,
  EntryDate,
  Description
)
VALUES
(
  43217,
  '2000/05/09',
  'Boeing 747'
)

-- Listing 3-4: Example of INSERT VALUES without a Column List
INSERT Mytable
VALUES
(
  43217,
  '2000/05/09',
  'Boeing 747'
)

-- Listing 3-5: Inserting Multiple Rows with a Single INSERT VALUES Statement
INSERT MyTable
VALUES
(
  (43217, '2000/05/31', 'Boeing 747'),
  (90210, '1941/12/07', 'Curtiss P-40'),
  (41268, '1970/01/24', 'Concorde')
)

-- Listing 3-6: Example of an INSERT SELECT Statement
INSERT MyTable
(
  ID,
  EntryDate,
  Description
)
SELECT
  ID,
  GETDATE (),
  Description
FROM
  HisTable
WHERE
  ID BETWEEN 4500 AND 5000
GO

-- Listing 3-7: Inserting Data into a Table with Defaults
CREATE TABLE MyTable
(
  RowNum  int      NOT NULL
                   PRIMARY KEY,
  Txt     char (5) NOT NULL
                   DEFAULT 'abc',
  TheDate datetime NOT NULL
                   DEFAULT getdate()
)
GO

INSERT MyTable (RowNum) VALUES (1)
INSERT MyTable (RowNum, Txt) VALUES (3, 'xyz')
INSERT MyTable (RowNum, Txt, TheDate) VALUES (5, 'ghi', '20001001')
INSERT MyTable (RowNum, Txt, TheDate) VALUES (7, DEFAULT, '20001101')
GO

INSERT MyTable
(
  RowNum
)
SELECT
  RowNum * 2
FROM
  MyTable
GO

-- Listing 3-8: Example of an INSERT EXEC Statement
CREATE TABLE MyTable
(
  spid     smallint,
  ecid     smallint,
  status   nchar (30),
  loginame nchar (128),
  hostname nchar (128),
  blk      char (5),
  dbname   nchar (128),
  cmd      nchar (16)
)
GO

INSERT MyTable
(
  spid,
  ecid,
  status,
  loginame,
  hostname,
  blk,
  dbname,
  cmd
)
EXEC sp_who

-- Listing 3-9: Example of an INSERT EXEC Statement on a Remote Server
INSERT MyTable
(
  spid,
  ecid,
  status,
  loginame,
  hostname,
  blk,
  dbname,
  cmd
)
EXEC Toronto.master..sp_who

-- Listing 3-10: Example of a Remote INSERT
INSERT Hadera.NW2.dbo.Orders
SELECT
  *
FROM
  Orders

-- Listing 3-11: Partial Syntax for the SELECT INTO Statement
SELECT
  <column _list>
INTO
  <destination_table>
FROM
  <table_list>
WHERE
  <filter_conditions>

-- Listing 3-12: Using SELECT INTO to Create an Empty Table
SELECT
  OrderID,
  ProductID,
  Quantity
INTO
  OrderDetails
FROM
  [Order Details]
WHERE
  1 = 0

-- Listing 3-13: Creating a Nullable NULLable Column Using SELECT INTO
SELECT
  ItemID,
  ItemType,
  CAST (NULL AS datetime) AS DateSold
INTO
  NewInventory
FROM
  Inventory
WHERE
  ItemID >= 11000

-- Listing 3-14: Syntax for the BULK INSERT Statement
BULK INSERT [['database_name'.]['owner'].]{'table_name' FROM data_file} 
[WITH 
(
[ BATCHSIZE [= batch_size]]
[[,] CHECK_CONSTRAINTS]
[[,] CODEPAGE [= 'ACP' | 'OEM' | 'RAW' | 'code_page']]
[[,] DATAFILETYPE [=
{'char' | 'native'| 'widechar' | 'widenative'}]]
[[,] FIELDTERMINATOR [= 'field_terminator']]
[[,] FIRSTROW [= first_row]]
[[,] FIRETRIGGERS]
[[,] FORMATFILE [= 'format_file_path']]
[[,] KEEPIDENTITY]
[[,] KEEPNULLS]
[[,] KILOBYTES_PER_BATCH [= kilobytes_per_batch]]
[[,] LASTROW [= last_row]]
[[,] MAXERRORS [= max_errors]]
[[,] ORDER ({column [ASC | DESC]} [,...n])]
[[,] ROWS_PER_BATCH [= rows_per_batch]]
[[,] ROWTERMINATOR [= 'row_terminator']]
[[,] TABLOCK]
)
]

-- Listing 3-15: Using BULK INSERT to Load a Table
CREATE TABLE AircraftTypes
(
  TypeID         int            NOT NULL
                                PRIMARY KEY,
  ManufacturerID int            NOT NULL
                                REFERENCES Manufacturer (ManufacturerID),
  TypeName       char (20)      NOT NULL,
  GrossWeight    numeric (10,1) NOT NULL
)
GO

BULK INSERT AircraftTypes
 FROM 'C:\Temp\AircraftTypes.txt'
 WITH
  (CHECK_CONSTRAINTS)
GO

-- Listing 3-16: Denormalized Legacy Table
CREATE TABLE Legacy
(
  CustomerID   int          NOT NULL
                            PRIMARY KEY,
  CustomerName varchar (30) NOT NULL,
  HomePhone    char (10)    NULL,
  WorkPhone    char (10)    NULL,
  CellPhone    char (10)    NULL,
  FaxPhone     char (10)    NULL
)

-- Listing 3-17: Normalized Tables
CREATE TABLE Customers
(
 CustomerID  int           NOT NULL
                           PRIMARY KEY,
 CustomerName varchar (30) NOT NULL,
)
GO

CREATE TABLE Phones
(
  CustomerID int       NOT NULL
                       REFERENCES Customers (CustomerID),
  Type       char (1)  NOT NULL
                       CHECK (Type IN ('H', 'W', 'C', 'F')),
  Phone      char (10) NOT NULL,
                       PRIMARY KEY (CustomerID, Type)
)

-- Listing 3-18: Populating the Customers Table
INSERT Customers
(
  CustomerID,
  CustomerName
)
SELECT
  CustomerID,
  CustomerName
FROM
  Legacy

-- Listing 3-19: Populating the Phones Table
INSERT Phones
(
  CustomerID,
  Type,
  Phone
)
SELECT
  CustomerID,
  'H',
  HomePhone
FROM
  Legacy
WHERE
  HomePhone IS NOT NULL
GO

INSERT Phones
(
  CustomerID,
  Type,
  Phone
)
SELECT
  CustomerID,
  'W',
  WorkPhone
FROM
  Legacy
WHERE
  WorkPhone IS NOT NULL
GO

INSERT Phones
(
  CustomerID,
  Type,
  Phone
)
SELECT
  CustomerID,
  'C',
  CellPhone
FROM
  Legacy
WHERE
  CellPhone IS NOT NULL
GO

INSERT Phones
(
  CustomerID,
  Type,
  Phone
)
SELECT
  CustomerID,
  'F',
  FaxPhone
FROM
  Legacy
WHERE
  FaxPhone IS NOT NULL
GO

-- Listing 3-20: Populating the Phones Table with a UNION ALL
INSERT Phones
(
  CustomerID,
  Type,
  Phone
)
SELECT
  CustomerID,
  'H',
  HomePhone
FROM
  Legacy
WHERE
  HomePhone IS NOT NULL
UNION ALL
SELECT
  CustomerID,
  'W',
  WorkPhone
FROM
  Legacy
WHERE
  WorkPhone IS NOT NULL
UNION ALL
SELECT
  CustomerID,
  'C',
  CellPhone
FROM
  Legacy
WHERE
  CellPhone IS NOT NULL
UNION ALL
SELECT
  CustomerID,
  'F',
  FaxPhone
FROM
  Legacy
WHERE
  FaxPhone IS NOT NULL
GO

-- Listing 3-21: The Product Attribute Tables
CREATE TABLE Colors
(
  Color char (10) NOT NULL
                  PRIMARY KEY
)
GO

INSERT Colors VALUES ('Black')
INSERT Colors VALUES ('White')
INSERT Colors VALUES ('Green')
INSERT Colors VALUES ('Red')
GO

CREATE TABLE Descriptions
(
  Description char (25) NOT NULL
                        PRIMARY KEY
)
GO

INSERT Descriptions VALUES ('Widget')
INSERT Descriptions VALUES ('Dohickey')
INSERT Descriptions VALUES ('Whatchamacallit')
INSERT Descriptions VALUES ('Doflingy')
INSERT Descriptions VALUES ('Gizmo')
GO

CREATE TABLE Prices
(
  Price money NOT NULL
              PRIMARY KEY
)
GO

INSERT Prices VALUES (2.50)
INSERT Prices VALUES (3.50)
INSERT Prices VALUES (4.50)
INSERT Prices VALUES (5.50)
INSERT Prices VALUES (6.50)
INSERT Prices VALUES (7.50)
GO

CREATE TABLE ItemSizes
(
  ItemSize char (20) NOT NULL
                     PRIMARY KEY
)
GO

INSERT ItemSizes VALUES ('Small')
INSERT ItemSizes VALUES ('Medium')
INSERT ItemSizes VALUES ('Large')
GO

-- Listing 3-22: Populating the Products Table with a CROSS JOIN
CREATE TABLE Products
(
  ProductID   int       NOT NULL
                        IDENTITY (1, 1)
                        PRIMARY KEY,
  Color       char (10) NOT NULL,
  Description char (25) NOT NULL,
  Price       money     NOT NULL,
  ItemSize    char (20) NOT NULL
)
GO

INSERT Products
(
  Color,
  Description,
  Price,
  ItemSize
)
SELECT
  C.Color,
  D.Description,
  P.Price,
  S.ItemSize
FROM
    Colors       C
  CROSS JOIN
    Descriptions D
  CROSS JOIN
    Prices       P
  CROSS JOIN
    ItemSizes    S
GO

-- Listing 3-23: Using the Modulo Operator and a CROSS JOIN to Populate a Table
CREATE TABLE OrderDetails
(
  OrderID   int NOT NULL,
  ProductID int NOT NULL,
  Quantity  int NOT NULL
)
GO

INSERT OrderDetails
(
  OrderID,
  ProductID,
  Quantity
)
SELECT
  O.OrderID,
  P.ProductID,
  (O.OrderID * P.ProductID) % 10 + 1
FROM
    Orders  O
  CROSS JOIN
   Products P

-- Listing 3-24: Using the Modulo Operator and a JOIN to Populate a Table
DECLARE
  @ProductCount int

SELECT
  @ProductCount = MAX (ProductID)
FROM
    Products

INSERT OrderDetails
(
  OrderID,
  ProductID,
  Quantity
)
SELECT
  O.OrderID,
  P.ProductID,
  (O.OrderID * P.ProductID) % 10 + 1
FROM
    Orders  O
  JOIN
    Products P ON  P.ProductID BETWEEN ((O.OrderID % @ProductCount) + 1)
               AND ((O.OrderID % @ProductCount) + 2
                   + O.OrderID % 10)

-- SQL Puzzle 3 - Populating the Customers Table
CREATE TABLE Customers
(
  CustomerID int       NOT NULL
                       IDENTITY (1, 1)
                       PRIMARY KEY,
  FirstName  char (25) NOT NULL,
  LastName   char (30) NOT NULL,
  Number     int       NOT NULL,
  Street     char (50) NOT NULL,
  City       char (30) NOT NULL,
  Province   char (2)  NOT NULL
)
GO

