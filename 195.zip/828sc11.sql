-----------------------------------------
-- Chapter 11 - User-Defined Functions --
-----------------------------------------

-- Listing 11-1: Syntax for Creating Scalar Functions
CREATE FUNCTION [ owner_name. ] function_name 
    ( [ { @parameter_name scalar_parameter_data_type [ = default ] } [ ,...n ] ] ) 
RETURNS scalar_return_data_type
[ WITH { ENCRYPTION | SCHEMABINDING } [,...n] ] 
[ AS ]
BEGIN 
    function_body 
    RETURN scalar_expression
END

-- Listing 11-2: The linear_max() Scalar Function
USE testdb
GO

CREATE FUNCTION dbo.linear_max
(
  @arg1 AS int,
  @arg2 AS int
)
RETURNS int
AS

BEGIN
  RETURN CASE
           WHEN @arg1 >= @arg2 THEN @arg1
           WHEN @arg2 >  @arg1 THEN @arg2
           ELSE NULL
         END
END
GO

GRANT EXECUTE ON dbo.linear_max TO public
GO

-- Listing 11-3: Invoking the linear_max() Scalar Function in a Standalone Statement
SELECT
  dbo.linear_max(1, 2)

-- Listing 11-4: Incorporating the linear_max Scalar Function in a Query
SELECT
  col1,
  col2,
  dbo.linear_max(col1, col2) AS max_col1_col2
FROM
  T1

-- Listing 11-5: Calculating the Maximum of Three Columns
SELECT
  col1,
  col2,
  col3,
  dbo.linear_max(dbo.linear_max(col1, col2), col3) AS max_col1_col2_col3
FROM
  T1

-- Listing 11-6: The linear_min Scalar Function
CREATE FUNCTION dbo.linear_min
(
  @arg1 AS int,
  @arg2 AS int
)
RETURNS int
AS

BEGIN
  RETURN CASE
           WHEN @arg1 <= @arg2 THEN @arg1
           WHEN @arg2 <  @arg1 THEN @arg2
           ELSE NULL
         END
END
GO

GRANT EXECUTE ON dbo.linear_min TO public
GO

-- Listing 11-7: The bitwise_and() Scalar Function
CREATE FUNCTION dbo.bitwise_and
(
  @arg1 varbinary(8000),
  @arg2 varbinary(8000)
) RETURNS varbinary(8000)
AS
BEGIN

  DECLARE
    @result   AS varbinary(8000),
    @numbytes AS int,
    @curpos   AS int

  SET @result   = 0x
  SET @numbytes = dbo.linear_min(DATALENGTH(@arg1), DATALENGTH(@arg2))
  SET @curpos   = 1

  WHILE @curpos <= @numbytes
  BEGIN
    SELECT
      @result = @result + CAST(SUBSTRING(@arg1, @curpos, 1) &
                               CAST(SUBSTRING(@arg2, @curpos, 1) AS tinyint) AS binary(1))
    SET @curpos = @curpos + 1
  END

  RETURN @result
END
GO

GRANT EXECUTE ON dbo.bitwise_and TO public
GO

-- Listing 11-8: The bitwise_or() Scalar Function
CREATE FUNCTION dbo.bitwise_or
(
  @arg1 varbinary(8000),
  @arg2 varbinary(8000)
) RETURNS varbinary(8000)
AS
BEGIN

  DECLARE
    @result   AS varbinary(8000),
    @numbytes AS int,
    @curpos   AS int

  SET @result   = 0x
  SET @numbytes = dbo.linear_min(DATALENGTH(@arg1), DATALENGTH(@arg2))
  SET @curpos   = 1

  WHILE @curpos <= @numbytes
  BEGIN
    SELECT
      @result = @result + CAST(SUBSTRING(@arg1, @curpos, 1) |
                               CAST(SUBSTRING(@arg2, @curpos, 1)
                                 AS tinyint)
                            AS binary(1))
    SET @curpos = @curpos + 1
  END

  RETURN @result
END
GO

GRANT EXECUTE ON dbo.bitwise_or TO public
GO

-- Listing 11-9: The bitwise_xor() Scalar Function
CREATE FUNCTION dbo.bitwise_xor
(
  @arg1 varbinary(8000),
  @arg2 varbinary(8000)
) RETURNS varbinary(8000)
AS
BEGIN

  DECLARE
    @result   AS varbinary(8000),
    @numbytes AS int,
    @curpos   AS int

  SET @result   = 0x
  SET @numbytes = dbo.linear_min(DATALENGTH(@arg1), DATALENGTH(@arg2))
  SET @curpos   = 1

  WHILE @curpos <= @numbytes
  BEGIN
    SELECT
      @result = @result + CAST(SUBSTRING(@arg1, @curpos, 1) ^
                               CAST(SUBSTRING(@arg2, @curpos, 1)
                                 AS tinyint)
                            AS binary(1))
    SET @curpos = @curpos + 1
  END

  RETURN @result
END
GO

GRANT EXECUTE ON dbo.bitwise_xor TO public
GO

-- Listing 11-10: The bitwise_not() Scalar Function
CREATE FUNCTION dbo.bitwise_not
(
  @arg1 varbinary(8000)
) RETURNS varbinary(8000)
AS
BEGIN

  DECLARE
    @result   AS varbinary(8000),
    @numbytes AS int,
    @curpos   AS int

  SET @result = 0x
  SET @numbytes = DATALENGTH(@arg1)
  SET @curpos = 1

  WHILE @curpos <= @numbytes
  BEGIN
    SELECT
      @result = @result + CAST(~CAST(SUBSTRING(@arg1, @curpos, 1) AS tinyint)
                            AS binary(1))
    SET @curpos = @curpos + 1
  END

  RETURN @result
END
GO

GRANT EXECUTE ON dbo.bitwise_not TO public
GO

-- Listing 11-11: Testing the Bitwise Scalar Functions
SELECT dbo.bitwise_and(0x00000001000000010000000100000001,
                       0xffffffffffffffffffffffffffffffff)
SELECT dbo.bitwise_or (0x00000001000000010000000100000001,
                       0xffffffffffffffffffffffffffffffff)
SELECT dbo.bitwise_xor(0x00000001000000010000000100000001,
                       0xffffffffffffffffffffffffffffffff)
SELECT dbo.bitwise_not(0x00000001000000010000000100000001)

-- Listing 11-12: Syntax for Creating Inline Table-Valued Functions
CREATE FUNCTION [ owner_name. ] function_name 
    ( [ { @parameter_name scalar_parameter_data_type [ = default ] } [ ,...n ] ] ) 
RETURNS TABLE 
[ WITH { ENCRYPTION | SCHEMABINDING } [ ,...n ] ] 
[ AS ] 
RETURN [ ( ] select-stmt [ ) ]

-- Listing 11-13: Example of a Built-in Function that Returns a Rowset
SELECT
  T1.*
FROM
  OPENROWSET('SQLOLEDB',
             'Server1';'sa';'password',
             'SELECT * FROM pubs.dbo.authors') AS T1

-- Listing 11-14: Syntax for Using a User-Defined Function that Returns a Rowset
SELECT
  T1.*
FROM
  f1(5) AS T1

-- Listing 11-15: Syntax for Using a User-Defined Function that Returns a Rowset in a Join Query
SELECT
  T1.*
FROM
    f1(5)  AS T1
  JOIN
    Table2 AS T2 ON T1.key_col = T2.key_col

-- Listing 11-16: The custorders() Inline Table-Valued Function
USE Northwind
GO

CREATE FUNCTION dbo.custorders (@custid char(5))
RETURNS TABLE
AS

RETURN SELECT
         *
       FROM
         Orders
       WHERE
         CustomerID = @custid
GO

-- Listing 11-17: Using the custorders() Inline Table-Valued Function
SELECT
  C.*
FROM
  custorders('VINET') AS C

-- Listing 11-18: Using the custorders() Inline Table-Valued Function in a Join Query
SELECT
  O.OrderID,
  O.OrderDate,
  OD.ProductID,
  OD.Quantity
FROM
    custorders('VINET') AS O
  JOIN
    [Order Details]     AS OD ON O.OrderID = OD.OrderID

-- Listing 11-19: Illegal custorderdetails Inline Table-Valued Function
CREATE FUNCTION dbo.custorderdetails
(
  @custid char(5)
)
RETURNS TABLE
AS

RETURN SELECT
         *,
         UnitPrice * Quantity
       FROM
           Orders          AS O
         JOIN
           [Order Details] AS OD ON O.OrderID = OD.OrderID
       WHERE
           CustomerID = @custid
GO

-- Listing 11-20: Legal custorderdetails Inline Table-Valued Function
CREATE FUNCTION dbo.custorderdetails
(
  @custid char(5)
)
RETURNS TABLE
AS

RETURN SELECT
         O.*,
         OD.ProductID,
         OD.UnitPrice,
         OD.Quantity,
         OD.Discount,
         UnitPrice * Quantity AS Value
       FROM
           Orders          AS O
         JOIN
           [Order Details] AS OD ON O.OrderID = OD.OrderID
       WHERE
           CustomerID = @custid
GO

-- Listing 11-21: Syntax for Creating Multistatement Table-Valued Functions
CREATE FUNCTION [ owner_name. ] function_name 
    ( [ { @parameter_name scalar_parameter_data_type [ = default ] } [ ,...n ] ] ) 
RETURNS @return_variable TABLE ( { column_definition | table_constraint } [ ,...n ] )
[ WITH { ENCRYPTION | SCHEMABINDING } [ ,...n ] ] 
[ AS ] 
BEGIN 
    function_body 
    RETURN
END

-- Listing 11-22: The get_mgremps() Multistatement Table-Valued Function
USE Northwind
GO

CREATE FUNCTION get_mgremps
(
  @mgrid AS int
)
RETURNS @tree table
(
  EmployeeID      int           NOT NULL,
  LastName        nvarchar(20)  NOT NULL,
  FirstName       nvarchar(10)  NOT NULL,
  Title           nvarchar(30)  NULL,
  TitleOfCourtesy nvarchar(25)  NULL,
  BirthDate       datetime      NULL,
  HireDate        datetime      NULL,
  Address         nvarchar(60)  NULL,
  City            nvarchar(15)  NULL,
  Region          nvarchar(15)  NULL,
  PostalCode      nvarchar(10)  NULL,
  Country         nvarchar(15)  NULL,
  HomePhone       nvarchar(24)  NULL,
  Extension       nvarchar(4)   NULL,
  Photo           image         NULL,
  Notes           ntext         NULL,
  ReportsTo       int           NULL,
  PhotoPath       nvarchar(255) NULL,
  lvl             int           NOT NULL
)
AS

BEGIN
  
  DECLARE @lvl AS int
  SET @lvl = 0

  INSERT INTO @tree
    SELECT
      *, 
      @lvl
    FROM
      Employees
    WHERE
      EmployeeID = @mgrid

  WHILE @@rowcount > 0
  BEGIN
    SET @lvl = @lvl + 1
    INSERT INTO @tree
      SELECT
        E.*,
        @lvl
      FROM
          Employees AS E
        JOIN
          @tree AS T ON  E.ReportsTo = T.EmployeeID
                     AND T.lvl       = @lvl - 1
  END  
  
  RETURN

END
GO

-- Listing 11-23: Using the get_mgremps() Multistatement Table-Valued Function
SELECT
  T1.*
FROM
  get_mgremps(5) AS T1

-- Listing 11-24: Getting Details about User-Defined Functions in master
USE master
GO

SELECT
  *
FROM
  sysobjects
WHERE
    type IN('FN', 'TF')
  AND
    uid IN(user_id('system_function_schema'),
           user_id('dbo'))

-- Listing 11-25: Invoking the fn_chariswhitespace() Scalar System Function
SELECT fn_chariswhitespace(' ') -- returns 1
SELECT fn_chariswhitespace('a') -- returns 0

-- Listing 11-26: Invoking the fn_varbintohexstr() Scalar Function
SELECT
  master.dbo.fn_varbintohexstr(0x0123456789abcdef)

-- Listing 11-27: Invoking the fn_varbintohexsubstring() Scalar Function
SELECT
  master.dbo.fn_varbintohexsubstring(1, 0x0123456789abcdef, 1, 2)

-- Listing 11-28: Invoking the fn_helpcollations() Table-Valued System Function
SELECT
  *
FROM
  ::fn_helpcollations()

-- Listing 11-29: Allowing Updates to System Tables
EXEC sp_configure 'allow updates', 1
GO
RECONFIGURE WITH OVERRIDE
GO

-- Listing 11-30: Creating Your Own User-Defined System Function
USE master
GO

CREATE FUNCTION system_function_schema.fn_linear_max
(
  @arg1 AS int,
  @arg2 AS int
)
RETURNS int
AS

BEGIN
  RETURN CASE
           WHEN @arg1 >= @arg2 THEN @arg1
           WHEN @arg2 >  @arg1 THEN @arg2
           ELSE NULL
         END
END
GO

GRANT EXECUTE ON system_function_schema.fn_linear_max TO public
GO

-- Listing 11-31: Disallowing Updates to System Tables
EXEC sp_configure 'allow updates', 0
GO
RECONFIGURE WITH OVERRIDE
GO

-- Listing 11-32: Invoking the fn_linear_max() System Function
SELECT
  fn_linear_max(1, 2)

-- Listing 11-33: Using the fn_linear_max() System Function in a Query
SELECT
  col1,
  col2,
  fn_linear_max(col1, col2) AS max_value
FROM
  <table_name>

-- Listing 11-34: Creating a User-Defined Function with Default Values
CREATE FUNCTION dbo.myudf
(
  @arg1 int,
  @arg2 int = 0
)
RETURNS int
AS
BEGIN
  RETURN @arg1 + @arg2
END
GO 

-- Listing 11-35: Legal Invocation of a User-Defined Function with Default Values
SELECT
  dbo.myudf(1, DEFAULT)

-- Listing 11-36: Illegal Invocation of a User-Defined Function with Default Values
SELECT
  dbo.myudf(1)

-- Listing 11-37: Creating the num_with_cast9_checkdigit() Scalar Deterministic User-Defined Function
CREATE FUNCTION dbo.num_with_cast9_checkdigit
(
  @num AS int
)
RETURNS int
WITH SCHEMABINDING

AS
BEGIN
  RETURN @num * 10 + ((@num - 1) % 9 + 1)
END
GO

-- Listing 11-38: Using the num_with_cast9_checkdigit() Function in a Computed Column
CREATE TABLE T1
(
  num int NOT NULL PRIMARY KEY,
  numwithcheckdigit AS dbo.num_with_cast9_checkdigit(num)
)
GO

-- Listing 11-39: Creating an Index on a Computed Column that Invokes a Deterministic Function
CREATE INDEX idx_nci_numwithcheckdigit ON T1(numwithcheckdigit)
GO

-- Listing 11-40: Creating a UNIQUE Constraint on a Computed Column that Invokes a Deterministic Function
DROP INDEX T1.idx_nci_numwithcheckdigit
GO
ALTER TABLE T1
  ADD CONSTRAINT UNQ_T1_numwithcheckdigit
      UNIQUE(numwithcheckdigit)
GO

-- Listing 11-41: Illegal Attempt to Create a PRIMARY KEY Constraint on a Computed Column that Invokes a Deterministic Function
DROP TABLE T1
GO

CREATE TABLE T1
(
  num int NOT NULL,
  numwithcheckdigit AS dbo.num_with_cast9_checkdigit(num) NOT NULL PRIMARY KEY
)
GO

-- Listing 11-42: Creating a PRIMARY KEY Constraint on a Computed Column that Invokes a Deterministic Function
CREATE TABLE T1
(
  num int NOT NULL,
  numwithcheckdigit AS ISNULL(dbo.num_with_cast9_checkdigit(num), 0) PRIMARY KEY
)

-- Listing 11-43: Inserting a Row that Causes an Overflow in a Function Invocation
INSERT INTO T1 VALUES(10000000000)

Server: Msg 8115, Level 16, State 3, Line 1
Arithmetic overflow error converting numeric to data type int.
The statement has been terminated.

-- Listing 11-44: Inserting Rows in a Table with a Computed Column that Invokes a User-Defined Function
INSERT INTO T1 VALUES(123)
INSERT INTO T1 VALUES(234)
INSERT INTO T1 VALUES(456)
INSERT INTO T1 VALUES(678)
INSERT INTO T1 VALUES(789)
INSERT INTO T1 VALUES(890)

SELECT * FROM T1

-- Listing 11-45: Deferred Name Resolution in User-Defined Functions
USE testdb
GO

CREATE FUNCTION dbo.f1
(
  @arg1 AS int
)
RETURNS int
AS
BEGIN
  DECLARE @var1 AS int

  SELECT
    @var1 = col1
  FROM
    T1
  WHERE
    key_col = @arg1

  SET @var1 = dbo.f2(@var1)

  RETURN @var1
END
GO

-- Listing 11-46: Implementing the fibonacci() User-Defined Function with Recursion
CREATE FUNCTION dbo.fibonacci
(
  @n AS int
)
RETURNS int
AS

BEGIN
  RETURN CASE
           WHEN @n > 1 THEN @n + dbo.fibonacci(@n - 1) --recursive invocation
           WHEN @n IN (0, 1) THEN @n
           ELSE NULL 
         END
END
GO

-- Listing 11-47: Invoking the Recursive fibonacci() User-Defined Function
SELECT dbo.fibonacci(32) -- succeeds
SELECT dbo.fibonacci(33) -- fails

-- Listing 11-48: Implementing the fibonacci2() User-Defined Function with a Loop
CREATE FUNCTION dbo.fibonacci2
(
  @n AS int
)
RETURNS int
AS

BEGIN
  IF @n < 0
    RETURN NULL
  ELSE
    IF @n in (0, 1)
      RETURN @n
  ELSE
  BEGIN
    DECLARE
      @i AS int,
      @f AS int

    SET @i = @n
    SET @f = 0
    WHILE @i > 0
    BEGIN
      SET @f = @f + @i
      SET @i = @i - 1
    END -- loop while @i > 0
  END -- if @n > 0
  RETURN @f
END -- function
GO

-- Listing 11-49: Invoking the Loop fibonacci2() User-Defined Function
SELECT dbo.fibonacci2(32) -- succeeds
SELECT dbo.fibonacci2(33) -- succeeds

-- Listing 11-50: Syntax for the OBJECTPROPERTY() Function
OBJECTPROPERTY ( <object_id> , <property> )

-- Listing 11-51: Using the OBJECTPROPERTY() Function
SELECT
  objectproperty(object_id('dbo.fibonacci'), 'IsScalarFunction')

-- Listing 11-52: Creating the complex User-Defined Datatype
EXEC sp_addtype complex, 'varchar(50)'

-- Listing 11-53: Creation Script for the dbo.cxValid Function
----------------------------
-- Complex Validate       --
-- 0 - invalid, 1 - valid --
----------------------------
CREATE FUNCTION dbo.cxValid(
  @cx AS complex)
RETURNS bit
AS

BEGIN
  -- trim leading and trailing blanks
  SET @cx = RTRIM(LTRIM(@cx))
  
  -- check if last character is 'i'
  IF RIGHT(@cx, 1) <> 'i'
    RETURN 0

  -- remove the character 'i' from the end
  SET @cx = LEFT(@cx, LEN(@cx) - 1)

  -- find the position of the middle -/+ sign
  DECLARE @signpos AS int
  SET @signpos = PATINDEX('%_[-+]%', @cx) + 1
  IF @signpos = 0
    RETURN 0

  -- check if the real part exists and is numeric
  IF IsNumeric(LEFT(@cx, @signpos - 1)) = 0
    RETURN 0
    
  -- check if the imaginary part exists and is numeric
  IF IsNumeric(RIGHT(@cx, LEN(@cx) - @signpos + 1)) = 0
    RETURN 0

  -- if not aborted yet, number is a "real" imaginary number. ;-)
  RETURN 1
END
GO

--------------------------------
-- Complex Validate as a rule --
--------------------------------
CREATE rule complex_valid
AS
  -- check if last character is 'i'
  RIGHT(RTRIM(@cx), 1) = 'i' AND

  -- check if the real part exists and is numeric
  IsNumeric(LEFT(LTRIM(@cx),
              PATINDEX('%_[-+]%', LTRIM(@cx)))) = 1 AND

  -- check if the imaginary part exists and is numeric
  IsNumeric(SUBSTRING(LTRIM(@cx),
              PATINDEX('%_[-+]%', LTRIM(@cx)) + 1,
              LEN(RTRIM(LTRIM(@cx))) -
                PATINDEX('%_[-+]%', LTRIM(@cx)) - 1)) = 1
GO

EXEC sp_bindrule 'complex_valid', 'complex'
GO

-- Listing 11-55: Creation Script for the dbo.cxNormalize Function
--------------------------------------------------------
-- Normalize the complex number to: '[-]a {+ | -} bi' --
-- with no redundant trailing zeros                   --
--------------------------------------------------------
CREATE FUNCTION dbo.cxNormalize(
  @cx AS complex)
RETURNS complex
AS

BEGIN
-- step 1: remove spaces
  SET @cx = REPLACE(@cx, ' ', '')

-- step 2: remove redundant trailing zeros
--        from both the real and imaginary parts  

  -- extract the real part
  DECLARE @real AS varchar(25)
  SET @real = LEFT(@cx, PATINDEX('%_[-+]%', @cx))

  -- remove the dot if one exists and only zeros appear after it
  IF CHARINDEX('.', @real) > 0 AND PATINDEX('%.%[1-9]%', @real) = 0
    SET @real = LEFT(@real, CHARINDEX('.', @real) - 1)

  -- remove trailing zeros if there are significant digits after the dot
  IF PATINDEX('%.%0', @real) > 0
    SET @real = LEFT(@real, LEN(@real) - PATINDEX('%[^0]%.%',
                                           REVERSE(@real)) + 1)

  -- extract the imaginary part
  DECLARE @imaginary AS varchar(25)
  SET @imaginary = SUBSTRING(@cx, PATINDEX('%_[-+]%', @cx) + 1,
                     CHARINDEX('i', @cx) - PATINDEX('%_[-+]%',
                                             @cx) - 1)

  -- remove the dot if one exists and only zeros appear after it
  IF CHARINDEX('.', @imaginary) > 0
     AND PATINDEX('%.%[1-9]%', @imaginary) = 0
    SET @imaginary = LEFT(@imaginary, CHARINDEX('.', @imaginary) - 1)

  -- remove trailing zeros if there are significant digits after the dot
  IF PATINDEX('%.%0', @imaginary) > 0
    SET @imaginary = LEFT(@imaginary,
                       LEN(@imaginary) - PATINDEX('%[^0]%.%',
                                           REVERSE(@imaginary)) + 1)

-- step 3: concatenate the real and imaginary parts
  SET @cx = @real + @imaginary + 'i'

-- step 4: add a space before and after middle sign
  SET @cx = STUFF(@cx, PATINDEX('%_[-+]%', @cx) + 1, 0, ' ')
  SET @cx = STUFF(@cx, PATINDEX('%_[-+]%', @cx) + 2, 0, ' ')

-- step 5: remove positive sign before the real part, if one exists
  IF LEFT(@cx, 1) = '+'
    SET @cx = STUFF(@cx, 1, 1, '')

  RETURN @cx
END
GO

-- Listing 11-56: Creation Script for the dbo.cxGetReal Function
------------------------------------------------
-- Get Real                                   --
-- Extract real portion of the complex number --
------------------------------------------------
CREATE FUNCTION dbo.cxGetReal(
  @cx AS complex)
RETURNS decimal(19, 9)
AS

BEGIN
  SET @cx = REPLACE(@cx, ' ', '')
  RETURN CAST(LEFT(@cx, PATINDEX('%_[-+]%', @cx)) AS decimal(19,9))
END
GO

-- Listing 11-57: Creation Script for the dbo.cxGetImaginary Function
-----------------------------------------------------
-- Get Imaginary                                   --
-- Extract imaginary portion of the complex number --
-----------------------------------------------------
CREATE FUNCTION dbo.cxGetImaginary(
  @cx AS complex)
RETURNS decimal(19,9)
AS

BEGIN
  SET @cx = REPLACE(@cx, ' ', '')
  RETURN CAST(
           SUBSTRING(
             @cx,
             PATINDEX('%_[-+]%', @cx) + 1,
             CHARINDEX('i', @cx) - PATINDEX('%_[-+]%', @cx) - 1)
           AS decimal(19,9))
END
GO

-- Listing 11-58: Creation Script for the dbo.cxStrForm Function
-----------------------------------------------------
-- Format Complex Number String                    --
-- Form a string representing a complex number     --
-- out of its real and imaginary parts             --
-----------------------------------------------------
CREATE FUNCTION dbo.cxStrForm(
  @real      AS decimal(19,9),
  @imaginary AS decimal(19,9))
RETURNS complex
AS

BEGIN
  RETURN dbo.cxNormalize(
    CAST(@real AS varchar(21)) +
    CASE SIGN(@imaginary)
      WHEN -1 THEN '-'
      ELSE '+'
    END +
    CAST(ABS(@imaginary) AS varchar(21)) +
    'i')
END
GO

-- Listing 11-59: Creation Script for the dbo.cxAdd Function
--------------------------------------
-- Complex Add                      --
-- z1 + z2 = (a1 + a2) + (b1 + b2)i --
--------------------------------------
CREATE FUNCTION dbo.cxAdd(
  @cx1 as complex,
  @cx2 as complex)
RETURNS complex
AS

BEGIN

  IF dbo.cxValid(@cx1) = 0 OR dbo.cxValid(@cx2) = 0
    RETURN NULL

  DECLARE
    @a1        AS decimal(19,9),
    @b1        AS decimal(19,9),
    @a2        AS decimal(19,9),
    @b2        AS decimal(19,9)

  DECLARE
    @real      AS decimal(19,9),
    @imaginary AS decimal(19,9)

  SET @a1 = dbo.cxGetReal(@cx1)
  SET @a2 = dbo.cxGetReal(@cx2)
  SET @b1 = dbo.cxGetImaginary(@cx1)
  SET @b2 = dbo.cxGetImaginary(@cx2)

  -- z1 + z2 = (a1 + a2) + (b1 + b2)i
  SET @real =      @a1 + @a2
  SET @imaginary = @b1 + @b2

  RETURN dbo.cxStrForm(@real, @imaginary)

END
GO

-- Listing 11-60: Creation Script for the dbo.cxSubtract Function
--------------------------------------
-- Complex Subtract                 --
-- z1 - z2 = (a1 - a2) + (b1 - b2)i --
--------------------------------------
CREATE FUNCTION dbo.cxSubtract(
  @cx1 as complex,
  @cx2 as complex)
RETURNS complex
AS

BEGIN

  IF dbo.cxValid(@cx1) = 0 OR dbo.cxValid(@cx2) = 0
    RETURN NULL

  DECLARE
    @a1        AS decimal(19,9),
    @b1        AS decimal(19,9),
    @a2        AS decimal(19,9),
    @b2        AS decimal(19,9)

  DECLARE
    @real      AS decimal(19,9),
    @imaginary AS decimal(19,9)

  SET @a1 = dbo.cxGetReal(@cx1)
  SET @a2 = dbo.cxGetReal(@cx2)
  SET @b1 = dbo.cxGetImaginary(@cx1)
  SET @b2 = dbo.cxGetImaginary(@cx2)

  -- z1 - z2 = (a1 - a2) + (b1 - b2)i
  SET @real =      @a1 - @a2
  SET @imaginary = @b1 - @b2

  RETURN dbo.cxStrForm(@real, @imaginary)

END
GO

-- Listing 11-61: Creation Script for the dbo.cxMult Function
--------------------------------------------------
-- Complex Multiply                             --
-- z1 * z2 = (a1*a2 - b1*b2) + (a1*b2 + a2*b1)i --
--                                              --
-- Explanation:                                 --
-- z1 * z2 =                                    --
-- (a1 + b1i) * (a2 + b2i) =                    --
-- a1*a2 + a1*b2i + a2*b1i + b1*b2i� =          --
-- a1*a2 + a1*b2i + a2*b1i - b1*b2 =            --
-- (a1*a2 - b1*b2) + (a1*b2 + a2*b1)i           --
--------------------------------------------------
CREATE FUNCTION dbo.cxMult(
  @cx1 as complex,
  @cx2 as complex)
RETURNS complex
AS

BEGIN

  IF dbo.cxValid(@cx1) = 0 OR dbo.cxValid(@cx2) = 0
    RETURN NULL

  DECLARE
    @a1        AS decimal(19,9),
    @b1        AS decimal(19,9),
    @a2        AS decimal(19,9),
    @b2        AS decimal(19,9)

  DECLARE
    @real      AS decimal(19,9),
    @imaginary AS decimal(19,9)

  SET @a1 = dbo.cxGetReal(@cx1)
  SET @a2 = dbo.cxGetReal(@cx2)
  SET @b1 = dbo.cxGetImaginary(@cx1)
  SET @b2 = dbo.cxGetImaginary(@cx2)

  -- z1 * z2 = (a1*a2 - b1*b2) + (a1*b2 + a2*b1)i
  SET @real =      @a1*@a2 - @b1*@b2
  SET @imaginary = @a1*@b2 + @a2*@b1

  RETURN dbo.cxStrForm(@real, @imaginary)

END
GO

-- Listing 11-62: Creation Script for the dbo.cxDivide Function
--------------------------------------------------------------------
-- Complex Divide                                                 --
-- z1 / z2 =                                                      --
-- ((a1*a2 + b1*b2)/(a2� + b2�)) + ((a2*b1 - a1*b2)/(a2� + b2�))i --
--                                                                --
-- Explanation:                                                   --
--             _                                                  --
-- z = a + bi, z = a - bi                                         --
--     _           _                                              --
-- z + z = 2a, z * z = a� + b�                                    --
-- z1 / z2 =                                                      --
--     _         _                                                --
-- (z1*z2)/(z2*z2) =                                              --
-- ((a1 + b1i)*(a2 - b2i))/(a2� + b2�) =                          --
-- ((a1*a2 + b1*b2) + (a2*b1 - a1*b2)i)/(a2� + b2�) =             --
-- ((a1*a2 + b1*b2)/(a2� + b2�)) + ((a2*b1 - a1*b2)/(a2� + b2�))i --
--------------------------------------------------------------------
CREATE FUNCTION dbo.cxDivide(
  @cx1 as complex,
  @cx2 as complex)
RETURNS complex
AS

BEGIN

  IF dbo.cxValid(@cx1) = 0 OR dbo.cxValid(@cx2) = 0
    RETURN NULL

  DECLARE
    @a1        AS decimal(19,9),
    @b1        AS decimal(19,9),
    @a2        AS decimal(19,9),
    @b2        AS decimal(19,9)

  DECLARE
    @real      AS decimal(19,9),
    @imaginary AS decimal(19,9)

  SET @a1 = dbo.cxGetReal(@cx1)
  SET @a2 = dbo.cxGetReal(@cx2)
  SET @b1 = dbo.cxGetImaginary(@cx1)
  SET @b2 = dbo.cxGetImaginary(@cx2)

  -- ((a1*a2 + b1*b2)/(a2� + b2�)) + ((a2*b1 - a1*b2)/(a2� + b2�))i
  SET @real =      (@a1*@a2 + @b1*@b2)/(@a2*@a2 + @b2*@b2)
  SET @imaginary = (@a2*@b1 - @a1*@b2)/(@a2*@a2 + @b2*@b2)

  RETURN dbo.cxStrForm(@real, @imaginary)

END
GO

-- Listing 11-63: Creation Script for the dbo.cxVectorSize Function
--------------------------------------------------
-- Complex Vector Length                        --
-- r = |z| = |a + bi| =                         --
-- Pythagoras: SQRT(a� + b�)                    --
--------------------------------------------------
CREATE FUNCTION dbo.cxVectorSize(
  @cx as complex)
RETURNS decimal(19,9)
AS

BEGIN

  IF dbo.cxValid(@cx) = 0
    RETURN NULL

  DECLARE
    @real      AS decimal(19,9),
    @imaginary AS decimal(19,9)

  SET @real      = dbo.cxGetReal(@cx)
  SET @imaginary = dbo.cxGetImaginary(@cx)

  -- r = SQRT(a� + b�)
  RETURN SQRT(@real*@real + @imaginary*@imaginary)

END
GO

-- Listing 11-64: A Table Populated with Sample Complex Numbers
CREATE TABLE T1
(
  key_col int NOT NULL PRIMARY KEY,
  cx1 complex NOT NULL,
  cx2 complex NOT NULL
)

INSERT INTO T1 VALUES(1, '5 + 2i', '2 + 4i')
INSERT INTO T1 VALUES(2, '2 + 9i', '4 + 5i')
INSERT INTO T1 VALUES(3, '7 + 4i', '3 + 2i')
INSERT INTO T1 VALUES(4, '3 + 2i', '6 + 3i')
INSERT INTO T1 VALUES(5, '4 + 3i', '7 + 2i')
INSERT INTO T1 VALUES(6, '1 + 4i', '4 + 3i')
INSERT INTO T1 VALUES(7, '7 + 2i', '8 + 1i')
INSERT INTO T1 VALUES(8, '2 + 3i', '3 + 6i')
INSERT INTO T1 VALUES(9, '3 + 6i', '2 + 8i')
INSERT INTO T1 VALUES(10, '2 + 1i', '3 + 2i')

-- Listing 11-65: Embedding the Complex Functions in a Query
SELECT
  key_col,
  cx1,
  cx2,
  dbo.cxAdd(cx1, cx2)      AS cxAdd,
  dbo.cxSubtract(cx1, cx2) AS cxSubtract,
  dbo.cxMult(cx1, cx2)     AS cxMult,
  dbo.cxDivide(cx1, cx2)   AS cxDivide
FROM
  T1

-- Listing 11-66: Performing Aggregate Computations with Complex Functions
DECLARE @sumproduct AS complex
SET @sumproduct = '0 + 0i'

SELECT
  @sumproduct = dbo.cxAdd(@sumproduct, dbo.cxMult(cx1, cx2))
FROM
  T1

PRINT 'The sum product of the vectors is: ' + @sumproduct

The sum product of the vectors is: 8 + 252i

-- Listing 11-67: Original Sound Wave in the Spatial Domain
CREATE TABLE SoundWave
(
  time_index  int             NOT NULL
                              PRIMARY KEY,
  sound_level decimal (19, 9) NOT NULL
)

-- Listing 11-68: Filter in the Frequency Domain
CREATE TABLE Filter
(
  frequency_index int          NOT NULL
                               PRIMARY KEY,
  filter_vector        complex NOT NULL
)

-- Listing 11-69: Transformed Sound Wave in the Frequency Domain
CREATE TABLE TransformedSoundWave
(
  frequency_index int        NOT NULL
                             PRIMARY KEY,
  signal_vector      complex NOT NULL
)

-- Listing 11-70: Storing the Filtered Sound Wave in the Frequency Domain in a Table
INSERT INTO TransformedFilteredSoundWave
  SELECT
    T.frequency_index,
    dbo.cxMult(T.signal_vector, F.filter_vector) AS signal_vector
  FROM
      TransformedSoundWave AS T
    JOIN
      Filter AS F ON T.frequency_index = F.frequency_index
