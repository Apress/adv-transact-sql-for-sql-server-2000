-----------------------------------
-- Chapter 12 - Temporary Tables --
-----------------------------------

-- Listing 12-1: Creating a Temporary Table with a SELECT INTO
SELECT
  CustomerID,
  OrderDate,
  ShippedDate
INTO
  #OrderInfo
FROM
    Orders

-- Listing 12-2: Creating a Global Temporary Table
CREATE TABLE ##CustomerSales
(
  CustomerID char (6) NOT NULL,
  Year       smallint NOT NULL,
  Sales      money    NOT NULL
)

-- Listing 12-3: NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  C.*
FROM
    Customers AS C
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O1
  WHERE
      O1.CustomerID = C.CustomerID
    AND
      O1.OrderDate BETWEEN '19960101' AND '19961231'
)
AND EXISTS
(
  SELECT
    *
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = C.CustomerID
    AND
      O2.OrderDate BETWEEN '19970101' AND '19971231'
)
AND
    C.Country IN ('Canada', 'USA', 'Mexico')

-- Listing 12-4: Orders in 1998 for NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  O.*
FROM
    Customers AS C
  JOIN
    Orders    AS O  ON O.CustomerID = C.CustomerID
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O1
  WHERE
      O1.CustomerID = C.CustomerID
    AND
      O1.OrderDate BETWEEN '19960101' AND '19961231'
)
AND EXISTS
(
  SELECT
    *
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = C.CustomerID
    AND
      O2.OrderDate BETWEEN '19970101' AND '19971231'
)
AND
    C.Country IN ('Canada', 'USA', 'Mexico')
AND
    O.OrderDate BETWEEN '19980101' AND '19981231'

-- Listing 12-5: Order Details in 1998 for NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  OD.*
FROM
    Customers       AS C
  JOIN
    Orders          AS O  ON O.CustomerID = C.CustomerID
  JOIN
    [Order Details] AS OD ON OD.OrderID   = O.OrderID
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O1
  WHERE
      O1.CustomerID = C.CustomerID
    AND
      O1.OrderDate BETWEEN '19960101' AND '19961231'
)
AND EXISTS
(
  SELECT
    *
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = C.CustomerID
    AND
      O2.OrderDate BETWEEN '19970101' AND '19971231'
)
AND
    C.Country IN ('Canada', 'USA', 'Mexico')
AND
    O.OrderDate BETWEEN '19980101' AND '19981231'

-- Listing 12-6: Creating a Temporary Table of NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  C.*
INTO
  #NAFTA
FROM
    Customers AS C
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O1
  WHERE
      O1.CustomerID = C.CustomerID
    AND
      O1.OrderDate BETWEEN '19960101' AND '19961231'
)
AND EXISTS
(
  SELECT
    *
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = C.CustomerID
    AND
      O2.OrderDate BETWEEN '19970101' AND '19971231'
)
AND
    C.Country IN ('Canada', 'USA', 'Mexico')

CREATE UNIQUE INDEX #IDX on #NAFTA (CustomerID)

-- Listing 12-7: NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  *
FROM
    #NAFTA

-- Listing 12-8: Orders in 1998 for NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  O.*
FROM
    #NAFTA AS C
  JOIN
    Orders AS O ON O.CustomerID = C.CustomerID
WHERE
    O.OrderDate BETWEEN '19980101' AND '19981231'

-- Listing 12-9: Orders Details in 1998 for NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  OD.*
FROM
    #NAFTA          AS C
  JOIN
    Orders          AS O ON O.CustomerID = C.CustomerID
  JOIN
    [Order Details] AS OD ON OD.OrderID  = O.OrderID
WHERE
    O.OrderDate BETWEEN '19980101' AND '19981231'

-- Listing 12-10: Creating a Temporary Table of NAFTA CustomerIDs with No Orders in 1996 but with Orders in 1997
SELECT
  C.CustomerID
INTO
  #NAFTA
FROM
    Customers AS C
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O1
  WHERE
      O1.CustomerID = C.CustomerID
    AND
      O1.OrderDate BETWEEN '19960101' AND '19961231'
)
AND EXISTS
(
  SELECT
    *
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = C.CustomerID
    AND
      O2.OrderDate BETWEEN '19970101' AND '19971231'
)
AND
    C.Country IN ('Canada', 'USA', 'Mexico')

CREATE UNIQUE INDEX #IDX on #NAFTA (CustomerID)

-- Listing 12-11: NAFTA Customers with No Orders in 1996 but with Orders in 1997
SELECT
  c.*
FROM
    #NAFTA    AS T
  JOIN
    Customers AS C ON C.CustomerID = T.CustomerID

-- Listing 12-12: Pivot Table for Quarterly Sales per Year per Customer
SELECT
  YEAR (O.OrderDate) AS Year,
  O.CustomerID,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 1
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q1,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 2
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q2,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 3
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q3,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 4
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q4
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID = O.OrderID
GROUP BY
  YEAR (O.OrderDate),
  O.CustomerID
ORDER BY
  Year,
  O.CustomerID

-- Listing 12-13: Quarterly Sales per Customer for a Single Year
SELECT
  O.CustomerID,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 1
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q1,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 2
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q2,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 3
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q3,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 4
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0
       END) AS Q4
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID = O.OrderID
WHERE
    O.OrderDate BETWEEN '19960101' AND '19961231'
GROUP BY
  O.CustomerID
ORDER BY
  O.CustomerID

-- Listing 12-14: Creating a Temporary Table for Quarterly Customer Sales for All Years
SELECT
  YEAR (O.OrderDate) AS Year,
  O.CustomerID,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 1
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0 
       END) AS Q1,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 2
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0 
       END) AS Q2,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 3
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0 
       END) AS Q3,
  SUM (CASE
         WHEN DATEPART(qq, O.OrderDate) = 4
           THEN OD.Quantity * OD.UnitPrice
         ELSE 0 
       END) AS Q4
INTO
  ##Sales
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID = O.OrderID
GROUP BY
  YEAR (O.OrderDate),  
  O.CustomerID

CREATE UNIQUE CLUSTERED INDEX #IDX on ##Sales (Year, CustomerID)

-- Listing 12-15: Creating Annual Sales Reports from the Global Temporary Table
DECLARE
  @MaxYear int,
  @CurYear int,
  @ExecStr varchar (8000)

SELECT
  @CurYear = MIN (YEAR (OrderDate)),  -- first year
  @MaxYear = MAX (YEAR (OrderDate))   -- last year
FROM
  Orders

-- loop through all years
WHILE @CurYear <= @MaxYear
BEGIN
  -- build string to send to xp_cmdshell
  SELECT
    @ExecStr = 'osql -E -w2000 -S.\BMCI03_02 '
             + '-Q"SELECT CustomerID, Q1, Q2, Q3, Q4 '
             + 'FROM ##Sales WHERE Year = '
             + STR (@CurYear, 4)
             + '" -oC:\TEMP\'
             + STR (@CurYear, 4)
             + '.txt'

  -- produce report and save to file
  EXEC master..xp_cmdshell @ExecStr

  -- get next year
  SELECT
    @CurYear = @CurYear + 1
END

-- Listing 12-16: Creating a Temporary Table of Order Totals for a Customer
SELECT
  IDENTITY (int, 1, 1)             AS Sequence,
  O.OrderID,
  SUM (OD.Quantity * OD.UnitPrice) AS Total
INTO
  #Totals
FROM
    Orders AS O
  JOIN
    [Order Details] AS OD ON OD.Orderid = o.OrderID
WHERE
    O.CustomerID = 'SAVEA'
GROUP BY
  O.OrderID
ORDER BY
  O.OrderID

CREATE UNIQUE CLUSTERED INDEX #Idx on #Totals (Sequence)

-- Listing 12-17: Calculating the Discount
SELECT
  OrderID,
  Total,
  Previous4,
  CASE
    WHEN Previous4 < 10000.00 THEN 5
    WHEN Previous4 BETWEEN 10000.00 AND 15000.00 THEN 10
    ELSE 20
  END  AS Discount
FROM
(
  SELECT
    T1.OrderID,
    T1.Total,
    (
      SELECT
        SUM (T2.Total) AS Total
      FROM
          #Totals AS T2
      WHERE
          T2.Sequence >= T1.Sequence - 4
        AND
          T2.Sequence < T1.Sequence
    )  AS Previous4
  FROM
    #Totals AS T1
  WHERE
      0 = T1.Sequence % 5
)  AS X

-- Listing 12-18: Sending Variable Information to an EXEC() Call
DECLARE
  @IntVal int

SET
  @IntVal = 21

EXEC ('usp_MyProc ' + STR (@IntVal))

-- Listing 12-19: Illegal Use of Variable in Call to EXEC()
DECLARE
  @Variable varchar (25)

EXEC ('SET @Variable = ''my value''')   -- this won't work

-- Listing 12-20: Using a Temporary Table to Communicate with an EXEC()
DECLARE
  @Variable varchar (25)

CREATE TABLE #tmpvar
(
  Variable varchar (25) NOT NULL
)

EXEC ('INSERT INTO #tmpvar VALUES (''my value'')')

SELECT
  @Variable = Variable
FROM
  #tmpvar

DROP TABLE #tmpvar
PRINT @Variable

-- Listing 12-21: Creating a Table with Duplicate Rows
CREATE TABLE Dupes
(
  ID  int       NOT NULL,
  Txt char (10) NOT NULL
)
GO

INSERT Dupes (ID, Txt) VALUES (1, 'x')
INSERT Dupes (ID, Txt) VALUES (1, 'a')
INSERT Dupes (ID, Txt) VALUES (1, 'x')
INSERT Dupes (ID, Txt) VALUES (1, 'x')
INSERT Dupes (ID, Txt) VALUES (2, 'b')
INSERT Dupes (ID, Txt) VALUES (2, 'x')
INSERT Dupes (ID, Txt) VALUES (2, 'b')
INSERT Dupes (ID, Txt) VALUES (3, 'c')

-- Listing 12-22: Creating a Temporary Table of Distinct Rows
SELECT
  ID,
  Txt
INTO
  #Singles
FROM
    Dupes
GROUP BY
  ID,
  Txt
HAVING
  COUNT (*) > 1

-- Listing 12-23: Removing the Duplicates
DELETE d
FROM
    Dupes AS D
  JOIN
    #Singles AS S ON  S.ID  = D.ID
                  AND S.Txt = D.Txt

-- Listing 12-24: Inserting the Former Duplicates
INSERT Dupes
SELECT
  *
FROM
  #Singles

-- Listing 12-25: Altering the Table to Add an IDENTITY Column
ALTER TABLE Dupes
ADD
  Ident int NOT NULL IDENTITY (1, 1)

-- Listing 12-26: Deleting Duplicates With a Correlated Subquery
DELETE D1
FROM
    Dupes AS D1
WHERE
    D1.Ident >
(
  SELECT
    MIN (D2.Ident)
  FROM
      Dupes AS D2
  WHERE
      D2.ID  = D1.ID
    AND
      D2.Txt = D1.Txt
)

-- Listing 12-27: Deleting Duplicates with a Join
DELETE D1
FROM
    Dupes AS D1
  JOIN
    Dupes AS D2 ON  D2.ID    = D1.ID
                AND D2.Txt   = D1.Txt
                AND D1.Ident > D2.Ident

-- Listing 12-28: Removing the IDENTITY Column
ALTER TABLE Dupes
DROP COLUMN
  Ident

