----------------------------------------------
-- Chapter 7 - Writing Code in Transact-SQL --
----------------------------------------------


-- Listing 7-1: Syntax for the DECLARE Statement
DECLARE
 {@local_variable [AS] data_type}
[,...n]

-- Listing 7-2: Example of the DECLARE Statement
DECLARE
 @OrderID    int,
 @CustomerID int,
 @ShipDate   datetime

-- Listing 7-3: Syntax for Variable Assigment with the SELECT Statement
SELECT {@local_variable = expression } [,...n]

-- Listing 7-4: Using SELECT to Assign a Variable
DECLARE
  @Customerid AS char(5)

SELECT
  @CustomerID = CustomerID
FROM
  Orders
WHERE
  OrderID = 10248

PRINT @CustomerID

-- Listing 7-5: Using Aggregate Concatenation
DECLARE
  @OrderIDs AS varchar (8000)
SET
  @OrderIDs = ''
SELECT
  @OrderIDs = @OrderIDs + CAST (OrderID AS varchar) + ';'
FROM
  Orders
WHERE
  CustomerID = 'VINET'

PRINT @OrderIDs

-- Listing 7-6: Syntax for Variable Assignment with the SET Statement
SET 
  @local_variable = expression

-- Listing 7-7: Example of a Variable Not Updated Due to No Rows Being Returned
DECLARE
  @CustomerID int

SELECT
  @CustomerID = 0

SELECT
  @CustomerID = CustomerID
   FROM
     Orders
   WHERE
     OrderID = 1

SELECT
  @CustomerID

-- Listing 7-8: Assignment with a Subquery
DECLARE
  @CustomerID int

SELECT
  @CustomerID = 0

SELECT
  @CustomerID = 
 (
   SELECT
     CustomerID
   FROM
     Orders
   WHERE
     OrderID = 1
)

SELECT
  @CustomerID

-- Listing 7-9: Syntax for the IF ELSE Statement
IF Boolean_expression
  {sql_statement | statement_block}
[ELSE
  {sql_statement | statement_block}]

-- Listing 7-10: Example of a Simple IF ELSE
IF @@ERROR <> 0 OR @@ROWCOUNT = 0
  RAISERROR ('Houston, we have a problem.', 16, 1)
ELSE
BEGIN
  PRINT 'Success'

  UPDATE Orders
  SET
    ShipDate = GETDATE ()
  WHERE
     OrderID = @OrderID
END

-- Listing 7-11: Illegal Table Creation with IF ELSE Construct
IF 1 = 1
  CREATE TABLE #MyTable
  (
    i int NOT NULL
  )
ELSE
  CREATE TABLE #MyTable
  (
    i int      NOT NULL,
    a char (5) NOT NULL
  )
GO

-- Listing 7-12: Syntax of the WHILE Loop
WHILE Boolean_expression
  {sql_statement | statement_block}
  [BREAK]
  {sql_statement | statement_block}
  [CONTINUE]

-- Listing 7-13: Sample Code for a WHILE Loop
DECLARE
  @Count int

SET
  @Count = 1

WHILE @Count <= 100
BEGIN
  INSERT MyTable VALUES (@Count)

  IF @@ERROR <> 0
    BREAK

  SET
    @Count = @Count + 1
END

-- Listing 7-14: A WHILE Loop with a Single Statement Using an EXEC
SET
  @rc = 1

WHILE @rc <> 0
  EXEC @rc = sp_MyProc

-- Listing 7-15: Using a Subquery with a Single-Statement WHILE Loop
WHILE (SELECT AVG (UnitPrice) FROM Products) < $20
  UPDATE Products
  SET
    UnitPrice = UnitPrice * 1.05

-- Listing 7-16: Syntax for the sp_addmessage System Stored Procedure
sp_addmessage [ @msgnum = ] msg_id ,
 [ @severity = ] severity ,
 [ @msgtext = ] 'msg'
 [ , [ @lang = ] 'language' ] 
 [ , [ @with_log = ] 'with_log' ]
 [ , [ @replace = ] 'replace' ]

-- Listing 7-17: Using sp_addmessage
sp_addmessage
  60000,
  16,
  'Customer does not exist.'

-- Listing 7-18: Syntax for the sp_altermessage System Stored Procedure
sp_altermessage [ @message_id = ] message_number ,
  [ @parameter = ] 'write_to_log' ,
  [ @parameter_value = ] 'value'

-- Listing 7-19: Using sp_altermessage
sp_altermessage
  60000,
  'WITH_LOG',
  'true'

-- Listing 7-20: Syntax for the sp_dropmessage System Stored Procedure
sp_dropmessage [ @msgnum = ] message_number
  [ , [ @lang = ] 'language' ]

-- Listing 7-21: Using sp_dropmessage
sp_dropmessage
  60000

-- Listing 7-22: Syntax for the RAISERROR Statement
RAISERROR ( { msg_id | msg_str } { , severity , state }
  [ , argument [ ,...n ] ] )
  [ WITH option [ ,...n ] ]

-- Listing 7-23: Placeholder Format
% [[flag] [width] [precision] [{h | l}]] type

-- Listing 7-24: Using RAISERROR with an Error Number
RAISERROR (60000, 16, 1)

-- Listing 7-25: Output from RAISERROR
Server: Msg 60000, Level 16, State 1, Line 1
Customer does not exist.

-- Listing 7-26: Using RAISERROR without an Error Number
RAISERROR ('Houston, we have a problem.', 16, 1)

-- Listing 7-27: Output from RAISERROR
Server: Msg 50000, Level 16, State 1, Line 1
Houston, we have a problem.

-- Listing 7-28: Using RAISERROR
RAISERROR ('Unable to find Customer ID %09d', 16, 1, @CustomerID)

-- Listing 7-29: Using sp_addmessage to Add an Error with Parameter Substitution
sp_addmessage
  60001,
  16,
  'Unable to find Customer ID %09d'

-- Listing 7-30: Raising a Numbered Message with Parameter Substitution
RAISERROR (60001, 16, 1, 23)

-- Listing 7-31: Raising an Error with Logging
RAISERROR (60001, 16, 1, 23) WITH LOG

-- Listing 7-32: Using RAISERROR with the SETERROR Option
RAISERROR (60001, 1, 2)
SELECT @@ERROR
GO

RAISERROR (60001, 1, 2) WITH SETERROR
SELECT @@ERROR

-- Listing 7-33: Using @@ERROR
DELETE [Order Details]
WHERE
  OrderID = @OrderID

IF @@ERROR = 0
  DELETE Orders
  WHERE
    OrderID = @OrderID

-- Listing 7-34: Saving the Value of @@ERROR
DECLARE
  @Error int

DELETE [Order Details]
WHERE
  OrderID = @OrderID

SET
  @Error = @@ERROR

IF @Error = 0
  DELETE Orders
  WHERE
    OrderID = @OrderID
ELSE
  RAISERROR (
    'Unable to delete Order ID %d because of error number %d.',
    @OrderID,
    @Error, 16, 1)

-- Listing 7-35: Tom's Coding Style
select
        o.CustomerID
,       Products        = sum (od.Quantity)
,       Sales           = sum (od.Quantity * od.Price)
from
        Orders          o
join    [Order Details] od      on      od.OrderID      = o.OrderID
join    Products        p       on      p.ProductID     = od.ProductID
where
        p.CategoryID    = 8  -- seafood
group by
        o.CustomerID
order by
        o.CustomerID

-- Listing 7-36: Itzik's Short Coding Style
SELECT * FROM T1

-- Listing 7-37: Itzik's Short-But-Not-Too-Short Coding Style
SELECT col1, col2, col3
FROM T1
WHERE col1 > 10
ORDER BY col1

-- Listing 7-38: Itzik's Long Coding Style
SELECT
 O.customerid,
 SUM(OD.quantity) AS total_qty,
 SUM(OD.quantity * OD.price) AS total_volume
FROM
 Orders AS O JOIN [Order Details] AS OD
  ON OD.orderid = O.orderid
 JOIN Products AS P
  ON P.productid = OD.ProductID
WHERE P.categoryid = 8
GROUP BY O.customerid
ORDER BY O.customerid

-- Listing 7-39: Syntax for BEGIN TRANSACTION
BEGIN TRAN [ SACTION ] [ transaction_name | @tran_name_variable
 [ WITH MARK [ 'description' ] ] ] 

-- Listing 7-40: Syntax for COMMIT TRAN and COMMIT WORK
COMMIT [ TRAN [ SACTION ] [ transaction_name | @tran_name_variable ] ]

COMMIT [ WORK ]

-- Listing 7-41: Syntax for ROLLBACK TRAN and ROLLBACK WORK
ROLLBACK [ TRAN [ SACTION ]
 [ transaction_name | @tran_name_variable
 | savepoint_name | @savepoint_variable ] ]

ROLLBACK [ WORK ]

-- Listing 7-42: Changing the Royalty Percentage inside a Transaction
BEGIN TRAN

UPDATE titleauthor
SET
  royaltyper = 60
WHERE
   au_id    = '213-46-8915'
  AND
   title_id = 'BU1032'

UPDATE titleauthor
SET
  royaltyper = 40
WHERE
    au_id    = '409-56-7008'
  AND
    title_id = 'BU1032'

COMMIT TRAN

-- Listing 7-43: Syntax for the SAVE TRANSACTION Statement
SAVE TRAN [ SACTION ] { savepoint_name | @savepoint_variable }

