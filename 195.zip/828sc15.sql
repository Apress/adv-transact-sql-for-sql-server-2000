---------------------------------------------------------------
-- Chapter 15 - Server-Side Cursors - The SQL of Last Resort --
---------------------------------------------------------------

-- Listing 15-1: DECLARE Syntax for SQL-92 Cursor
DECLARE cursor_name [INSENSITIVE] [SCROLL] CURSOR
FOR select_statement
[FOR {READ ONLY | UPDATE [OF column_name [,...n]]}]

-- Listing 15-2: DECLARE Syntax for Transact-SQL Cursor
DECLARE cursor_name CURSOR
[LOCAL | GLOBAL]
[FORWARD_ONLY | SCROLL]
[STATIC | KEYSET | DYNAMIC | FAST_FORWARD]
[READ_ONLY | SCROLL_LOCKS | OPTIMISTIC]
[TYPE_WARNING]
FOR select_statement
[FOR UPDATE [OF column_name [,...n]]]

-- Listing 15-3: DECLARE Syntax for Cursor Variable
DECLARE
  @cursor_variable CURSOR

-- Listing 15-4: SET Syntax for a Cursor
SET 
@cursor_variable = 
CURSOR
[FORWARD_ONLY | SCROLL]
[STATIC | KEYSET | DYNAMIC | FAST_FORWARD]
[READ_ONLY | SCROLL_LOCKS | OPTIMISTIC]
[TYPE_WARNING]
FOR select_statement 
[FOR {READ ONLY
| UPDATE [OF column_name [,...n]] } ]

-- Listing 15-5: FETCH Syntax
FETCH
[ [ NEXT | PRIOR | FIRST | LAST
| ABSOLUTE {n | @nvar}
| RELATIVE {n | @nvar}
]
FROM
]
{ { [GLOBAL] cursor_name } | @cursor_variable_name}
[INTO @variable_name[,...n] ]

-- Listing 15-6: CURSOR_STATUS() Function Syntax
CURSOR_STATUS
(
{'local', 'cursor_name'}
| {'global', 'cursor_name'}
| {'variable', 'cursor_variable'}
)

-- Listing 15-7: UPDATE Syntax
UPDATE <Table Name>
WHERE CURRENT OF <Cursor Name>

-- Listing 15-8: DELETE Syntax
DELETE <Table Name>
WHERE CURRENT OF <Cursor Name>
From the Trenches

-- Listing 15-9: CLOSE Syntax
CLOSE CRS
Using the DEALLOCATE Statement

-- Listing 15-10: DEALLOCATE Syntax
DEALLOCATE CRS

-- Listing 15-11: Stored Procedure with Cursor Parameter
CREATE PROC Contacts
(
  @crsContacts  CURSOR VARYING OUTPUT
)
AS
SET
  @crsContacts = CURSOR FAST_FORWARD
FOR
SELECT
  ContactName
FROM
    Customers

OPEN @crsContacts
GO

-- Listing 15-12: Calling a Stored Procedure with a Cursor Parameter
DECLARE
  @crs  CURSOR

EXEC Contacts
  @crs output

FETCH @crs

-- Listing 15-13: Setting Database Option 'Default to Local Cursor'
ALTER DATABASE MyDB
SET
  CURSOR_DEFAULT LOCAL

EXEC sp_dboption
  'MyDB',
  'default to local cursor',
  'true'

-- Listing 15-14: Example of OPENROWSET Call to Stored Procedure
DECLARE c CURSOR FOR
SELECT
  *
FROM
    OPENROWSET
    (
      'SQLOLEDB',
      "DRIVER={SQL Server};SERVER=(local);Trusted_Connection=yes",
      "SET FMTONLY OFF EXEC sp_who2"
    )

-- Listing 15-15: Finding the Median
DECLARE
  @Quantity   int,
  @Quantity2  int,
  @Median     float,
  @Row        int

DECLARE c SCROLL CURSOR FOR
SELECT
  SUM (Quantity)
FROM
    [Order Details]
GROUP BY
  OrderID
ORDER BY
  SUM (Quantity)

OPEN c

FETCH LAST FROM c INTO
  @Quantity

IF @@CURSOR_ROWS % 2 = 1    -- odd number of rows
BEGIN
  PRINT 'Odd'

  SET
    @Row    = CAST (@@CURSOR_ROWS + 1 AS int) / 2

  FETCH ABSOLUTE @row FROM c INTO
    @Quantity

  SET
    @Median    = CAST (@Quantity AS float)
END
ELSE                -- even number of rows
BEGIN
  PRINT 'Even'

 SET
    @Row    = @@CURSOR_ROWS / 2

 FETCH ABSOLUTE @row FROM c INTO
   @Quantity

 FETCH NEXT FROM c INTO
   @Quantity2

 SET
   @Median    = (@Quantity + @Quantity2) / 2.0
END

CLOSE c
DEALLOCATE c

SELECT
  Median    = @Median

-- Listing 15-16: Selecting the Top Ten Orders by Quantity
SELECT TOP 10
  OrderID,
  Quantity    = SUM (Quantity)
FROM
    [Order Details]
GROUP BY
  OrderID
ORDER BY
  Quantity DESC

-- Listing 15-17: Finding the Eighth, Ninth, and Tenth Highest Orders by Quantity
SELECT TOP 3
  OrderID,
  Quantity
FROM
(
    SELECT TOP 10
      OrderID,
      Quantity = SUM (Quantity)
    FROM
      [Order Details]
    GROUP BY
      OrderID
    ORDER BY
      Quantity  DESC
)    q
ORDER BY
  Quantity  ASC

-- Listing 15-18: Finding Customers Who Place Orders through the Same Employee
SELECT
  CustomerID
FROM
    Orders
GROUP BY
  CustomerID
HAVING
  MIN (EmployeeID) = MAX (EmployeeID)

-- Listing 15-19: Finding the First Order Date for every Third Month
SELECT
  MIN (OrderDate)
FROM
    Orders
WHERE
    MONTH (OrderDate) % 3 = 0
GROUP BY
  YEAR (OrderDate),
  MONTH (OrderDate)
ORDER BY
  MIN (OrderDate)

-- Listing 15-20: Finding the Next Row
SELECT
  @OrderID = MIN (OrderID)
FROM
    Orders
WHERE
    OrderID > @OrderID

-- Listing 15-21: Cursor on a Single-Column Key
DECLARE
  @OrderID    int,
  @Count      int,
  @DateTime   datetime

SELECT                     -- initialize
  @Count    = 0,
  @DateTime = GETDATE ()

DECLARE c CURSOR FOR       -- set up cursor
SELECT
  OrderID
FROM
    Orders

OPEN c

FETCH c INTO               -- get first order
  @OrderID

WHILE @@FETCH_STATUS = 0   -- loop through orders
BEGIN
  SET
    @Count = @Count + 1    -- increment counter

  FETCH c INTO             -- pick up next order
    @OrderID
END

CLOSE c                    -- clean up
DEALLOCATE c

-- show the time difference
SELECT
  @Count,
  DATEDIFF (ms, @DateTime, GETDATE ())

-- Listing 15-22: WHILE Loop on a Single-Column Key
DECLARE
  @OrderID    int,
  @Count      int,
  @DateTime   datetime

SELECT                     -- initialize
  @Count    = 0,
  @DateTime = GETDATE ()

SELECT                     -- get first order ID
  @OrderID  = MIN (OrderID)
FROM
    Orders

WHILE @OrderID IS NOT NULL -- loop through orders
BEGIN
  SET                      -- increment counter
    @Count    = @Count + 1

  SELECT                   -- get next order ID
    @OrderID    = MIN (OrderID)
  FROM
      Orders
  WHERE
      OrderID    > @OrderID    
END

-- show the time difference
SELECT
  @Count,
  DATEDIFF (ms, @DateTime, GETDATE ())

-- Listing 15-23: Cursor on Multiple-Column Key
DECLARE
  @Quantity    float,
  @Count       int,
  @DateTime    datetime

SELECT                     -- initialize
  @Count    = 0,
  @DateTime = GETDATE ()

DECLARE c CURSOR FOR       -- set up cursor
SELECT
  Quantity
FROM
    [Order Details]

OPEN c

FETCH c INTO               -- pick up first order detail
  @Quantity

WHILE @@FETCH_STATUS = 0   -- loop through order details
BEGIN
  SET
    @Count = @Count + 1    -- increment counter

  FETCH c INTO             -- pick up next order detail
    @Quantity
END

CLOSE c                    -- clean up
DEALLOCATE c

-- show the time difference
SELECT
  @Count,
  DATEDIFF (ms, @DateTime, GETDATE ())

-- Listing 15-24: WHILE Loop for Multiple-Column Key
DECLARE
  @OrderID    int,
  @ProductID  int,
  @Count      int,
  @DateTime   datetime

SELECT                          -- initialize
  @Count     = 0,
  @DateTime  = GETDATE ()

SELECT                          -- get first order ID
  @OrderID   = MIN (OrderID)
FROM
    [Order Details]

WHILE @OrderID IS NOT NULL      -- loop through orders
BEGIN
  SELECT                        -- pick up first product ID for this order ID
    @ProductID = MIN (ProductID)
  FROM
      [Order Details]
  WHERE
      OrderID = @OrderID

  WHILE @ProductID IS NOT NULL  -- loop through product IDs for this order ID
  BEGIN
    SET
      @Count = @Count + 1       -- increment counter

    SELECT                      -- get next product ID for this order ID
      @ProductID    = MIN (ProductID)
    FROM
        [Order Details]
    WHERE
        OrderID      = @OrderID
    AND
        ProductID    > @ProductID
  END

  SELECT                        -- pick up next order ID
    @OrderID    = MIN (OrderID)
  FROM
      [Order Details]
  WHERE
      OrderID    > @OrderID    
END

-- show the time difference
SELECT
  @Count,
  DATEDIFF (ms, @DateTime, GETDATE ())

-- Listing 15-25: Example of sp_MSForEachDB
sp_MSForEachDB
  "print '?' DBCC CHECKCATALOG (?)"

-- Listing 15-26: Example of sp_MSForEachTable
sp_MSForEachTable
  'print "?" exec sp_spaceused "?"',
  @whereand = 'and name like "Order%"'

