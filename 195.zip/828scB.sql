------------------------------------------------------------------------
-- Appendix B - Checking for ANSI Compatibility with SET FIPS_FLAGGER --
------------------------------------------------------------------------

-- Listing B-1: Using the SET FIPS_FLAGGER Command
SET FIPS_FLAGGER level

-- Listing B-2: Checking for Full ANSI SQL-92 Compliance � Syntax
SET FIPS_FLAGGER 'FULL'

-- Listing B-3: Checking for Full ANSI SQL-92 Compliance � Result
FIPS Warning: Line 1 has the non-ANSI statement 'SET'.

-- Listing B-4: ANSI SQL-92 Compliant Query
SELECT
  *
FROM
  Authors

-- Listing B-5: Non-ANSI SQL-92 Compliant Query
SELECT
  TOP 5 *
FROM
  Authors
ORDER BY
  au_id

-- Listing B-6: Warning for Non-ANSI SQL-92 Compliant Query
FIPS Warning: Line 2 has the non-ANSI clause 'TOP'.

-- Listing B-7: Turning Off ANSI-Compliance Checking
SET FIPS_FLAGGER OFF
