------------------------------------------------
-- Chapter 4 - Other Data Manipulation Issues --
------------------------------------------------

-- Listing 4-1: Syntax for the Simple CASE Expression
SELECT
  CASE <expression>
    WHEN <expression1a> THEN <expression1b>
    WHEN <expression2a> THEN <expression2b>
    ...
    ELSE ValueN
  END
FROM
    Table1

-- Listing 4-2: Example of a Simple CASE Expression
SELECT
  ProductID,
  ProductName,
  CategoryID,
  UnitPrice AS 'Old Price',
  UnitPrice *
    CASE CategoryID
      WHEN 6 THEN 1.10
      WHEN 7 THEN 1.20
      WHEN 8 THEN 1.25
      ELSE        1.00
    END     AS 'New Price'
FROM
    Products
WHERE
    SupplierID = 4

-- Listing 4-3: Syntax for the Searched CASE Expression
SELECT
  CASE
    WHEN <expression1a> THEN <expression1b>
    WHEN <expression2a> THEN <expression2b>
    ...
    ELSE ValueN
  END
FROM
    Table1

-- Listing 4-4: Example of a Searched CASE Expression
SELECT
  CustomerID,
  COUNT (*) AS 'Orders',
  CASE
    WHEN COUNT (*) BETWEEN  1 AND 10 THEN '*'
    WHEN COUNT (*) BETWEEN 11 AND 20 THEN '**'
    WHEN COUNT (*) BETWEEN 21 AND 30 THEN '***'
    ELSE '****'
  END       AS 'Rating'
FROM
    Orders
GROUP BY
  CustomerID

-- Listing 4-5: Using a CASE Expression in an ORDER BY Clause
SELECT
  *
FROM
    Customers
ORDER BY
  CASE Country
    WHEN 'Canada' THEN char (1)
    WHEN 'USA'    THEN char (2)
    WHEN 'Mexico' THEN char (3)
    ELSE Country
  END,
  Region

-- Listing 4-6: Using a CASE Expression in an ORDER BY Clause (Alternative)
SELECT
  *
FROM
  Customers
ORDER BY
  CASE Country
    WHEN 'Canada' THEN 1
    WHEN 'USA'    THEN 2
    WHEN 'Mexico' THEN 3
    ELSE               4
  END,     -- Dummy NAFTA Region
  Country,
  Region

-- Listing 4-7: UPDATE Using a CASE Expression
UPDATE Products
SET
  UnitPrice = UnitPrice *
    CASE CategoryID
      WHEN 6 THEN 1.10
      WHEN 7 THEN 1.20
      WHEN 8 THEN 1.25
      ELSE        1.00
    END
WHERE
    SupplierID = 4

-- Listing 4-8: Example of a Pivot Table Query
SELECT
  O.CustomerID,
  SUM (CASE WHEN P.CategoryID = 6
            THEN OD.Quantity
            ELSE 0 END)  AS MeatUnits,
  SUM (CASE WHEN P.CategoryID = 8
            THEN OD.Quantity
            ELSE 0 END)  AS SeafoodUnits
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID  = O.OrderID
  JOIN
    Products        AS P  ON P.ProductID = OD.ProductID
WHERE
    P.CategoryID    IN (6, 8)  -- Meat, Seafood
GROUP BY
  O.CustomerID
ORDER BY
  O.CustomerID

-- Listing 4-9: Finding the Total Sales
SUM (CASE WHEN P.CategoryID = 6
          THEN OD.Quantity * P.UnitPrice
          ELSE 0 END)  AS MeatSales

-- Listing 4-10: Finding the Number of Items
SUM (CASE WHEN P.CategoryID = 6
          THEN 1
          ELSE 0 END)  AS MeatItems

-- Listing 4-11: Finding the Distinct Meat Orders
COUNT (DISTINCT
       CASE WHEN P.CategoryID = 6
            THEN O.OrderID
            ELSE NULL END)  AS MeatOrders

-- Listing 4-12: TOP n Query
SELECT TOP 6
  *
FROM
  sales

-- Listing 4-13: TOP n Query with ORDER BY
SELECT TOP 6
  *
FROM
  sales
ORDER BY
  qty DESC

-- Listing 4-14: TOP n WITH TIES Query
SELECT TOP 6 WITH TIES
  * 
FROM
  sales
ORDER BY
  qty DESC

-- Listing 4-15: Authors That Did Not Get a Bonus
SELECT
  au_lname,
  au_fname,
  S.title_id,
  title
FROM
    sales       AS S
  JOIN
    titleauthor AS TA ON S.title_id  = TA.title_id
  JOIN
    authors     AS A  ON TA.au_id    = A.au_id
  JOIN
    titles      AS T  ON TA.title_id = T.title_id
WHERE
  S.title_id IN ('BU1111', 'PS2106', 'PS7777')

-- Listing 4-16: TOP 10 PERCENT Query
SELECT TOP 10 PERCENT
  * 
FROM
  sales
ORDER BY
  qty DESC

-- Listing 4-17: Syntax for SET ROWCOUNT
SET ROWCOUNT n

-- Listing 4-18: Resetting ROWCOUNT
SET ROWCOUNT 0

-- Listing 4-19: Using the SET ROWCOUNT Option
SET ROWCOUNT 6

SELECT
  * 
FROM
  sales
ORDER BY
  qty DESC

SET ROWCOUNT 0

-- Listing 4-20: Illegal Use of Expression
SELECT
  col1,
  col2,
  (col1 = col2) AS equale
FROM
  T1

-- Listing 4-21: Use Logical Expressions in a SELECT Statement
SELECT
  <select_column_list>
FROM 
    T1
  JOIN
    T2 ON <logical_expression>
WHERE
  <logical_expression>
GROUP BY
  <group_by_column_list>
HAVING
  <logical_expression>
ORDER BY
  <order_by_column_list>

-- Listing 4-22: Use of a Logical Expression In an IF Statement
IF <logical_expression>
  <statement or statement_block>

-- Listing 4-23: Use of a Logical Expression In a WHILE Statement
WHILE <logical_expression>
  <statement or statement_block>

-- Listing 4-24: Use of Logical Expressions In a CASE Query
CASE
  WHEN <logical_expression1> THEN value1
  WHEN <logical_expression2> THEN value2
  ...
  ELSE valuen
END

-- Listing 4-25: Using an Expression with an Explicit Unknown Value
IF 1 = NULL
  PRINT 'TRUE'
ELSE
  PRINT 'FALSE or UNKNOWN'

-- Listing 4-26: Using an Expression with an Unknown Value Returned From One of the Participating Simple Logical Expressions
IF (1 = 1) AND (1 > NULL)
  PRINT 'TRUE'
ELSE
  PRINT 'FALSE or UNKNOWN'

-- Listing 4-27: The Wrong Way to Look for NULLs
SELECT
  *
FROM
  Personnel
WHERE
  salary = NULL

-- Listing 4-28: The Right Way to Look for NULLs
SELECT
  *
FROM
  Personnel
WHERE
  salary IS NULL

-- Listing 4-29: The Right Way to Look for non-NULLs
SELECT
  *
FROM
  Personnel
WHERE
  salary IS NOT NULL

-- Listing 4-30: Short Circuit Using the AND Operator 
 (1 = 0) AND (1=1)

-- Listing 4-31: Short Circuit and Divide By Zero Using the AND Operator
IF (0 <> 0) AND (1/0 > 0)
  PRINT 'Greater Than 0' 

-- Listing 4-32: Short Circuit and Divide By Zero Using the OR Operator
IF (1 > 0) OR (1/0 > 0)
  PRINT 'Greater Than 0'

-- Listing 4-33: Schema Creation Script for the T1 Table
CREATE TABLE T1(
col1 int NOT NULL,
col2 int NOT NULL)

INSERT INTO T1 VALUES(1, 1)
INSERT INTO T1 VALUES(1, 0)
INSERT INTO T1 VALUES(-1, 1)

-- Listing 4-34: All Rows From T1, Where col1 / col2 is Greater than Zero�First Try
SELECT
  *
FROM
  T1
WHERE
    (col1 / col2 > 0)

-- Listing 4-35: All Rows From T1, Where col1 / col2 is Greater than Zero�Second Try
SELECT
  *
FROM
  T1
WHERE
    (col2 <> 0)
  AND
    (col1 / col2 > 0)

-- Listing 4-36: Showplan Output for All Rows From T1, Where col1 / col2 is Greater than Zero�Second Try
|--Table Scan(OBJECT:([testdb].[dbo].[T1]),
              WHERE:([T1].[col2]<>0 AND [T1].[col1]/[T1].[col2]>0))

-- Listing 4-37: All Rows From T1, Where col1 / col2 is Greater than Zero�Try 3
SELECT
  *
FROM
  T1
WHERE
    (col1 / col2 > 0)
  AND
    (col2 <> 0)

-- Listing 4-38: Showplan Output for All Rows From T1, Where col1 / col2 is Greater than Zero�Third Try
|--Table Scan(OBJECT:([testdb].[dbo].[T1]),
              WHERE:([T1].[col2]<>0 AND [T1].[col1]/[T1].[col2]>0))

-- Listing 4-39: All Rows From T1, Where col1 / col2 is Greater than Zero�Fourth Try
SELECT
  *
FROM
  T1
WHERE
  CASE
    WHEN col2 = 0        THEN 0
    WHEN col1 / col2 > 0 THEN 1
    ELSE 0
  END = 1

-- Listing 4-40: Illegal Bitwise Operation:
SELECT
    0x00000001
  &
    0x00000001

-- Listing 4-41: Legal Bitwise Operation:
SELECT
    CAST(0x00000001 AS int)
  &
    0x00000001

-- Listing 4-42: Finding Out if the First Bit Is Turned On, Behind the Scenes
  10101010 -- 170
&
  00000001 -- 1
  --------
  00000000 -- 0

-- Listing 4-43: Finding Out if the Second Bit Is Turned On, Behind the Scenes
  10101010 -- 170
&
  00000010 -- 2
  --------
  00000010 -- 2

-- Listing 4-44: Finding Out if the Second Bit is Turned On, Using T-SQL
SELECT
  170 & 2

-- Listing 4-45: Retrieving Index Properties by Using the Bitwise AND (&) Operator
SELECT
  object_name([id]) AS table_name,
  [indid] AS index_id,
  [name] as index_name,
  status,
  CASE
    WHEN status & 2 = 2 THEN 'Yes'
    ELSE 'No'
  END AS is_unique,
  CASE
    WHEN status & 16 = 16 THEN 'Yes'
    ELSE 'No'
  END AS is_clustered,
  CASE
    WHEN status & 2048 = 2048 THEN 'Yes'
    ELSE 'No'
  END AS is_PK_CNS,
  CASE
    WHEN status & 4096 = 4096 THEN 'Yes'
    ELSE 'No'
  END AS is_UNQ_CNS
FROM
  sysindexes
WHERE
  indid BETWEEN 1 AND 254 -- clustered and nonclustered indexes
ORDER BY
  table_name,
  index_id

-- Listing 4-46: Combining Multiple Flags Using the Bitwise OR Operator, Behind the Scenes
  00000001 -- 1
|
  00000010 -- 2
|
  00000100 -- 4
|
  00001000 -- 8
  --------
  00001111 -- 1+2+4+8 = 15

-- Listing 4-47: Combining Multiple Flags Using the Bitwise OR Operator, in T-SQL
SELECT
  1 | 2 | 4 | 8

-- Listing 4-48: Use of a Complex Expression in the WHERE Clause�First Try
SELECT
  *
FROM
  Orders
WHERE
    CustomerID IN ('VINET', 'TOMSP', 'HANAR')
  AND
    EmployeeID = 3
  OR
    EmployeeID = 4
  AND
    ShipVia = 3

-- Listing 4-49: Use of a Complex Expression in the WHERE Clause�Second Try
SELECT
  *
FROM
  Orders
WHERE
      CustomerID IN ('VINET', 'TOMSP', 'HANAR')
    AND
      EmployeeID = 3
  OR
      EmployeeID = 4
    AND
      ShipVia = 3

-- Listing 4-50: Use of a Complex Expression in the WHERE Clause�Third Try
SELECT
  *
FROM
  Orders
WHERE
    (  
       CustomerID IN ('VINET', 'TOMSP', 'HANAR')
    AND
       (
          EmployeeID = 3
      OR
          EmployeeID = 4
       )
    )
  AND
    ShipVia = 3

-- Listing 4-51: Syntax for the STR() Function
STR (float_expression[, length[, decimal]])

-- Listing 4-52: Syntax for the REPLACE() Function
REPLACE ('string_expression1', 'string_expression2', 'string_expression3')

-- Listing 4-53: Sample Code for Numerics with Leading Zeroes
SELECT
  REPLACE (STR (25, 8, 2), ' ', '0') AS TwentyFive

-- Listing 4-54: Syntax for the DATEPART() Function
DATEPART (datepart, date)

-- Listing 4-55: Examples of DATEPART(), YEAR(), MONTH(), and DAY() Functions
SELECT
  DATEPART (yy, getdate ()),
  DATEPART (mm, getdate ()),
  DATEPART (dd, getdate ())

SELECT
  YEAR (getdate ()),
  MONTH (getdate ()),
  DAY (getdate ())

-- Listing 4-56: Finding Orders Broken Down by Year and Month
SELECT
  YEAR (OrderDate)         AS 'Year',
  MONTH (OrderDate)        AS 'Month',
  DATENAME (mm, OrderDate) AS 'Month Name',
  COUNT (*)                AS 'Count'
FROM
  Orders
GROUP BY
  YEAR (OrderDate),
  MONTH (OrderDate),
  DATENAME (mm, OrderDate)
ORDER BY
  YEAR (OrderDate),
  MONTH (OrderDate)

-- Listing 4-57: DATEADD() Function Syntax
DATEADD (datepart, number, date)

-- Listing 4-58: Using the DATEADD() Function
SELECT
  DATEADD (dd, 5, GETDATE ())

-- Listing 4-59: Adding to a Date Using the Addition Operator
SELECT
  GETDATE () + 1.5

-- Listing 4-60: DATEDIFF() Function Syntax
DATEDIFF (datepart, startdate, enddate)

-- Listing 4-61: WHERE Clause for a Date Range Search
WHERE
    SalesDateTime BETWEEN '1Jul2000' and '31Jul2000'

-- Listing 4-62: Correct WHERE Clause for a Date Search
WHERE
    SalesDateTime >= '1Jul2000'
AND SalesDateTime <  '1Aug2000'

-- Listing 4-63: CONVERT() Function Syntax
CONVERT (data_type[(length)], expression [, style])

-- Listing 4-64: Calculating the First Day of the Month
SELECT
  CONVERT (char (6), OrderDate, 112) + '01'
FROM
    Orders

-- Listing 4-65: Calculating the Month End
SELECT
  DATEADD (dd, -1,
    DATEADD (mm, 1,
      CONVERT (char (6), OrderDate, 112) + '01'))
FROM
    Orders

-- Listing 4-66: Calculating Month Name from Month Number
SELECT
  DATENAME (mm, '2000' + REPLACE (STR (@Month, 2, 2), ' ', '0')  + '01')

-- Listing 4-67: Generating a Date in YYYYMMDD Format
SELECT
  STR (2000, 4) + STR (10, 2) + REPLACE (STR (1, 2), ' ', '0') AS 'Date'

-- Listing 4-68: Sample Code for the GETUTCDATE() Function.
SELECT
  GETUTCDATE()
