-------------------------------------------------
-- Chapter 6 - Special Datatypes and Properties--
-------------------------------------------------

-- Listing 6-1: Syntax for NCHAR()
NCHAR ( integer_expression )

-- Listing 6-2: Using NCHAR()
SELECT
 NCHAR (252)

-- Listing 6-3: Syntax for UNICODE ()
UNICODE ( 'ncharacter_expression' )

-- Listing 6-4: Using UNICODE()
SELECT
 UNICODE ('�')

-- Listing 6-5: Using a Table with a rowversion Column
CREATE TABLE MyTable
(
  DataValue int        NOT NULL,
  RowVer    rowversion NOT NULL
)
GO

INSERT MyTable (DataValue) VALUES (1)
INSERT MyTable (DataValue) VALUES (2)
INSERT MyTable (DataValue) VALUES (3)
INSERT MyTable (DataValue) VALUES (4)
GO

-- Listing 6-6: Updating a Row in a Table with a rowversion Column
UPDATE MyTable
SET
  DataValue = 10
WHERE
  DataValue = 3
GO

SELECT
  *
FROM
  MyTable
WHERE
  RowVer =
(
  SELECT
    MAX (RowVer)
  FROM
    MyTable
)
GO

-- Listing 6-7: Turning on ''text in row''
sp_tableoption
 'MyTable',
 'text in row',
 'ON'

-- Listing 6-8: Setting a ''text in row'' Limit
sp_tableoption
 'MyTable',
 'text in row',
 '1000'

-- Listing 6-9: Turning Off 'tText in rRow'
sp_tableoption
 'MyTable',
 'text in row',
 'OFF'

-- Listing 6-10: Sample Table Containing Text
CREATE TABLE MyTextTable
(
 id int NOT NULL PRIMARY KEY,
 txt text NULL
)
GO

EXEC sp_tableoption 'MyTextTable', 'text in row', '1000'
GO

INSERT MyTextTable
 VALUES (1, NULL)

UPDATE MyTextTable
SET
 txt = REPLICATE ('x', 1000)

-- Listing 6-11: Syntax for sp_invalidate_textptr
sp_invalidate_textptr [ [ @TextPtrValue = ] textptr_value ]

-- Listing 6-12: Syntax for the TEXTPTR() Function
TEXTPTR ( column )

-- Listing 6-13: Syntax for TEXTVALID() Function
TEXTVALID ( 'table.column' , text_ptr )

-- Listing 6-14: Syntax for the READTEXT Statement
READTEXT { table.column text_ptr offset size } [ HOLDLOCK ]

-- Listing 6-15: Sample Code for READTEXT
DECLARE
 @ptr varbinary (16)

SELECT
 @ptr = TEXTPTR (pr_info)
FROM
  pub_info
WHERE
  pub_id = 9999

READTEXT pub_info.pr_info @ptr 223 47

-- Listing 6-16: Syntax for WRITETEXT Statement
WRITETEXT { table.column text_ptr } 
 [ WITH LOG ] { data }

-- Listing 6-17: Sample Code for WRITETEXT
DECLARE
 @ptr varbinary (16)

SELECT
 @ptr = TEXTPTR (pr_info)
FROM
  pub_info
WHERE
  pub_id = 9999


-- Listing 6-18: Syntax for UPDATETEXT
UPDATETEXT { table_name.dest_column_name dest_text_ptr }
 { NULL | insert_offset }
 { NULL | delete_length }
 [ WITH LOG ]
 [ inserted_data
  | { table_name.src_column_name src_text_ptr } ]

-- Listing 6-19: Using UPDATETEXT to Insert Data
DECLARE
 @ptr varbinary (16)

SELECT
 @ptr = TEXTPTR (HomePage)
FROM
  Suppliers
WHERE
  SupplierID = 6

UPDATETEXT Suppliers.HomePage @ptr 17 0 'Venerable '

-- Listing 6-20: Using UPDATETEXT to Update Data
DECLARE
 @ptr varbinary (16)

SELECT
 @ptr = TEXTPTR (HomePage)
FROM
  Suppliers
WHERE
  SupplierID = 6

UPDATETEXT Suppliers.HomePage @ptr 28 3 'Wait'

-- Listing 6-21: Using UPDATETEXT to Delete Data
DECLARE
 @ptr varbinary (16)

SELECT
 @ptr = TEXTPTR (HomePage)
FROM
  Suppliers
WHERE
  SupplierID = 6

UPDATETEXT Suppliers.HomePage @ptr 17 11

-- Listing 6-22: Syntax for SET TEXTSIZE
SET TEXTSIZE { number | @number_var }

-- Listing 6-23: Sample Table Using the uniqueidentifier and NEWID() Function
CREATE TABLE MyTable
(
 PK_ID     uniqueidentifier NOT NULL
                 PRIMARY KEY
                 DEFAULT (NEWID ()),
 CustomerName char (30)     NOT NULL
)
GO

INSERT MyTable (Name) VALUES ('Fred')
INSERT MyTable (Name) VALUES ('Wilma')

-- Listing 6-24: Syntax for the SQL_VARIANT_PROPERTY() Function
SQL_VARIANT_PROPERTY (expression, property)

-- Listing 6-25: Sample DECLARE Statement for a table Variable
DECLARE
 @MyTable table
      (
       ItemID    int       PRIMARY KEY,
       Descr     char (20) NOT NULL,
       Quantity   smallint  NOT NULL
                           CHECK (quantity < 20)
      )

-- Listing 6-26: Sample INSERT into a table Variable
INSERT @MyTable VALUES (1, 'Widget', 15)
INSERT @MyTable VALUES (2, 'Gizmo', 10)
INSERT @MyTable VALUES (3, 'Thingy', 12)

-- Listing 6-27: Sample SELECT from a table Variable
SELECT
 *
FROM
  @MyTable

-- Listing 6-28: Syntax for Creating a Table with an IDENTITY Column
CREATE TABLE <table_name>
(
 <col_name> <datatype> NOT NULL IDENTITY[(seed, increment)],
...other columns...
)

-- Listing 6-29: Schema Creation Script for the Identable Table
CREATE TABLE Identable
(
 key_col int   NOT NULL IDENTITY (1,1),
 abc   char(1) NOT NULL
)

INSERT INTO Identable VALUES ('a')
INSERT INTO Identable VALUES ('b')
INSERT INTO Identable VALUES ('c')

-- Listing 6-30: Retrieving the Initial Identable's Content
SELECT
 *
FROM
 Identable
ORDER BY
 key_col

-- Listing 6-31: Using the IDENTITYCOL Keyword
SELECT
 IDENTITYCOL,
 abc
FROM
 Identable

-- Listing 6-32: Deleting and Inserting Rows from Identable
DELETE FROM Identable
WHERE
 key_col = 2

INSERT INTO Identable VALUES ('d')

SELECT
 *
FROM
 Identable
ORDER BY
 key_col

-- Listing 6-33: Inserting a Row into Identable and Rolling Back the Transaction
BEGIN TRAN
 INSERT INTO Identable VALUES ('e')
ROLLBACK TRAN

INSERT INTO Identable VALUES ('f')

SELECT
 *
FROM
 Identable
ORDER BY
 key_col

-- Listing 6-34: Retrieving the Seed and Increment Values
SELECT
 IDENT_SEED ('Identable') AS seed,
 IDENT_INCR ('Identable') AS increment
Using the IDENTITY_INSERT Session Option

-- Listing 6-35: Using the IDENTITY_INSERT Option
SET IDENTITY_INSERT Identable ON

INSERT INTO Identable (key_col, abc) VALUES(2, 'g')

SELECT
 *
FROM
 Identable
ORDER BY
 key_col
GO

SET IDENTITY_INSERT Identable OFF

-- Listing 6-36: Inserting a New Row into Identable
INSERT INTO Identable VALUES ('g')

-- Listing 6-37: Retrieving the @@IDENTITY Value
SELECT
 @@IDENTITY

-- Listing 6-38: Saving the @@IDENTITY Value in a Variable
DECLARE @mylastident AS int
SET @mylastident = @@IDENTITY
PRINT @mylastident

-- Listing 6-39: Saving the SCOPE_IDENTITY() Value in a Variable
DECLARE @mylastident AS int
SET @mylastident = SCOPE_IDENTITY ()
PRINT @mylastident

-- Listing 6-40: Retrieving the Maximum Value of key_col from Identable
SELECT
 MAX (key_col) AS max_key_col
FROM
 Identable

-- Listing 6-41: Retrieving the IDENT_CURRENT() Value
SELECT
 IDENT_CURRENT ('Identable')

-- Listing 6-42: Syntax for Retrieving the Current IDENTITY Value of a Table and the Correct Value
DBCC CHECKIDENT ('table_name', NORESEED)

-- Listing 6-43: Retrieving the Current IDENTITY Value of the Table Identable and Its Correct Value
DBCC CHECKIDENT ('Identable', NORESEED)

Checking identity information: current identity value '7',
                current column value '7'.
DBCC execution completed. If DBCC printed error messages,
 contact your system administrator.

-- Listing 6-44: Reseeding the IDENTITY Value
DBCC CHECKIDENT ('table_name', RESEED)

-- Listing 6-45: Syntax for Reseeding the IDENTITY Value with a New Explicit Value
DBCC CHECKIDENT ('table_name', RESEED, new_reseed_value) 

-- Listing 6-46: Reseeding the IDENTITY Value of Identable with a New Explicit Value
DBCC CHECKIDENT ('Identable', RESEED, 50) 

-- Listing 6-47: Inserting a New Row into Identable
INSERT INTO Identable VALUES('h')

SELECT
 *
FROM
 Identable
ORDER BY
 key_col

-- Listing 6-48: Syntax for Using the IDENTITY() Function
SELECT
 IDENTITY(<data_type> [, <seed>, <increment>]) AS column_name,
 <other_columns>
INTO
 <new_table_name>
FROM
 <table_name>
WHERE
 <search_criteria>

-- Listing 6-49: Query that Returns Result Row Numbers, Starting with 1 and Incremented by 1
SELECT
 (SELECT
   COUNT (*)
  FROM
   Identable AS T2
  WHERE
   T2.abc <= T1.abc) AS rownum,
 abc
FROM
 Identable AS T1
ORDER BY
 abc

-- Listing 6-50: Query that Returns Result Row Numbers, Starting with 1 and Incrementinged by 3
SELECT
 1 +
 3 *
 (SELECT
   count(*)
  FROM
   Identable AS T2
  WHERE
   T2.abc < T1.abc) AS rownum,
 abc
FROM
 Identable AS T1
ORDER BY
 abc

-- Listing 6-51: Storing the Results in a Temporary Table Using the IDENTITY() Function
SELECT
 IDENTITY (int , 1, 1) AS rownum,
 abc
INTO
 #temp
FROM
 Identable
ORDER BY
 abc

-- Listing 6-52: Retrieving the Results of Using the IDENTITY() Function from the Temporary Table
SELECT
 *
FROM
 #temp
ORDER BY
 Abc

