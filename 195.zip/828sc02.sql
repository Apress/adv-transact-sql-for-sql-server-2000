-----------------------------------------------
-- Chapter 2 - Subqueries and Derived Tables --
-----------------------------------------------

-- Listing 2-1: Finding the Date of the Last Order
SELECT
  MAX (OrderDate)
FROM
    Orders

-- Listing 2-2: Finding the Most-Recent Orders
SELECT
  *
FROM
    Orders
WHERE
    OrderDate =
(
  SELECT
    MAX (OrderDate)
  FROM
      Orders
)

-- Listing 2-3: Finding the Difference Between Price and Average Price
SELECT
  ProductID,
  UnitPrice  -
  (
    SELECT
      AVG (UnitPrice)
    FROM
        Products
  ) AS Difference
FROM
    Products

-- Listing 2-4: Using the IN Predicate as a Subquery
SELECT
  COUNT (*)
FROM
    Orders
WHERE
    CustomerID IN
(
  SELECT
    CustomerID
  FROM
      Customers
  WHERE
      Country = 'UK'
)

-- Listing 2-5: The IN Predicate Flattened into a Join
SELECT
  COUNT (*)
FROM
    Orders    AS O
  JOIN
    Customers AS C ON C.CustomerID = O.CustomerID
WHERE
    C.Country = 'UK'

-- Listing 2-6: Using the NOT IN Predicate as a Subquery
SELECT
  COUNT (*)
FROM
    Orders
WHERE
    CustomerID NOT IN
(
  SELECT
    CustomerID
  FROM
      Customers
  WHERE
      Country = 'UK'
)

-- Listing 2-7: Example of a Correlated Subquery
SELECT
  O.*
FROM
    Orders AS O
WHERE
    36 <
(
  SELECT
    OD.Quantity
  FROM
      [Order Details] AS OD
  WHERE
      OD.ProductID = 17
    AND
      OD.OrderID   = O.OrderID  -- here is the correlation
)

-- Listing 2-8: Equivalent Join Query
SELECT
  O.*
FROM
    Orders          AS O
JOIN
    [Order Details] AS OD ON OD.OrderID = O.OrderID
WHERE
    OD.Quantity  > 36
AND
    OD.ProductID = 17

-- Listing 2-9: Correlated Subquery to Show Price Difference
SELECT
  P.ProductID,
  P.UnitPrice,
  P.UnitPrice -
(
  SELECT
    AVG (A.UnitPrice)
  FROM
      Products AS A
  WHERE
      A.CategoryID = P.CategoryID
  GROUP BY
    A.CategoryID
)  AS Difference
FROM
    Products AS P

-- Listing 2-10: Using a Correlated Subquery on the HAVING Predicate
SELECT
  OD1.ProductID,
  OD1.OrderID
FROM
    [Order Details] AS OD1
GROUP BY
  OD1.ProductID,
  OD1.OrderID
HAVING
  SUM (OD1.Quantity) > 3 *
(
  SELECT
    AVG (OD2.Quantity)
  FROM
      [Order Details] AS OD2
  WHERE
      OD2.ProductID = OD1.ProductID
)

-- Listing 2-11: Example of a Correlated Subquery Using an EXISTS Predicate
SELECT
    C.ContactName
FROM
    Customers AS C
WHERE EXISTS
(
  SELECT
    *
  FROM
      Orders          AS O
    JOIN
      [Order Details] AS OD ON OD.OrderID = O.OrderID
  WHERE
      OD.ProductID = 64
    AND
      O.CustomerID = C.CustomerID
)

-- Listing 2-12: Example of a Correlated Subquery Using COUNT(*)
SELECT
  C.ContactName
FROM
    Customers AS C
WHERE
    0 <
(
  SELECT
    COUNT (*)
  FROM
      Orders          AS O
    JOIN
      [Order Details] AS OD ON OD.OrderID = O.OrderID
  WHERE
      OD.ProductID = 64
    AND
      C.CustomerID = O.CustomerID
)

-- Listing 2-13: Correlated Subquery with NOT EXISTS Predicate
SELECT
  C.*
FROM
    Customers AS C
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Orders AS O
  WHERE
      O.CustomerID = C.CustomerID
)

-- Listing 2-14: Equivalent Subquery with NOT IN
SELECT
  *
FROM
    Customers
WHERE
    CustomerID NOT IN
(
  SELECT
    CustomerID
  FROM
      Orders
)

-- Listing 2-15: INSERT Using Correlated Subquery with NOT EXISTS
-- Update the existing cars
UPDATE C
SET
  Owner = F.Owner
FROM
    Feed AS F
  JOIN
    Cars AS C ON F.License = C.License

-- Insert the new cars
INSERT Cars
SELECT
  License,
  Owner
FROM
    Feed AS F
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      Cars AS C
  WHERE
      C.License = F.License
)

-- Listing 2-16: Finding All Authors for a Book Using the ANY Predicate
SELECT
  *
FROM
    authors
WHERE
    au_id = ANY
(
  SELECT
    au_id
  FROM
      titleauthor
  WHERE
      title_id = 'BU1032'
)

-- Listing 2-17: Finding Co-authored Books Using the ALL Predicate
SELECT
  *
FROM
    titles AS T
WHERE
    1 < ALL
(
  SELECT
    COUNT (*)
  FROM
      titleauthor TA 
  WHERE
      TA.title_id = T.title_id
)

-- Listing 2-17: Finding the Most Recently Shipped Orders Using MAX()
SELECT
  *
FROM
    Orders
WHERE
    ShippedDate =
(
  SELECT
    MAX (ShippedDate)
  FROM
      Orders
)

-- Listing 2-19: Finding the Most Recently Shipped Orders Using ALL
SELECT
  *
FROM
    Orders
WHERE
    ShippedDate >= ALL
(
  SELECT
    ShippedDate
  FROM
      Orders
)

-- Listing 2-20: Finding the Most Recently Shipped Orders Using ALL with NULL Handling
SELECT
  *
FROM
    Orders
WHERE
    ShippedDate >= ALL
(
  SELECT
    ShippedDate
  FROM
      Orders
  WHERE
      ShippedDate IS NOT NULL
)

-- Listing 2-21: Finding the Earliest Shipped Orders Using MIN()
SELECT
  *
FROM
    Orders
WHERE
    ShippedDate =
(
  SELECT
    MIN (ShippedDate)
  FROM
      Orders
)

-- Listing 2-22: Finding the Most Recently Shipped Orders Using ALL
SELECT
  *
FROM
    Orders
WHERE
    ShippedDate <= ALL
(
  SELECT
    ShippedDate
  FROM
      Orders
)

-- Listing 2-23: Calculating Running Totals
SELECT
  CONVERT (char (11), O1.OrderDate)  AS OrderDate,
  SUM (OD1.UnitPrice * OD1.Quantity) AS Sales,
(
  SELECT
    SUM (OD2.UnitPrice * OD2.Quantity) AS Sale
  FROM
      Orders          AS O2
    JOIN
      [Order Details] AS OD2 ON OD2.OrderID = O2.OrderID
  WHERE
      O2.CustomerID = 'BOTTM'
  AND
      O2.OrderDate  <= O1.OrderDate
)  AS 'Sales to Date'
FROM
    Orders          AS O1
  JOIN
    [Order Details] AS OD1 ON OD1.OrderID = O1.OrderID
WHERE
    O1.CustomerID = 'BOTTM'
GROUP BY
  O1.OrderDate

-- Listing 2-24: Determining Average Price by Category
SELECT
  CategoryID,
  AVG (UnitPrice) AS AvgPrice
FROM
    Products
GROUP BY
  CategoryID

-- Listing 2-25: Example of SELECT with GROUP BY as a Derived Table
SELECT
  P.ProductID,
  P.UnitPrice,
  A.AvgPrice
FROM
    Products AS P
  JOIN
  (
    SELECT
      CategoryID,
      AVG (UnitPrice) AS AvgPrice
    FROM
        Products
    GROUP BY
      CategoryID
  )          AS A ON A.CategoryID = P.CategoryID

-- Listing 2-26: Equivalent Correlated Subquery
SELECT
  P.ProductID,
  P.UnitPrice,
(
    SELECT
      AVG (UnitPrice)
    FROM
        Products AS A
    WHERE
        A.CategoryID = P.CategoryID
    GROUP BY
      A.CategoryID
) AS AvgPrice
FROM
    Products AS p

-- Listing 2-27: Finding Duplicate Rows in a Table
SELECT
  T.*
FROM
    MyTable AS T
  JOIN
  (
      SELECT
        keycol1,
        keycol2
      FROM
          MyTable
      GROUP BY
        keycol1,
        keycol2
      HAVING
        COUNT (*) > 1
  )         AS D ON  D.keycol1 = T.keycol1
                 AND D.keycol2 = T.keycol2

-- Listing 2-28: Update with a GROUP BY
UPDATE P
SET
  P.UnitPrice = P.UnitPrice * 1.2
FROM
    Products AS p
  JOIN
  (
    SELECT TOP 5
      ProductID,
      SUM (Quantity) AS Quantity
    FROM
        [Order Details]
    GROUP BY
      ProductID
    ORDER BY
      Quantity DESC
  )          AS S ON S.ProductID = P.ProductID

-- Listing 2-28: Using a UNION ALL Clause in a Derived Table
SELECT
  ProductID,
  SUM (Amount) AS Sales
FROM
(
  SELECT
    SaleDate,
    ProductID,
    Amount
  FROM
      CurrentSales
  UNION ALL
  SELECT
    SaleDate,
    ProductID,
    Amount
  FROM
      PastSales
) AS S
WHERE
    SaleDate >= '19991101'
  AND
    SaleDate <= '20001031'
GROUP BY
  ProductID

-- Listing 2-29: Generating Data for a Histogram
SELECT
  Cnt,
  COUNT (*) AS Frequency
FROM
(
  SELECT
    CustomerID,
    COUNT (*) AS Cnt
  FROM
      Orders
  GROUP BY
    CustomerID
) AS X
GROUP BY
  Cnt

-- Listing 2-30: Finding the Last Row in Products Using MAX()
SELECT
  *
FROM
    Products
WHERE
    ProductID =
(
  SELECT
    MAX (ProductID)
  FROM
      Products
)

-- Listing 2-31: Finding the Last Row in Products Using ALL
SELECT
  *
FROM
    Products
WHERE
    ProductID >= ALL
(
  SELECT
    ProductID
  FROM
      Products
)

-- Listing 2-32: Finding the First Order for Each Customer Using MIN()
SELECT
  O1.*
FROM
    Orders AS O1
WHERE
    O1.OrderID =
(
  SELECT
    MIN (O2.OrderID)
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = O1.CustomerID
)

-- Listing 2-33: Finding the First Order for Each Customer Using the ALL Predicate
SELECT
  O1.*
FROM
    Orders AS O1
WHERE
    O1.OrderID <= ALL
(
  SELECT
    O2.OrderID
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = O1.CustomerID
)

-- Listing 2-34: Finding First Orders Using a Derived Table
SELECT
  O.*
FROM
    Orders AS O
JOIN
(
  SELECT
    MIN (OrderID) AS OrderID
  FROM
      Orders
  GROUP BY
    CustomerID
)        AS X ON  X.OrderID = O.OrderID

-- Listing 2-35: Finding the Total Quantity for Each Customer's Most Recent Order Using MAX()
SELECT
  O1.CustomerID,
  SUM (OD.Quantity) AS Quantity
FROM
    Orders          AS O1
JOIN
    [Order Details] AS OD ON OD.OrderID = O1.OrderID
WHERE
    O1.OrderDate =
(
  SELECT
    MAX (O2.OrderDate)
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = O1.CustomerID
)
GROUP BY
  O1.CustomerID

-- Listing 2-36: Finding the Total Quantity for Each Customer's Most Recent Order Using the ALL Predicate
SELECT
  O1.CustomerID,
  SUM (OD.Quantity) AS Quantity
FROM
    Orders          AS O1
  JOIN
    [Order Details] AS OD ON OD.OrderID = O1.OrderID
WHERE
    O1.OrderDate >= ALL
(
  SELECT
    O2.OrderDate
  FROM
      Orders AS O2
  WHERE
      O2.CustomerID = O1.CustomerID
)
GROUP BY
  O1.CustomerID

-- Listing 2-37: Finding the Total Quantity for Each Customer's Most Recent Order Using a Derived Table
SELECT
  O1.CustomerID,
  SUM (OD.Quantity) AS Quantity
FROM
    Orders          AS O1
  JOIN
    [Order Details] AS OD ON OD.OrderID = O1.OrderID
  JOIN
   (
    SELECT
      CustomerID,
      MAX (OrderDate) AS OrderDate
    FROM
        Orders
    GROUP BY
      CustomerID
  )               AS O2 ON  O2.CustomerID = O1.CustomerID
                        AND O2.OrderDate  = O1.OrderDate
GROUP BY
  O1.CustomerID

-- Puzzle 2.2
CREATE TABLE Orders
(
  orderid int      NOT NULL
                   CONSTRAINT PK_orders_orderid PRIMARY KEY,
  custid  int      NOT NULL,
  odate   datetime NOT NULL
)

CREATE TABLE OrderDetails
(
  orderid int NOT NULL
              CONSTRAINT FK_odetails_orders REFERENCES Orders,
  partno  int NOT NULL,
  qty     int NOT NULL,
  CONSTRAINT PK_odetails_orderid_partno PRIMARY KEY(orderid, partno)
)

CREATE TABLE OrderPayments
(
  orderid   int NOT NULL
                CONSTRAINT FK_opayments_orders REFERENCES Orders,
  paymentno int NOT NULL,
  value     int NOT NULL,
  CONSTRAINT PK_opayments_orderid_paymentno PRIMARY KEY(orderid, paymentno)
)

INSERT INTO Orders VALUES(1, 1001, '20010118')
INSERT INTO Orders VALUES(2, 1002, '20010212')

INSERT INTO OrderDetails VALUES(1, 101, 5)
INSERT INTO OrderDetails VALUES(1, 102, 10)
INSERT INTO OrderDetails VALUES(2, 101, 8)
INSERT INTO OrderDetails VALUES(2, 102, 2)

INSERT INTO OrderPayments VALUES(1, 1, 75)
INSERT INTO OrderPayments VALUES(1, 2, 75)
INSERT INTO OrderPayments VALUES(2, 1, 50)
INSERT INTO OrderPayments VALUES(2, 2, 50)

-- Puzzle 2.3
CREATE TABLE Users
(
  userid   int         NOT NULL PRIMARY KEY,
  username varchar(25) NOT NULL
)

CREATE TABLE Messages
(
  msgid int NOT NULL PRIMARY KEY,
  msg varchar(100) NOT NULL
)

CREATE TABLE MessagesRead
(
  msgid  int NOT NULL REFERENCES Messages(msgid),
  userid int NOT NULL REFERENCES Users(userid)
)

INSERT INTO Users VALUES(1, 'BPMargolin')
INSERT INTO Users VALUES(2, 'Darren')
INSERT INTO Users VALUES(3, 'Umachandar')

INSERT INTO Messages
  VALUES(1, 'Someone called and said that you made her heart double-click')
INSERT INTO Messages
  VALUES(2, 'Your Floppy disk experienced a crash')
INSERT INTO Messages
  VALUES(3, 'Someone sprayed instant glue on all keyboards. Don''t touuuccchhh')

INSERT INTO MessagesRead VALUES(1, 1)
INSERT INTO MessagesRead VALUES(1, 2)
INSERT INTO MessagesRead VALUES(2, 2)
INSERT INTO MessagesRead VALUES(2, 3)
INSERT INTO MessagesRead VALUES(3, 3)
INSERT INTO MessagesRead VALUES(3, 1)

