--------------------------------
-- Chapter 1 - Joins in T-SQL --
--------------------------------

-- Listing 1-1: Schema Creation Script for the Human Resources Database
CREATE TABLE Departments
(
Deptno   int         NOT NULL
                     CONSTRAINT PK_dept_deptno PRIMARY KEY,
deptname varchar(15) NOT NULL
)

CREATE TABLE Jobs
(
jobid   int         NOT NULL
                    CONSTRAINT PK_jobs_jobid PRIMARY KEY,
jobdesc varchar(15) NOT NULL
)

CREATE TABLE Employees
(
empid   int         NOT NULL
                    CONSTRAINT PK_emps_empid PRIMARY KEY,
empname varchar(10) NOT NULL,
deptno  int         NULL
                    CONSTRAINT FK_emps_depts
                      REFERENCES Departments(deptno),
jobid   int         NOT NULL
                    CONSTRAINT FK_emps_jobs REFERENCES Jobs(jobid),
salary decimal(7,2) NOT NULL
)

INSERT INTO Departments VALUES(100, 'Engineering')
INSERT INTO Departments VALUES(200, 'Production')
INSERT INTO Departments VALUES(300, 'Sanitation')
INSERT INTO Departments VALUES(400, 'Management')

INSERT INTO Jobs VALUES(10, 'Engineer')
INSERT INTO Jobs VALUES(20, 'Worker')
INSERT INTO Jobs VALUES(30, 'Manager')
INSERT INTO Jobs VALUES(40, 'Cleaner')

INSERT INTO Employees VALUES(1, 'Leo', 400, 30, 10000.00)
INSERT INTO Employees VALUES(2, 'George', 200, 20, 1000.00)
INSERT INTO Employees VALUES(3, 'Chris', 100, 10, 2000.00)
INSERT INTO Employees VALUES(4, 'Rob', 400, 30, 3000.00)
INSERT INTO Employees VALUES(5, 'Laura', 400, 30, 3000.00)
INSERT INTO Employees VALUES(6, 'Jeffrey', NULL, 30, 5000.00)

-- Listing 1-2: Abbreviated Form of the SELECT Statement
SELECT
  <select_list>
FROM
  <table_source>
[WHERE
  <search_condition>]

-- Listing 1-3: SQL-89 Join Syntax
SELECT
  <select_list>
FROM
  T1, T2
WHERE
  <join_condition> [AND <filter>]

-- Listing 1-4: Old-Style Two-Way Inner Join
SELECT
  empid,
  empname,
  salary,
  E.deptno,
  deptname
FROM
  Employees   AS E,
  Departments AS D
WHERE
  E.deptno = D.deptno

-- Listing 1-5: SQL-92 Join Syntax
SELECT
  <select_list>
FROM
    T1
  <join_type> JOIN
    T2 [ON <join_condition>]
  [<join_type> JOIN
    T3 [ON <join_condition>]
[WHERE
  <filter>]

-- Listing 1-6: Abbreviated Form of an SQL-92 Two-Way Inner Join
SELECT
  <select_list>
FROM
    T1
  [INNER] JOIN
    T2 ON <join_condition>
[WHERE
  <filter>]

-- Listing 1-7: SQL-92 Two-Way Inner Join
SELECT
  empid,
  empname,
  salary,
  E.deptno,
  deptname
FROM
    Employees   AS E
  JOIN
    Departments AS D ON E.deptno = D.deptno

-- Listing 1-8: Old-Style Three-Way Inner Join
SELECT
  empid,
  empname,
  salary,
  E.deptno,
  deptname,
  E.jobid,
  jobdesc
FROM
  Employees   AS E,
  Departments AS D,
  Jobs        AS J
WHERE
    E.deptno = D.deptno
  AND
    E.jobid  = J.jobid

-- Listing 1-9: SQL-92 Three-Way Inner Join 
SELECT
  empid,
  empname,
  salary,
  E.deptno,
  deptname,
  E.jobid,
  jobdesc
FROM
    Employees   AS E
  JOIN
    Departments AS D ON E.deptno = D.deptno
  JOIN
    Jobs        AS J ON E.jobid  = J.jobid

-- Listing 1-10: Forcing the Order of Join Processing
SELECT
  empid,
  empname,
  salary,
  E.deptno,
  deptname,
  E.jobid,
  jobdesc
FROM
    Employees AS E
  JOIN
    Departments AS D ON E.deptno = D.deptno
  JOIN
    Jobs AS J ON E.jobid = J.jobid
OPTION(FORCE ORDER)

-- Listing 1-11: Old-Style Cross Join Syntax
SELECT
  deptname,
  jobdesc
FROM
  Departments,
  Jobs

-- Listing 1-12: SQL-92 Cross Join Syntax
SELECT
  deptname,
  jobdesc
FROM
    Departments
  CROSS JOIN
    Jobs

-- Listing 1-13: Old-Style Outer Join Syntax
SELECT
  <select_list>
FROM
  T1,
  T2
WHERE
  T1.key_col {*= | =*} T2.key_col [AND <filter>]

-- Listing 1-14: Old-Style Two-Way Left Outer Join
SELECT
  *
FROM
  Employees   AS E,
  Departments AS D
WHERE
  E.deptno *= D.deptno

-- Listing 1-15: SQL-92 Two-Way Outer Join Syntax
SELECT
  <select_list>
FROM
    T1
  {LEFT | RIGHT | FULL} [OUTER] JOIN
    T2 ON <join_condition>
[WHERE
  <filter>]

-- Listing 1-16: SQL-92 Two-Way Left Outer Join
SELECT
  *
FROM
    Employees   AS E
  LEFT OUTER JOIN
    Departments AS D ON E.deptno = D.deptno

-- Listing 1-17: Old-Style Two-Way Right Outer Join
SELECT
  *
FROM
  Employees   AS E,
  Departments AS D
WHERE
  E.deptno =* D.deptno

-- Listing 1-18: SQL-92 Two-Way Right Outer Join
SELECT
  *
FROM
    Employees   AS E
  RIGHT OUTER JOIN
    Departments AS D ON E.deptno = D.deptno

-- Listing 1-19: SQL-92 Two-Way Full Outer Join
SELECT
  *
FROM
    Employees   AS E
  FULL OUTER JOIN
    Departments AS D ON E.deptno = D.deptno

-- Listing 1-20: SQL-92 Three-Way Outer Join, Example 1
SELECT
  *
FROM
    Employees   AS E
  LEFT OUTER JOIN
    Departments AS D ON E.deptno = D.deptno
  RIGHT OUTER JOIN
    Jobs        AS J ON E.jobid  = J.jobid

-- Listing 1-21: Illegal Old-Style Three-Way Outer Join, Example 1
SELECT
  *
FROM
  Employees   AS E,
  Departments AS D,
  Jobs        AS J
WHERE
    E.deptno *= D.deptno
  AND
    E.jobid  =* J.jobid

-- Listing 1-22: SQL-92 Three-Way Outer Join, Example 2
SELECT
  *
FROM
    Employees   AS E
  JOIN
    Departments AS D ON E.deptno = D.deptno
  RIGHT OUTER JOIN
    Jobs        AS J ON E.jobid  = J.jobid

-- Listing 1-23: Illegal Old-Style Three-Way Outer Join, Example 2
SELECT
  *
FROM
  Employees AS E,
  Departments AS D,
  Jobs AS J
WHERE
    E.deptno = D.deptno
  AND
    E.jobid =* J.jobid

-- Listing 1-24: Old-Style Left Outer Join between Departments and Employees, Preserving All Departments
SELECT
  *
FROM
  Departments AS D,
  Employees   AS E
WHERE
  D.deptno *= E.deptno

-- Listing 1-25: Using the Old-Style Syntax to Look for Departments with No Employees
SELECT
  *
FROM
  Departments AS D,
  Employees   AS E
WHERE
    D.deptno *= E.deptno
  AND
    E.deptno IS NULL

-- Listing 1-26: Execution Plan for an Outer Join Using the Old-Style Syntax
3 |--Nested Loops(Left Outer Join, WHERE:([D].[deptno]=NULL))
   1 |--Clustered Index Scan(OBJECT:([testdb].[dbo].[Departments].[PK_dept_deptno] AS [D]))
   2 |--Clustered Index Scan(OBJECT:([testdb].[dbo].[Employees].[PK_emps_empid] AS [E]), WHERE:([E].[deptno]=NULL))

-- Listing 1-27: Using the SQL-92 Syntax to Look for Departments with No Employees
SELECT
  *
FROM
    Departments AS D
  LEFT OUTER JOIN
    Employees   AS E ON D.deptno = E.deptno
WHERE
  E.deptno IS NULL

-- Listing 1-28: Execution Plan for an Outer Join Using the SQL-92 Syntax
4 |--Filter(WHERE:([E].[deptno]=NULL))
   3 |--Nested Loops(Left Outer Join, WHERE:([D].[deptno]=[E].[deptno]))
      1 |--Clustered Index Scan(OBJECT:([testdb].[dbo].[Departments].[PK_dept_deptno] AS [D]))
      2 |--Clustered Index Scan(OBJECT:([testdb].[dbo].[Employees].[PK_emps_empid] AS [E]))

-- Listing 1-29: Controlling the Order of Joining and Filtering Rows
SELECT
  *
FROM
    Departments AS D
  LEFT OUTER JOIN
    Employees   AS E ON  D.deptno = E.deptno
                     AND E.deptno IS NULL

-- Listing 1-30: Schema Creation Script for the Candidates Table
CREATE TABLE Candidates
(
candname varchar(10) NOT NULL,
gender   char(1)     NOT NULL
                     CONSTRAINT CHK_gender
                       CHECK (gender IN('F', 'M'))
)

INSERT INTO Candidates VALUES('Neil'   , 'M')
INSERT INTO Candidates VALUES('Trevor' , 'M')
INSERT INTO Candidates VALUES('Terresa', 'F')
INSERT INTO Candidates VALUES('Mary'   , 'F')

-- Listing 1-31: Matching Couples Using a Cross Join; All Possible Couples
SELECT
  T1.candname,
  T2.candname
FROM
    Candidates AS T1
  CROSS JOIN
    Candidates AS T2

-- Listing 1-32: Matching Couples Using a Cross Join; Couples with Different Names
SELECT
  T1.candname,
  T2.candname
FROM
    Candidates AS T1
  CROSS JOIN
    Candidates AS T2
WHERE
  T1.candname <> T2.candname

-- Listing 1-33: Matching Couples Using a Cross Join; Couples with Different Genders
SELECT
  T1.candname,
  T2.candname
FROM
    Candidates AS T1
  CROSS JOIN
    Candidates AS T2
WHERE
  T1.gender <> T2.gender

-- Listing 1-34: Matching Couples Using a Cross Join; Final Query
SELECT
  M.candname AS Guy,
  F.candname AS Girl
FROM
    Candidates AS M
  CROSS JOIN
    Candidates AS F
WHERE
    M.gender <> F.gender
  AND
    M.gender = 'M'

-- Listing 1-35: Matching Couples Using a Cross Join; Using Minimalist Criteria
SELECT
  M.candname AS Guy,
  F.candname AS Girl
FROM
    Candidates AS M
  CROSS JOIN
    Candidates AS F
WHERE
  M.gender > F.gender

-- Listing 1-36: Matching Couples Using an Inner Join
SELECT
  M.candname AS Guy,
  F.candname AS Girl
FROM
    Candidates AS M
  JOIN
    Candidates AS F ON M.gender > F.gender

-- Listing 1-37: Schema Creation Script for the Salarylevels Table
CREATE TABLE Salarylevels
(
lowbound  decimal(7,2) NOT NULL,
highbound decimal(7,2) NOT NULL,
sallevel  varchar(50)  NOT NULL
)

INSERT INTO Salarylevels
  VALUES(0.00, 1500.00, 'Doing most of the work')
INSERT INTO Salarylevels
  VALUES(1500.01, 2500.00, 'Planning the work')
INSERT INTO Salarylevels
  VALUES(2500.01, 4500.00, 'Tell subordinates what to do')
INSERT INTO Salarylevels
  VALUES(4500.01, 99999.99, 'Owners and their relatives')

-- Listing 1-38: Using the BETWEEN Predicate in the Join Condition
SELECT
  E.*,
  sallevel
FROM
    Employees    AS E
  JOIN
    Salarylevels AS SL ON E.salary BETWEEN lowbound AND highbound

-- Listing 1-39: Syntax of DELETE with a Join
DELETE [FROM] <modified_table>
[FROM
    <modified_table>
  <join_type> JOIN
    <another_table> ON <join_condition>]
[WHERE
  <search_condition>]

-- Listing 1-40: DELETE with a Join
DELETE FROM [Order Details]
FROM
    [Order Details] AS OD
  JOIN
    Orders          AS O ON OD.orderid = O.orderid
WHERE
  CustomerID = 'VINET'

-- Listing 1-41: Syntax of UPDATE with a Join
UPDATE <modified_table>
  SET col1 = <new_value>[,
  col2 = <new_value>]
[FROM
    <modified_table>
  <join_type> JOIN
    <another_table> ON <join_condition>]
[WHERE
  <search_condition>]

-- Listing 1-42: UPDATE with a Join
UPDATE OD
  SET Discount = Discount + 0.05
FROM
    [Order Details] AS OD
  JOIN
    Products        AS P ON OD.productid = P.productid
WHERE
  SupplierID = 1

-- Listing 1-43: A Query with an Incompletely Qualified Filter Criteria
SELECT
  *
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID	= O.OrderID
WHERE
    O.OrderID  >= 11000

-- Listing 1-44: I/O Measures for a Query with an Incompletely Qualified Filter Criteria
Table 'Order Details'. Scan count 78, logical reads 158, physical reads 0, read-ahead reads 0.
Table 'Orders'. Scan count 1, logical reads 3, physical reads 0, read-ahead reads 0.

-- Listing 1-45: SHOWPLAN Output for a Query with an Incompletely Qualified Filter Criteria
|--Nested Loops(Inner Join, OUTER REFERENCES:([O].[OrderID]))
     |--Clustered Index Seek(OBJECT:([Northwind].[dbo].[Orders].[PK_Orders] AS [O]), SEEK:([O].[OrderID] >= 11000) ORDERED FORWARD)
     |--Clustered Index Seek(OBJECT:([Northwind].[dbo].[Order Details].[PK_Order_Details] AS [OD]), SEEK:([OD].[OrderID]=[O].[OrderID]) ORDERED FORWARD)

-- Listing 1-46: A Query with a Completely Qualified Filter Criteria
SELECT
  *
FROM
    Orders          AS O
  JOIN
    [Order Details] AS OD ON OD.OrderID = O.OrderID
WHERE
    O.OrderID  >= 11000
  AND
    OD.OrderID >= 11000

-- Listing 1-47: I/O Measures for a Query with a Completely Qualified Filter Criteria
Table 'Order Details'. Scan count 1, logical reads 3, physical reads 0, read-ahead reads 0.
Table 'Orders'. Scan count 1, logical reads 3, physical reads 0, read-ahead reads 0.

-- Listing 1-48: SHOWPLAN Output for a Query with a Completely Qualified Filter Criteria
|--Merge Join(Inner Join, MERGE:([O].[OrderID])=([OD].[OrderID]), RESIDUAL:([O].[OrderID]=[OD].[OrderID]))
     |--Clustered Index Seek(OBJECT:([Northwind].[dbo].[Orders].[PK_Orders] AS [O]), SEEK:([O].[OrderID] >= 11000) ORDERED FORWARD)
     |--Clustered Index Seek(OBJECT:([Northwind].[dbo].[Order Details].[PK_Order_Details] AS [OD]), SEEK:([OD].[OrderID] >= 11000) ORDERED FORWARD)

-- Listing 1-49: Join Hints Syntax
SELECT
  <select_list>
FROM
    T1
  <join_type> <join_hint> JOIN
    T2
