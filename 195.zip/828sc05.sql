----------------------------------
-- Chapter 5 - Summarizing Data --
----------------------------------

-- Listing 5-1: Total Number of Orders by Customer and Year
SELECT
  CustomerID,
  YEAR(OrderDate) AS Order_Year,
  COUNT(*) AS Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  YEAR(OrderDate)

-- Listing 5-2: Total Number of Orders by Customer, Employee, and Year
SELECT
  CustomerID,
  EmployeeID,
  YEAR(OrderDate) AS Order_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  EmployeeID,
  YEAR(OrderDate)

-- Listing 5-3: Basic CUBE Query
SELECT
  CustomerID,
  YEAR(OrderDate) AS Order_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  YEAR(OrderDate)
WITH CUBE

-- Listing 5-4: CUBE Query and the GROUPING() function
SELECT
  CustomerID,
  GROUPING(CustomerID) AS Grp_Cust,
  YEAR(OrderDate) AS Order_Year,
  GROUPING(YEAR(OrderDate)) AS Grp_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  YEAR(OrderDate)
WITH CUBE

-- Listing 5-5: Creating the Vbase_cube view to Hide the CUBE Query Complexity
CREATE VIEW Vbase_cube
AS

SELECT
  CustomerID,
  GROUPING(CustomerID) AS Grp_Cust,
  YEAR(OrderDate) AS Order_Year,
  GROUPING(YEAR(OrderDate)) AS Grp_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  YEAR(OrderDate)
WITH CUBE
GO

-- Listing 5-6: Selecting All Rows from the Vbase_cube View
SELECT
  *
FROM
  Vbase_cube

-- Listing 5-7: Replacing NULLs with your Own Value
ISNULL(CustomerID, <your_own_value>)

-- Listing 5-8: Expanding Your Own Value
<your_own_value> :=
CASE Grp_Cust
  WHEN 1 THEN 'ALL'
  ELSE 'UNKNOWN'
END

-- Listing 5-9: Replacing NULLs with Your Own Value, Expanded
ISNULL(CustomerID,
  CASE Grp_Cust
    WHEN 1 THEN 'ALL'
    ELSE 'UNKNOWN'
  END)

-- Listing 5-10: UNKNOWN is Truncated to UNKNO
ISNULL(NULL /* which is char(5) */, 'UNKNOWN') = 'UNKNO'

-- Listing 5-11: Avoiding Truncation of UNKNOWN in the CustomerID Column
ISNULL(CAST(CustomerID AS varchar(7)),
  CASE Grp_Cust
    WHEN 1 THEN 'ALL'
    ELSE 'UNKNOWN'
  END)

-- Listing 5-12: Handling Mixed Datatypes in the Order_Year Column
ISNULL(CAST(Order_Year AS varchar(7)),
  CASE Grp_Year
    WHEN 1 THEN 'ALL'
    ELSE 'UNKNOWN'
  END)

-- Listing 5-13: Replacing NULLs with ALL and UNKNOWN
SELECT
  ISNULL(CAST(CustomerID AS varchar(7)),
    CASE Grp_Cust
      WHEN 1 THEN 'ALL'
      ELSE 'UNKNOWN'
    END) AS Customer,
  ISNULL(CAST(Order_Year AS varchar(7)),
    CASE Grp_Year
      WHEN 1 THEN 'ALL'
      ELSE 'UNKNOWN'
    END) AS Order_Year,
  Order_Count
FROM
  Vbase_cube

-- Listing 5-14: Creating the Vcube View on Top of the Vbase_cube View to Hide the Query Complexity
CREATE VIEW Vcube
AS

SELECT
  ISNULL(CAST(CustomerID AS varchar(7)),
    CASE Grp_Cust
      WHEN 1 THEN 'ALL'
      ELSE 'UNKNOWN'
    END) AS Customer,
  ISNULL(CAST(Order_Year AS varchar(7)),
    CASE Grp_Year
      WHEN 1 THEN 'ALL'
      ELSE 'UNKNOWN'
    END) AS Order_Year,
  Order_Count
FROM
  Vbase_cube
GO 

-- Listing 5-15: Querying the Vcube View, Example 1
SELECT
  *
FROM
    Vcube
WHERE
    Customer   = 'ALL'
  AND
    Order_Year = 'ALL'

-- Listing 5-16: Querying the Vcube View, Example 2
SELECT
  *
FROM
    Vcube
WHERE
    Customer   = 'ALFKI'
  AND
    Order_Year = 'ALL'

-- Listing 5-17: Querying the Vcube View, Example 3
SELECT
  *
FROM
    Vcube
WHERE
    Customer   = 'ALL'
  AND
    Order_Year = '1998'

-- Listing 5-18: CUBE Returns All Possible Levels of Super Aggregation
SELECT
  CustomerID,
  EmployeeID,
  YEAR(OrderDate) AS Order_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  EmployeeID,
  YEAR(OrderDate)
WITH CUBE

-- Listing 5-19: ROLLUP Returns Super Aggregation Only in One Direction
SELECT
  CustomerID,
  EmployeeID,
  YEAR(OrderDate) AS Order_Year,
  COUNT(*)        AS Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  EmployeeID,
  YEAR(OrderDate)
WITH ROLLUP

-- Listing 5-20: Using ROLLUP to Get the Order Count by Year and Month
SELECT
  YEAR(OrderDate)  AS Oyear,
  MONTH(OrderDate) AS Omonth,
  COUNT(*)         AS Order_Count
FROM
  Orders
GROUP BY
  YEAR(OrderDate),
  MONTH(OrderDate)
WITH ROLLUP

-- Listing 5-21: Comparing Performance, Query 1�Simple GROUP BY Query
SELECT
  CustomerID,
  EmployeeID,
  ShipVia,
  COUNT(*) AS Order_Count
FROM
  Orders
GROUP BY
  CustomerID,
  EmployeeID,
  ShipVia

-- Listing 5-22: SHOWPLAN�s Output for Query 1�GROUP BY Query
3 |--Stream Aggregate(GROUP BY:([Orders].[CustomerID], [Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1002]=COUNT(*)))
   2 |--Sort(ORDER BY:([Orders].[CustomerID] ASC, [Orders].[EmployeeID] ASC, [Orders].[ShipVia] ASC))
      1 |--Clustered Index Scan(OBJECT:([Northwind].[dbo].[Orders].[PK_Orders]))

-- Listing 5-23: Comparing Performance, Query 2�ROLLUP Query
SELECT
 CustomerID,
  EmployeeID,
  ShipVia,
  COUNT(*) AS Order_Count
FROM
  Orders
GROUP BY
  CustomerID,
  EmployeeID,
  ShipVia
WITH ROLLUP

-- Listing 5-24: SHOWPLAN�s Output for Query 2�ROLLUP Query
4 |--Stream Aggregate(GROUP BY:([Orders].[CustomerID], [Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1002]=SUM([Expr1003])))
   3 |--Stream Aggregate(GROUP BY:([Orders].[CustomerID], [Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1003]=COUNT(*)))
      2 |--Sort(ORDER BY:([Orders].[CustomerID] ASC, [Orders].[EmployeeID] ASC, [Orders].[ShipVia] ASC))
         1 |--Clustered Index Scan(OBJECT:([Northwind].[dbo].[Orders].[PK_Orders]))

-- Listing 5-25: Comparing Performance, Query 3�CUBE Query
SELECT
  CustomerID,
  EmployeeID,
  ShipVia,
  COUNT(*) as Order_Count
FROM
  Orders
GROUP BY
  CustomerID,
  EmployeeID,
  ShipVia
WITH CUBE

-- Listing 5-26: SHOWPLAN�s Output for Query 3�CUBE Query
14 |--Concatenation
      5 |--Stream Aggregate(GROUP BY:([Orders].[CustomerID], [Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1002]=SUM([Expr1003])))
         |  4 |--Table Spool
         |     3 |--Stream Aggregate(GROUP BY:([Orders].[CustomerID], [Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1003]=COUNT(*)))
         |           2 |--Sort(ORDER BY:([Orders].[CustomerID] ASC, [Orders].[EmployeeID] ASC, [Orders].[ShipVia] ASC))
         |              1 |--Clustered Index Scan(OBJECT:([Northwind].[dbo].[Orders].[PK_Orders]))
      9 |--Compute Scalar(DEFINE:([Expr1004]=NULL))
         |  8 |--Stream Aggregate(GROUP BY:([Orders].[EmployeeID], [Orders].[ShipVia]) DEFINE:([Expr1002]=SUM([Expr1003])))
         |     7 |--Sort(ORDER BY:([Orders].[EmployeeID] ASC, [Orders].[ShipVia] ASC))
         |           6 |--Table Spool
    13 |--Compute Scalar(DEFINE:([Expr1005]=NULL))
           12 |--Stream Aggregate(GROUP BY:([Orders].[ShipVia], [Orders].[CustomerID]) DEFINE:([Expr1002]=SUM([Expr1003])))
              11 |--Sort(ORDER BY:([Orders].[ShipVia] ASC, [Orders].[CustomerID] ASC))
                    10 |--Table Spool

-- Listing 5-27: COMPUTE Syntax
COMPUTE
  <aggregate_function>(expression)

-- Listing 5-28: Using COMPUTE in a Query
SELECT
  CustomerID,
  EmployeeID,
  OrderID, Freight
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
COMPUTE
  SUM(Freight)

-- Listing 5-29: COMPUTE BY Syntax
COMPUTE
  <aggregate_function>(expression) BY expression[,...n]

-- Listing 5-30: Using COMPUTE BY in a Query
SELECT
  CustomerID,
  EmployeeID,
  OrderID,
  Freight
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
ORDER BY
  CustomerID
COMPUTE
  SUM(Freight) BY CustomerID
COMPUTE
  SUM(Freight)

-- Listing 5-31: Using COMPUTE BY with a Finer Grain
SELECT
  CustomerID,
  EmployeeID,
  OrderID, Freight
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
ORDER BY
  CustomerID,
  EmployeeID
COMPUTE
  SUM(Freight) BY CustomerID,
                  EmployeeID
COMPUTE
  SUM(Freight) BY CustomerID
COMPUTE
  SUM(Freight)
