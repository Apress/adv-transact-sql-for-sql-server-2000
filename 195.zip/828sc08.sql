-----------------------
-- Chapter 8 - Views --
-----------------------

-- Listing 8-1: Authors and the Titles They Wrote
SELECT
  A.au_id,
  au_fname + ', ' + LEFT(au_fname, 1),
  TA.au_id,
  TA.title_id
FROM
    Authors AS A
  LEFT OUTER JOIN
    Titleauthor AS TA ON A.au_id = TA.au_id

-- Listing 8-2: Requesting Duplicate Column Names and Unnamed Columns from an Imaginary View
SELECT
  [this column, you know, the one that has no name],
  [au_id...wait, wait, the second one, not the first one!]
FROM
  VAllauthors

-- Listing 8-3: Supplying Different Names and Qualifiers to Illegal Columns in the View
CREATE VIEW VAllauthors
AS
SELECT
  A.au_id                             AS au_id_A,
  au_fname + ', ' + LEFT(au_fname, 1) AS au_name,
  TA.au_id                            AS au_id_TA,
  TA.title_id
FROM
    Authors AS A
  LEFT OUTER JOIN
    Titleauthor AS TA ON A.au_id = TA.au_id
GO

-- Listing 8-4: Supplying Column Names in the Header of the View
CREATE VIEW VAllauthors(au_id_a, au_name, au_id_ta, title_id)
AS
SELECT
  A.au_id                             AS au_id_A,
  au_fname + ', ' + LEFT(au_fname, 1) AS au_name,
  TA.au_id                            AS au_id_TA,
  TA.title_id
FROM
    Authors AS A
  LEFT OUTER JOIN
    Titleauthor AS TA ON A.au_id = TA.au_id
GO

-- Listing 8-5: The Author�s Phone List View
CREATE VIEW VAuPhoneList
AS
SELECT
  au_fname,
  au_lname,
  phone
FROM
  Authors
GO
SELECT
  *
FROM
  VAuPhoneList
ORDER BY
  au_fname,
  au_lname

-- Listing 8-6: Trying to Use the ORDER BY Clause in a View
ALTER VIEW VAuPhoneList
AS
SELECT
  au_fname,
  au_lname,
  phone
FROM
  Authors
ORDER BY
  au_fname,
  au_lname
GO

-- Listing 8-7: Using the ORDER BY Clause in a View with a TOP Statement
ALTER VIEW VAuPhoneList
AS
SELECT TOP 5
  au_fname,
  au_lname,
  phone
FROM
  Authors
ORDER BY
  au_fname,
  au_lname
GO

-- Listing 8-8: Using the ORDER BY Clause in a View with TOP 100 PERCENT
ALTER VIEW VAuPhoneList
AS
SELECT TOP 100 PERCENT
  au_fname,
  au_lname,
  phone
FROM
  Authors
ORDER BY
  au_fname,
  au_lname
GO

Listing8-9: Redundant Sorting
SELECT
  *
FROM
  VAuPhoneList
ORDER BY
  au_lname,
  au_fname

-- Listing 8-10: Hiding the Complexity of the Underlying Query, Step 1
CREATE VIEW Vbase_cube
AS
SELECT
  CustomerID,
  GROUPING(CustomerID) AS Grp_Cust,
  YEAR(OrderDate) AS Order_Year,
  GROUPING(YEAR(OrderDate)) AS Grp_Year,
  COUNT(*) as Order_Count
FROM
  Orders
WHERE
  CustomerID LIKE 'A%'
GROUP BY
  CustomerID,
  YEAR(OrderDate)
WITH CUBE
GO

-- Listing 8-11: Hiding the Complexity of the Underlying Query, Step 2
CREATE VIEW Vcube
AS
SELECT
  ISNULL(CAST(CustomerID AS varchar(7)),
  CASE Grp_Cust
    WHEN 1 THEN 'ALL'
    ELSE 'UNKNOWN'
  END) AS customer,
  ISNULL(CAST(Order_Year AS varchar(7)),
  CASE Grp_Year
    WHEN 1 THEN 'ALL'
    ELSE 'UNKNOWN'
  END) AS Order_Year,
  Order_Count
FROM
  Vbase_cube
GO

-- Listing 8-12: Retriving Data through a View with a Complex Query
SELECT
  *
FROM
  Vcube
WHERE
    customer = 'ALL'
  AND
    Order_Year = 'ALL'

-- Listing 8-13: ALTER VIEW Syntax
ALTER VIEW view_name [(column [,...n])]
[WITH ENCRYPTION | SCHEMABINDING]
AS
  select_statement
[WITH CHECK OPTION]

-- Listing 8-14: Granting Permission on a Column in a View
CREATE VIEW VAunames
AS
SELECT
  au_id,
  au_lname,
  au_fname
FROM
  Authors
GO
GRANT SELECT ON VAunames(au_id) TO user1
GO

-- Listing 8-15: Testing Permissions Granted on a View
-- Should get error 230 (permissions denied) on columns au_fname and au_lname
SELECT
  *
FROM
  VAunames
-- Should get a valid output
SELECT
  au_id
FROM
  VAunames

-- Listing 8-16: Altering a View with Previously Granted Permissions
ALTER VIEW VAunames
AS
SELECT
  au_fname,
  au_id,
  au_lname
FROM
  Authors
GO

-- Listing 8-17: Column Permissions in a View Preserved by Column Name
SELECT
  au_fname
FROM
  Vaunames

-- Listing 8-18: Using sp_helptext to View an Object�s Definition
EXEC sp_helptext VAunames

-- Listing 8-19: Retrieving an Object�s Definition from syscomments
SELECT
  [text]
FROM
  syscomments
WHERE
  [id] = OBJECT_ID('dbo.VAunames')

-- Listing 8-20: Encrypting an Object�s Definition
ALTER VIEW VAunames
WITH ENCRYPTION
AS
SELECT
  au_id,
  au_lname,
  au_fname
FROM
  Authors
GO

-- Listing 8-21: Schema and Data of the Warriors and Weapons Tables
IF db_id('testdb') IS NULL
  CREATE DATABASE testdb
GO
USE testdb
GO
CREATE TABLE Weapons(
weaponid int        NOT NULL PRIMARY KEY,
weapon  varchar(25) NOT NULL)
CREATE TABLE Warriors(
warriorid int       NOT NULL PRIMARY KEY,
fname   varchar(15) NOT NULL,
lname   varchar(15) NOT NULL,
weaponid int        NOT NULL REFERENCES Weapons(weaponid))
GO
SET NOCOUNT ON
GO
INSERT INTO Weapons VALUES(100, 'Mangoes in syrup')
INSERT INTO Weapons VALUES(200, 'Passion fruit')
INSERT INTO Weapons VALUES(300, 'Black cherries')
INSERT INTO Weapons VALUES(400, 'Banana')
INSERT INTO Weapons VALUES(500, 'Pointed stick')
INSERT INTO Warriors VALUES(1,  'Andy'      , 'Ball'        , 100)
INSERT INTO Warriors VALUES(2,  'Bob'       , 'Pfeiff'      , 100)
INSERT INTO Warriors VALUES(3,  'Bruce'     , 'P. Margolin' , 100)
INSERT INTO Warriors VALUES(4,  'Brian'     , 'Moran'       , 200)
INSERT INTO Warriors VALUES(5,  'Darren'    , 'Green'       , 200)
INSERT INTO Warriors VALUES(6,  'Gianluca'  , 'Hotz'        , 200)
INSERT INTO Warriors VALUES(7,  'Kalen'     , 'Delaney'     , 300)
INSERT INTO Warriors VALUES(8,  'Neil'      , 'Pike'        , 300)
INSERT INTO Warriors VALUES(9,  'Ron'       , 'Talmage'     , 300)
INSERT INTO Warriors VALUES(10, 'Roy'       , 'Harvey'      , 400)
INSERT INTO Warriors VALUES(11, 'Steve'     , 'Robinson'    , 400)
INSERT INTO Warriors VALUES(12, 'Tibor'     , 'Karaszi'     , 400)
INSERT INTO Warriors VALUES(13, 'Tony'      , 'Reogerson'   , 500)
INSERT INTO Warriors VALUES(14, 'Trevor'    , 'Dwyer'       , 500)
INSERT INTO Warriors VALUES(15, 'Umachandar', 'Jayachandran', 500)
INSERT INTO Warriors VALUES(16, 'Wayne'     , 'Snyder'      , 500)
INSERT INTO Warriors VALUES(17, 'Fernando'  , 'G. Guerrero' , 500)
GO
SET NOCOUNT OFF
GO

-- Listing 8-22: Creating the VCherryWarriors View
CREATE VIEW VCherryWarriors
AS
SELECT
  *
FROM
  Warriors
WHERE
  Weaponid = 300
GO
SELECT
  *
FROM
  VCherryWarriors

-- Listing 8-23: Modifying a Row in the View so It Doesn�t Qualify for the Filter Criteria
UPDATE VCherryWarriors
  SET weaponid = 500
WHERE
  warriorid = 9

-- Listing 8-24: Inserting a Row that Doesn�t Qualify to the Filter Criteria in the View
INSERT INTO VCherryWarriors VALUES(18, 'Itzik', 'Ben-Gan', 100)

-- Listing 8-25: Retrieving Cherry Warriors after Modifications
SELECT
  *
FROM
  VCherryWarriors

-- Listing 8-26: Using the CHECK OPTION
ALTER VIEW VCherryWarriors
AS
SELECT
  *
FROM
  Warriors
WHERE
  weaponid = 300
WITH CHECK OPTION
GO

-- Listing 8-27: Creating the VWarriorNames View
CREATE VIEW VWarriorNames
AS
SELECT
  fname,
  lname
FROM
  Warriors
GO

-- Listing 8-28: Creating the VwarriorsWithFullNames View
CREATE VIEW VWarriorsWithFullNames
AS
SELECT
  warriorid,
  fname + ' ' + lname AS warriorname,
  weaponid
FROM
  Warriors
GO

-- Listing 8-29: Creating the VWarriorsWeapons View
CREATE VIEW VWarriorsWeapons
AS
SELECT
  warriorid,
  fname,
  lname,
  WP.weaponid,
  weapon
FROM
    Warriors AS WR
  JOIN
    Weapons AS WP ON WR.weaponid = WP.weaponid
GO

-- Listing 8-30: Querying the VWarriorsWeapons View
SELECT
  *
FROM
  VWarriorsWeapons

-- Listing 8-31: Trying to Modify Columns from Different Tables through a View
UPDATE VWarriorsWeapons
  SET lname = 'BG',
      weapon = 'The Mangoes in syrup'  
WHERE
  warriorid = 17

-- Listing 8-32: Modifying One Column at a Time through a View, Step1
UPDATE VWarriorsWeapons
  SET lname = 'BG'
WHERE
  warriorid = 17
SELECT
  *
FROM
  VWarriorsWeapons

-- Listing 8-33: Modifying One Column at a Time through a View, Step2
UPDATE VWarriorsWeapons
  SET weapon = 'The Mangoes in syrup'
WHERE
  warriorid = 17
SELECT
  *
FROM
  VWarriorsWeapons

-- Listing 8-34: Schema and Data for the Employees and Departments Tables
CREATE TABLE Departments(
deptno  int          NOT NULL
                     CONSTRAINT PK_Departments_deptno PRIMARY KEY,
deptname varchar(25) NOT NULL)
GO
CREATE TABLE Employees(
empid int         NOT NULL
                  CONSTRAINT PK_Employees_empid PRIMARY KEY,
fname varchar(25) NOT NULL,
lname varchar(25) NOT NULL,
deptno int        NOT NULL
                  CONSTRAINT FK_Employees_Departments
                    FOREIGN KEY
                    REFERENCES Departments(deptno),
salary money      NOT NULL)
GO
SET NOCOUNT ON
INSERT INTO Departments VALUES(100, 'HR')
INSERT INTO Departments VALUES(200, 'Marketing')
INSERT INTO Departments VALUES(300, 'Production')
INSERT INTO Departments VALUES(400, 'Finance')
DECLARE @i AS int
SET @i = 1
WHILE @i <= 100000
BEGIN
  INSERT INTO Employees(empid, fname, lname, deptno, salary)
    VALUES(@i,
           'fname' + cast(@i AS varchar(6)),
           'lname' + cast(@i AS varchar(6)),
            100 * ((@i - 1) % 4 + 1), -- 4 different departments
            1000.00 + 50 * ((@i - 1) % 50 + 1)) -- 50 different salaries
  SET @i = @i + 1
END
GO

-- Listing 8-35: Calculating the Number of Employees and the Total Salary for Each Department
SET STATISTICS IO ON
SELECT
  E.deptno,
  deptname,
  COUNT(*)  AS num_employees,
  sum(salary) AS total_salary
FROM
    dbo.Employees AS E
  JOIN
    dbo.Departments AS D ON E.deptno = D.deptno
GROUP BY
  E.deptno,
  deptname

-- Listing 8-36: Creating a View for Indexing
CREATE VIEW VDeptSalaries WITH SCHEMABINDING
AS
SELECT
  E.deptno,
  deptname,
  COUNT_BIG(*) AS num_employees,
  SUM(salary) AS total_salary
FROM
    dbo.Employees AS E
  JOIN
    dbo.Departments AS D ON E.deptno = D.deptno
GROUP BY
  E.deptno,
  deptname
GO

-- Listing 8-37: Creating an Index on a View
CREATE UNIQUE CLUSTERED INDEX idx_ci_deptno ON VDeptSalaries(deptno)

-- Listing 8-38: Querying an Indexed View
SELECT
  *
FROM
  VDeptSalaries

-- Listing 8-39: Querying Base Tables with an Indexed View Defined 
SELECT
  E.deptno,
  deptname,
  AVG(salary) AS avg_salary
FROM
    dbo.Employees AS E
  JOIN
    dbo.Departments AS D ON E.deptno = D.deptno
GROUP BY
  E.deptno,
  deptname

-- Listing 8-40: Starting from Scratch � Dropping the Existing Indexed View and Covering Index
DROP VIEW VDeptSalaries
GO
DROP INDEX Employees.idx_nci_deptno_salary
GO

-- Listing 8-41: Saving the Workload to Be Tuned by the ITW in a Script File
USE testdb
GO
SELECT
  E.deptno,
  deptname,
  COUNT(*)  AS num_employees,
  sum(salary) AS total_salary
FROM
    dbo.Employees AS E
  JOIN
    dbo.Departments AS D ON E.deptno = D.deptno
GROUP BY
  E.deptno,
  deptname
GO

-- Listing 8-42: Script File with the ITW�s Recommendations
/* Created by: Index Tuning Wizard 	*/
/* Date: 9/20/2000 			*/
/* Time: 6:35:30 PM 			*/
/* Server Name: SHIRE\SHILOH 			*/
/* Database Name: testdb 			*/
/* Workload File Name: C:\Temp\workload.sql */


USE [testdb] 
go

SET QUOTED_IDENTIFIER ON 
SET ARITHABORT ON 
SET CONCAT_NULL_YIELDS_NULL ON 
SET ANSI_NULLS ON 
SET ANSI_PADDING ON 
SET ANSI_WARNINGS ON 
SET NUMERIC_ROUNDABORT OFF 
go

DECLARE @bErrors as bit

go
CREATE VIEW [dbo].[_hypmv_0] WITH SCHEMABINDING
AS

SELECT
  [dbo].[employees].[deptno] as _hypmv_0_col_1,
  [dbo].[departments].[deptname] as _hypmv_0_col_2,
  count_big(*) as _hypmv_0_col_3,
  SUM([testdb].[dbo].[Employees].[salary]) as _hypmv_0_col_4
FROM
  [dbo].[employees],
  [dbo].[departments]
WHERE
  ( [dbo].[departments].[deptno] = [dbo].[employees].[deptno] )
GROUP BY
  [dbo].[employees].[deptno],
  [dbo].[departments].[deptname]  
go

DECLARE @bErrors as bit

BEGIN TRANSACTION
SET @bErrors = 0

CREATE UNIQUE CLUSTERED INDEX [_hypmv_02] ON [dbo].[_hypmv_0] ([_hypmv_0_col_1] ASC )
IF( @@error <> 0 ) SET @bErrors = 1

IF( @bErrors = 0 )
  COMMIT TRANSACTION
ELSE
  ROLLBACK TRANSACTION


/* Statistics to support recommendations */

CREATE STATISTICS [hind_2009058193_4A_5A] ON [dbo].[employees] ([deptno], [salary])
