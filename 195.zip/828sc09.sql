-----------------------------------
-- Chapter 9 - Stored Procedures --
-----------------------------------

-- Listing 9-1: Syntax for the CREATE PROCEDURE Statement
CREATE PROC[EDURE] [owner_name.]procedure_name [;number]
    [
        {@parameter data_type} [VARYING] [= default] [OUTPUT]
    ]
    [,...n]
[WITH 
    {
        RECOMPILE 
        | ENCRYPTION 
        | RECOMPILE, ENCRYPTION
    }
]
[FOR REPLICATION]
AS
    sql_statement [...n]

-- Listing 9-2: Example of a CREATE PROC Header with Parameters
CREATE PROC usp_DisplayCustomers
(
  @Country  AS nvarchar (15),
  @Region      nvarchar (15)
)

-- Listing 9-3: Example of a CREATE PROC with Output Parameters
CREATE PROC usp_LastOrderDate
(
  @CustomerID  nchar (5),
  @OrderDate   datetime    OUTPUT
)

-- Listing 9-4: Example of a CREATE PROC with Default Parameter
CREATE PROC usp_GetOrderDetails
(
  @CustomerID  nchar (5),
  @OrderID     int         = NULL
)

-- Listing 9-5: CREATE PROC Using WITH RECOMPILE
CREATE PROC usp_GetOrderDetails
(
  @CustomerID  nchar (5),
  @OrderID     int         = NULL
)
WITH RECOMPILE

-- Listing 9-6: Stored Procedure to Retrieve a Customer's Most Recent Order
CREATE PROC usp_GetRecentOrder
(
  @CustomerID  nchar (5)
)
AS
SELECT TOP 1
  *
FROM
  Orders
WHERE
    CustomerID = @CustomerID
ORDER BY
  OrderDate DESC
GO

-- Listing 9-6: Using the DROP PROCEDURE Statement
DROP PROCEDURE spMyProc

-- Listing 9-7: Syntax for the EXEC Statement
[[EXEC[UTE]]
{
  [@return_status =]
  {procedure_name [;number ] | @procedure_name_var
}
  [[@parameter =]{value | @variable [OUTPUT] | [DEFAULT]]
  [,...n ]
[WITH RECOMPILE]

-- Listing 9-8: Executing a Stored Procedure
EXEC usp_GetOrderDetails
  'BOTTM',
  10410

-- Listing 9-9: Alternative Calling Syntax for a Stored Procedure
EXEC usp_GetOrderDetails
  @OrderID    = 10410,
  @CustomerID = 'BOTTM'

-- Listing 9-10: Calling a Stored Procedure With Defaults
EXEC usp_DefaultProc
  @Parm2 = 909,
  @Parm3 = 50

-- Listing 9-11: Calling a Stored Procedure With Defaults
EXEC usp_DefaultProc
  DEFAULT
  909,
  50

-- Listing 9-12: A SELECT Followed by an EXEC
SELECT
  *
FROM
  Customers

EXEC sp_help

-- Listing 9-13: A SELECT Followed by a Stored Procedure Call without an EXEC
SELECT
  *
FROM
  Customers

sp_help

-- Listing 9-14: A SELECT Followed by a Stored Procedure Call without an EXEC, Reformatted
SELECT
  *
FROM
  Customers sp_help

-- Listing 9-15: Calling a Stored Procedure with an Output Parameter
DECLARE
  @OrderID  int

EXEC usp_GetLastOrderID
  'BOTTM',
  @OrderID  OUTPUT

SELECT
   @OrderID
Using WITH RECOMPILE

-- Listing 9-16: Using the WITH RECOMPILE Option with a Stored Procedure Call
EXEC usp_GetCustomerList
  'Canada',
  'Ontario'
WITH RECOMPILE

-- Listing 9-17: Query Resulting in Clustered Index Scan
SELECT
  *
FROM
  Orders
WHERE
  OrderDate >= '1996-07-04 00:00:00.000'

-- Listing 9-18: Query Resulting in Nonclustered Index Seek
SELECT
  *
FROM
  Orders
WHERE
  OrderDate >= '1998-05-06 00:00:00.000'

-- Listing 9-19: Stored Procedure to Retrieve Orders Based Upon Order Date
CREATE PROC usp_GetOrders
(
  @OrderDate AS datetime
)
AS

SELECT
  *
FROM
  Orders
WHERE
  OrderDate >= @OrderDate
GO
Now that you have a procedure, it's time to do some testing. For the tests to be meaningful, ensure that no one else is connected to SQL Server. Also, you'll need to start by purging the memory of existing plans. This you do with the script in Listing 9-20.

-- Listing 9-20: Clearing Out Memory
DBCC FREEPROCCACHE
DBCC DROPCLEANBUFFERS
GO

-- Listing 9-21: Using the usp_GetOrders Stored Procedure for May 6, 1998
EXEC usp_GetOrders
  '1998-05-06 00:00:00.000'

-- Listing 9-22: Using the usp_GetOrders Stored Procedure for July 4, 1996
EXEC usp_GetOrders
  '1996-07-04 00:00:00.000'

-- Listing 9-23: ALTER PROC Statement Using WITH RECOMPILE
ALTER PROC usp_GetOrders
(
  @OrderDate AS datetime
)
WITH RECOMPILE
AS

SELECT
  *
FROM
  Orders
WHERE
  OrderDate >= @OrderDate
GO

-- Listing 9-24: Using the RETURN Statement
RETURN 5

-- Listing 9-25: Partial Syntax for EXEC with a Return Code
EXEC @ReturnCode = ProcName
... parameter list ...

-- Listing 9-26: Syntax for EXEC () Statement
EXEC [ UTE ] ( { @string_variable | [ N ] 'tsql_string' } [ + ...n ] )

-- Listing 9-27: Using EXEC () to Execute a Dynamic TOP n Query
DECLARE
  @ExecStr varchar (2000),
  @N       int

SELECT
  @N = 5

SELECT
  @ExecStr = 'SELECT TOP ' + STR (@N, 2) + ' * '
           + 'FROM Orders ORDER BY OrderID DESC'

EXEC (@ExecStr)

-- Listing 9-28: Example of Dynamic Database Context with EXEC()
USE Northwind
EXEC ('USE pubs SELECT * FROM authors')

-- Listing 9-29: Syntax for sp_executesql
sp_executesql [@stmt =] stmt
[
    {, [@params =] N'@parameter_name  data_type [,...n]' }
    {, [@param1 =] 'value1' [,...n] }
]

-- Listing 9-30: Using sp_executesql to Find Employee Information
DECLARE
  @ExecStr nvarchar (4000)

SET
  @ExecStr = N'SELECT * FROM '
           + N'Northwind.dbo.Employees '
           + N'WHERE EmployeeID = @EmployeeId'

sp_executesql
  @stmt       = @ExecStr,
  @params     = N'@EmployeeId int',
  @EmployeeId = 1

-- Listing 9-31: Sample Order Table
CREATE TABLE Orders2000
(
  OrderID    int      NOT NULL PRIMARY KEY,
  OrderDate  datetime NOT NULL,
  CustomerID int      NOT NULL,
  Total      money    NOT NULL
)

-- Listing 9-32: Building the @stmt String
SET
  @stmt = N'INSERT MyDB.dbo.Orders' + STR (YEAR (@OrderDate), 4)
        + N' (OrderID, OrderDate, CustomerID, Total)'
        + N' VALUES (@OrderID, @OrderDate, @CustomerID, @Total)'

-- Listing 9-33: Building the @params String
SET
  @params = N'@OrderID int, '
          + N'@OrderDate datetime, '
          + N'@CustomerID int, '
          + N'@Total money'

-- Listing 9-34: Executing sp_executesql
EXEC sp_executesql
  @stmt,
  @params     = @params,
  @OrderID    = @OrderID,
  @OrderDate  = @OrderDate,
  @CustomerID = @CustomerID,
  @Total      = @Total

-- Listing 9-35: Example of Rows Affected
(91 row(s) affected)

-- Listing 9-36: Turning off Rows Affected
SET NOCOUNT ON
ANSI_DEFAULTS

-- Listing 9-37: Turning off ANSI Defaults
SET ANSI_DEFAULTS OFF

-- Listing 9-38: Syntax for SET TRANSACTION ISOLATION LEVEL
SET TRANSACTION ISOLATION LEVEL 
  { READ COMMITTED 
    | READ UNCOMMITTED 
    | REPEATABLE READ 
    | SERIALIZABLE 
}

-- Listing 9-39: Script which Allows Nonrepeatable Reads
SET TRANSACTION ISOLATION LEVEL READ COMMITTED  -- nonrepeatable reads
                                                -- are now possible
-- initial SELECT
SELECT
  *
FROM
  Orders
WHERE
  CustomerID = 'VINET'

-- another process now updates an order for
-- Customer ID = 'VINET'

-- this SELECT does not return exactly the same data as
-- the previous SELECT
SELECT
  *
FROM
  Orders
WHERE
  CustomerID = 'VINET'

-- Listing 9-40: Setting the Transaction Isolation Level
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
LOCK_TIMEOUT

-- Listing 9-41: Setting the LOCK_TIMEOUT to One Minute
SET LOCK_TIMEOUT 60000
QUERY_GOVERNOR_COST_LIMIT

-- Listing 9-42: Setting the QUERY_GOVERNOR_COST_LIMIT to One Minute
SET QUERY_GOVERNOR_COST_LIMIT 60

-- Listing 9-43: Example of sp_helptext
EXEC sp_helptext
  usp_GetOrderDetails

-- Listing 9-44: Example of Using sp_recompile
EXEC sp_recompile
  Customers

-- Listing 9-45: Syntax for sp_procoption
sp_procoption
    [[@ProcName =] 'procedure']
    [,[@OptionName =] 'option']
    [,[@OptionValue =] 'value']

-- Listing 9-46: Creating a System Stored Procedure that Modifies a System Table
sp_configure 'allow', 1
GO
RECONFIGURE WITH OVERRIDE
GO
CREATE PROC sp__MySystemProc AS ...
GO
sp_configure 'allow', 0
GO
RECONFIGURE WITH OVERRIDE
GO

-- Listing 9-47: Example of Recursion Using a Stored Procedure
CREATE PROC usp_FindBoss
(
  @EmployeeID  int
)
AS
DECLARE
  @ReportsTo  int

SELECT
  @ReportsTo  = ReportsTo
FROM
    Employees
WHERE
    EmployeeId = @EmployeeID

IF @ReportsTo IS NOT NULL AND @@NESTLEVEL <= 32
BEGIN
  SELECT
    @EmployeeID AS Employee,
    @ReportsTo  AS Manager

  EXEC usp_FindBoss
    @ReportsTo
END
GO

-- Listing 9-48: Results of Executing sup_FindBoss for EmployeeID 7
Employee    Manager     
----------- ----------- 
          7           5 

Employee    Manager     
----------- ----------- 
          5           2

-- Listing 9-49: Example of GRANT EXEC Statement
GRANT EXEC on usp_FindBoss to
  Itzik,
  Tom

-- Listing 9-50: Managing a Transaction Inside a Stored Procedure
CREATE PROC usp_MyProc
AS
DECLARE
  @TranCount  int

SET
  @TranCount = @@TRANCOUNT

IF @TranCount > 0
  SAVE TRAN usp_MyProc             -- Transaction in progress
ELSE
  BEGIN TRAN usp_MyProc            -- No existing transaction

-- do work here ...

IF @@ERROR > 0
BEGIN                              -- Failure
  RAISERROR ('usp_MyProc - Bailing out. ', 16, 1)
  ROLLBACK TRAN usp_MyProc
  RETURN
END
ELSE IF @Trancount = 0             -- Started our own transaction
  COMMIT TRAN usp_MyProc           -- Success
GO

