-------------------------------------------------
-- Chapter 13 - Horizontally Partitioned Views --
-------------------------------------------------

-- Listing 13-1: Original Orders Table Schema
CREATE TABLE Orders
(
OrderID    int      NOT NULL
                    CONSTRAINT PK_Orders_OrderID
                      PRIMARY KEY(OrderID),
CustomerID int      NOT NULL,
OrderDate  datetime NOT NULL
/* ...  other columns ...  */
) 
GO

-- Listing 13-2: Partitioning the Orders Table
CREATE TABLE Orders1998
(
OrderID    int      NOT NULL
                    CONSTRAINT PK_Orders1998_OrderID
                      PRIMARY KEY(OrderID),
CustomerID int      NOT NULL,
OrderDate  datetime NOT NULL
                    CONSTRAINT CHK_Orders1998_OrderDate
                      CHECK (YEAR(OrderDate) = 1998),
OrderYear  int      NOT NULL
                    CONSTRAINT DF_Orders1998_OrderYear
                      DEFAULT 1998
                    CONSTRAINT CHK_Orders1998_OrderYear
                      CHECK (OrderYear = 1998),  -- partitioning column
/* ...  other columns ...  */
) 
GO

CREATE TABLE Orders1999
(
OrderID    int      NOT NULL
                    CONSTRAINT PK_Orders1999_OrderID
                      PRIMARY KEY(OrderID),
CustomerID int      NOT NULL,
OrderDate  datetime NOT NULL
                    CONSTRAINT CHK_Orders1999_OrderDate
                      CHECK (YEAR(OrderDate) = 1999),
OrderYear  int      NOT NULL
                    CONSTRAINT DF_Orders1999_OrderYear
                      DEFAULT 1999
                    CONSTRAINT CHK_Orders1999_OrderYear
                      CHECK (OrderYear = 1999),  -- partitioning column
/* ...  other columns ...  */
) 
GO

CREATE TABLE Orders2000
(
OrderID    int      NOT NULL
                    CONSTRAINT PK_Orders2000_OrderID
                      PRIMARY KEY(OrderID),
CustomerID int      NOT NULL,
OrderDate  datetime NOT NULL
                    CONSTRAINT CHK_Orders2000_OrderDate
                      CHECK (YEAR(OrderDate) = 2000),
OrderYear  int      NOT NULL
                    CONSTRAINT DF_Orders2000_OrderYear
                      DEFAULT 2000
                    CONSTRAINT CHK_Orders2000_OrderYear
                      CHECK (OrderYear = 2000),  -- partitioning column
/* ...  other columns ...  */
) 
GO

-- Listing 13-3: A View that Assembles Partitioned Tables
CREATE VIEW VOrders
AS

SELECT * FROM Orders1998
UNION ALL
SELECT * FROM Orders1999
UNION ALL
SELECT * FROM Orders2000
GO

-- Listing 13-4: Stored Procedure that Inserts a New Order in the Right Partition
CREATE PROCEDURE InsertOrder
  @OrderID int,
  @CustomerID int,
  @OrderDate datetime
AS

DECLARE @cmd nvarchar(4000)

-- construct the insert statement
SET @cmd =
  'INSERT INTO Orders' +
  CAST(YEAR(@OrderDate) AS nchar(4)) + -- determine destination table
  '(OrderID, CustomerID, OrderDate)' +
  ' VALUES(@OrderID, @CustomerID, @OrderDate)'

-- execute the insert
EXEC sp_executesql @cmd,
  N'@OrderID int, @CustomerID int, @OrderDate datetime',
  @OrderID, @CustomerID, @OrderDate
GO

-- Listing 13-5: Using the InsertOrder Stored Procedure to Insert a New Order
EXEC InsertOrder    1, 11111, '19980101'

-- Listing 13-6: Using the InsertOrder Stored Procedure to Insert More Sample Orders
EXEC InsertOrder    2, 22222, '19980101'
EXEC InsertOrder 1001, 22222, '19990101'
EXEC InsertOrder 1002, 33333, '19990101'
EXEC InsertOrder 2001, 33333, '20000101'
EXEC InsertOrder 2002, 44444, '20000101'

SELECT * FROM VOrders

-- Listing 13-7: Inefficient Query against a Local Partitioned View
SELECT
  *
FROM
    VOrders
WHERE
    CustomerID = 11111
  AND
    YEAR(OrderDate) = 1998

-- Listing 13-8: Efficient Query Against a Local Partitioned View
SELECT
  *
FROM
    VOrders
WHERE
    CustomerID = 11111
  AND
    OrderYear = 1998

-- Listing 13-9: Efficient Complex Query against a Local Partitioned View
SELECT
  COALESCE(Cust1998, Cust1999) AS CustomerID,
  CASE
    WHEN Cust1998 IS NULL THEN 'No'
    ELSE 'Yes'
  END AS [Ordered in 1998],
  CASE
    WHEN Cust1999 IS NULL THEN 'No'
    ELSE 'Yes'
  END AS [Ordered in 1999]
FROM
    (SELECT
       DISTINCT(CustomerID) AS Cust1998
     FROM
       VOrders AS O1998
     WHERE
       OrderYear = 1998) AS O1998
  FULL OUTER JOIN
    (SELECT
       DISTINCT(CustomerID) AS Cust1999
     FROM
       VOrders
     WHERE
       OrderYear = 1999) AS O1999 ON Cust1998 = Cust1999
WHERE
    Cust1998 IS NULL
  OR
    Cust1999 IS NULL

-- Listing 13-10: Set Up Linked Servers on Node1
-- Run on Node1 - Shire\Shiloh

USE master
GO

-- Connect to Hobbiton\Shiloh, call it Node2
EXEC sp_addlinkedserver
  @server='Node2',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Hobbiton\Shiloh'

-- Connect to Rivendell\Shiloh, call it Node3
EXEC sp_addlinkedserver
  @server='Node3',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Rivendell\Shiloh'
GO

-- Postpone requsting metadata until data is actually needed
EXEC sp_serveroption 'Node2', 'lazy schema validation', true
EXEC sp_serveroption 'Node3', 'lazy schema validation', true
GO

-- Listing 13-11: Set Up Linked Servers on Node2
-- Run on Node2 - Hobbiton\Shiloh

USE master
GO

-- Connect to Shire\Shiloh, call it Node1
EXEC sp_addlinkedserver
  @server='Node1',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Shire\Shiloh'

-- Connect to Rivendell\Shiloh, call it Node3
EXEC sp_addlinkedserver
  @server='Node3',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Rivendell\Shiloh'
GO

-- Postpone requsting metadata until data is actually needed
EXEC sp_serveroption 'Node1', 'lazy schema validation', true
EXEC sp_serveroption 'Node3', 'lazy schema validation', true
GO

-- Listing 13-12: Set Up Linked Servers on Node3
-- Run on Node3 - Rivendell\Shiloh

USE master
GO

-- Connect to Shire\Shiloh, call it Node1
EXEC sp_addlinkedserver
  @server='Node1',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Shire\Shiloh'

-- Connect to Hobbiton\Shiloh, call it Node2
EXEC sp_addlinkedserver
  @server='Node2',
  @srvproduct='',
  @provider='SQLOLEDB',
  @datasrc='Hobbiton\Shiloh'
GO

-- Postpone requsting metadata until data is actually needed
EXEC sp_serveroption 'Node1', 'lazy schema validation', true
EXEC sp_serveroption 'Node2', 'lazy schema validation', true
GO

-- Listing 13-13: Create Partitioned Tables on Node1
-- Run on Node1 - Shire\Shiloh

-- Create the testdb database
CREATE DATABASE testdb
GO

USE testdb
GO

CREATE TABLE CustomersAF(
  CustomerID   nchar(5)     NOT NULL,
  CompanyName  nvarchar(40) NOT NULL,
  ContactName  nvarchar(30) NULL,
  ContactTitle nvarchar(30) NULL,
  Address      nvarchar(60) NULL,
  City         nvarchar(15) NULL,
  Region       nvarchar(15) NULL,
  PostalCode   nvarchar(10) NULL,
  Country      nvarchar(15) NULL,
  Phone        nvarchar(24) NULL,
  Fax          nvarchar(24) NULL,
  CONSTRAINT PK_CustomersAF PRIMARY KEY CLUSTERED(CustomerID),
  CONSTRAINT CHK_CustomersAF CHECK (CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'))
GO

CREATE TABLE OrdersAF(
  OrderID        int          NOT NULL,
  CustomerID     nchar(5)     NOT NULL,
  EmployeeID     int          NULL,
  OrderDate      datetime     NULL,
  RequiredDate   datetime     NULL,
  ShippedDate    datetime     NULL,
  ShipVia        int          NULL,
  Freight        money        NULL,
  ShipName       nvarchar(40) NULL,
  ShipAddress    nvarchar(60) NULL,
  ShipCity       nvarchar(15) NULL,
  ShipRegion     nvarchar(15) NULL,
  ShipPostalCode nvarchar(10) NULL,
  ShipCountry    nvarchar(15) NULL,
  CONSTRAINT PK_OrdersAF PRIMARY KEY CLUSTERED(CustomerID, OrderID),
  CONSTRAINT UNQ_OrdersAF_OrderID UNIQUE(OrderID),
  CONSTRAINT FK_OrdersAF_CustomersAF
    FOREIGN KEY (CustomerID)
    REFERENCES CustomersAF(CustomerID),
  CONSTRAINT CHK_OrdersAF CHECK (CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'))
GO

-- Listing 13-14: Create Partitioned Tables on Node2
-- Run on Node2 - Hobbiton\Shiloh

-- Create the testdb database
CREATE DATABASE testdb
GO

USE testdb
GO

CREATE TABLE CustomersGP(
  customerid   nchar(5)     NOT NULL,
  companyname  nvarchar(40) NOT NULL,
  contactname  nvarchar(30) NULL,
  contacttitle nvarchar(30) NULL,
  address      nvarchar(60) NULL,
  city         nvarchar(15) NULL,
  region       nvarchar(15) NULL,
  postalcode   nvarchar(10) NULL,
  country      nvarchar(15) NULL,
  phone        nvarchar(24) NULL,
  fax          nvarchar(24) NULL,
  CONSTRAINT PK_CustomersGP PRIMARY KEY CLUSTERED(customerid),
  CONSTRAINT CHK_CustomersGP CHECK (customerid BETWEEN 'GAAAA' AND 'PZZZZ'))
GO

CREATE TABLE OrdersGP(
  orderid        int          NOT NULL,
  customerid     nchar(5)     NOT NULL,
  employeeid     int          NULL,
  orderdate      datetime     NULL,
  requireddate   datetime     NULL,
  shippeddate    datetime     NULL,
  shipvia        int          NULL,
  freight        money        NULL,
  shipname       nvarchar(40) NULL,
  shipaddress    nvarchar(60) NULL,
  shipcity       nvarchar(15) NULL,
  shipregion     nvarchar(15) NULL,
  shippostalcode nvarchar(10) NULL,
  shipcountry    nvarchar(15) NULL,
  CONSTRAINT PK_OrdersGP PRIMARY KEY CLUSTERED(customerid, orderid),
  CONSTRAINT UNQ_OrdersGP_OrderID UNIQUE(OrderID),
  CONSTRAINT FK_OrdersGP_CustomersGP
    FOREIGN KEY (customerid)
    REFERENCES CustomersGP(customerid),
  CONSTRAINT CHK_OrdersGP CHECK (customerid BETWEEN 'GAAAA' AND 'PZZZZ'))
GO

-- Listing 13-15: Create Partitioned Tables on Node3
-- Run on Node3 - Rivendell\Shiloh

-- Create the testdb database
CREATE DATABASE testdb
GO

USE testdb
GO

CREATE TABLE CustomersQZ(
  customerid   nchar(5)     NOT NULL,
  companyname  nvarchar(40) NOT NULL,
  contactname  nvarchar(30) NULL,
  contacttitle nvarchar(30) NULL,
  address      nvarchar(60) NULL,
  city         nvarchar(15) NULL,
  region       nvarchar(15) NULL,
  postalcode   nvarchar(10) NULL,
  country      nvarchar(15) NULL,
  phone        nvarchar(24) NULL,
  fax          nvarchar(24) NULL,
  CONSTRAINT PK_CustomersQZ PRIMARY KEY CLUSTERED(customerid),
  CONSTRAINT CHK_CustomersQZ CHECK (customerid BETWEEN 'QAAAA' AND 'ZZZZZ'))
GO

CREATE TABLE OrdersQZ(
  orderid        int          NOT NULL,
  customerid     nchar(5)     NOT NULL,
  employeeid     int          NULL,
  orderdate      datetime     NULL,
  requireddate   datetime     NULL,
  shippeddate    datetime     NULL,
  shipvia        int          NULL,
  freight        money        NULL,
  shipname       nvarchar(40) NULL,
  shipaddress    nvarchar(60) NULL,
  shipcity       nvarchar(15) NULL,
  shipregion     nvarchar(15) NULL,
  shippostalcode nvarchar(10) NULL,
  shipcountry    nvarchar(15) NULL,
  CONSTRAINT PK_OrdersQZ PRIMARY KEY CLUSTERED(customerid, orderid),
  CONSTRAINT UNQ_OrdersQZ_OrderID UNIQUE(OrderID),
  CONSTRAINT FK_OrdersQZ_CustomersQZ
    FOREIGN KEY (customerid)
    REFERENCES CustomersQZ(customerid),
  CONSTRAINT CHK_OrdersQZ CHECK (customerid BETWEEN 'QAAAA' AND 'ZZZZZ'))
GO

-- Listing 13-16: Create Partitioned Views on Node1
-- Run on Node1 - Shire\Shiloh

CREATE VIEW Customers
AS

SELECT * FROM CustomersAF
UNION ALL
SELECT * FROM Node2.testdb.dbo.CustomersGP
UNION ALL
SELECT * FROM Node3.testdb.dbo.CustomersQZ
GO

CREATE VIEW Orders
AS

SELECT * FROM OrdersAF
UNION ALL
SELECT * FROM Node2.testdb.dbo.OrdersGP
UNION ALL
SELECT * FROM Node3.testdb.dbo.OrdersQZ
GO

-- Run on Node2 - Hobbiton/Shiloh
CREATE VIEW Customers
AS

SELECT * FROM Node1.testdb.dbo.CustomersAF
UNION ALL
SELECT * FROM CustomersGP
UNION ALL
SELECT * FROM Node3.testdb.dbo.CustomersQZ
GO

CREATE VIEW Orders
AS

SELECT * FROM Node1.testdb.dbo.OrdersAF
UNION ALL
SELECT * FROM OrdersGP
UNION ALL
SELECT * FROM Node3.testdb.dbo.OrdersQZ
GO

-- Run on Node3 - Rivendell/Shiloh
CREATE VIEW Customers
AS

SELECT * FROM Node1.testdb.dbo.CustomersAF
UNION ALL
SELECT * FROM Node2.testdb.dbo.CustomersGP
UNION ALL
SELECT * FROM CustomersQZ
GO

CREATE VIEW Orders
AS

SELECT * FROM Node1.testdb.dbo.OrdersAF
UNION ALL
SELECT * FROM Node2.testdb.dbo.OrdersGP
UNION ALL
SELECT * FROM OrdersQZ
GO

-- Listing 13-17: Populating Data through the Customers View
-- Run on Node1 - Shire\Shiloh

-- Required for remote modifications
SET XACT_ABORT ON
GO

-- Populate the Customers view
INSERT INTO Customers
  SELECT * FROM Northwind.dbo.Customers

-- Listing 13-18: Modifying Data through the Customers View
-- Modifications resulting in modifying the local table
INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax)
  VALUES('AAAAA', 'CompA', 'ContA', 'ContTitleA', 'AddA', 'CityA', 'RegionA', 'PCA', 'CoutryA', 'PhoneA', 'FaxA')

UPDATE Customers
  SET CompanyName = 'CompAA'
WHERE
  CustomerID = 'AAAAA'

DELETE FROM Customers
WHERE
  CustomerID = 'AAAAA'

-- Modifications resulting in modifying a remote table
INSERT INTO Customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax)
  VALUES('ZZZZZ', 'CompZ', 'ContZ', 'ContTitleZ', 'AddZ', 'CityZ', 'RegionZ', 'PCZ', 'CoutryZ', 'PhoneZ', 'FaxZ')

UPDATE Customers
  SET CompanyName = 'CompZZ'
WHERE
  CustomerID = 'ZZZZZ'

DELETE FROM Customers
WHERE
  CustomerID = 'ZZZZZ'

-- Listing 13-19: Populating Data through the Orders View
-- Populate the Orders view
INSERT INTO Orders
  SELECT * FROM Northwind.dbo.Orders

-- Listing 13-20: Selecting All Rows from the Customers View
SELECT
  *
FROM
    Customers

-- Listing 13-21: Selecting a Local Customer from the Customers View
SELECT
  *
FROM
    Customers
WHERE
    CustomerID = 'ALFKI'

-- Listing 13-22: STATISTICS PROFILE Output for a Query against the Customers View
Rows   Executes    StmtText
1     1            SELECT * FROM [Customers] WHERE [customerid]=@1
1     1              |--Compute Scalar
                     (DEFINE:([CustomersAF].[CustomerID]=
                              [CustomersAF].[CustomerID],
                              [CustomersAF].[CompanyName]=
                              [CustomersAF].[CompanyName],
                              [CustomersAF].[ContactName]=
                              [CustomersAF].[ContactName],
                              [CustomersAF].[ContactTitle]=
                              [CustomersAF].[ContactTitle], 
1     1                |--Clustered Index Seek(OBJECT:
                          ([testdb].[dbo].[CustomersAF].[PK_CustomersAF]),
                          SEEK:([CustomersAF].[CustomerID]='ALFKI')
                          ORDERED FORWARD)

-- Listing 13-23: Selecting a Remote Customer from the Customers View
SELECT
  *
FROM
    Customers
WHERE
    CustomerID = 'OLDWO'

-- Listing 13-24: Selecting Local Customers from the Customers View using the OR Operator
SELECT
  *
FROM
    Customers
WHERE
    CustomerID = 'ALFKI'
  OR
    CustomerID = 'ANATR'

-- Listing 13-25: Selecting Remote Customers from the Customers View using the OR Operator
SELECT
  *
FROM
    Customers
WHERE
    CustomerID = 'WILMK'
  OR
    CustomerID = 'WOLZA'

-- Listing 13-26: Using a GROUP BY Query against the Orders View
SELECT
  CustomerID,
  COUNT(*) AS Count_Orders
FROM
  Orders
GROUP BY
  CustomerID

-- Listing 13-27: Creating another Partitioned View, with OrderID as the Partitioning Column
-- Run on Node1
-- Create the partitioned table on Node1
CREATE TABLE OrdersA(
  OrderID        int          NOT NULL,
  CustomerID     nchar(5)     NOT NULL,
  EmployeeID     int          NULL,
  OrderDate      datetime     NULL,
  RequiredDate   datetime     NULL,
  ShippedDate    datetime     NULL,
  ShipVia        int          NULL,
  Freight        money        NULL,
  ShipName       nvarchar(40) NULL,
  ShipAddress    nvarchar(60) NULL,
  ShipCity       nvarchar(15) NULL,
  ShipRegion     nvarchar(15) NULL,
  ShipPostalCode nvarchar(10) NULL,
  ShipCountry    nvarchar(15) NULL,
  CONSTRAINT PK_Orders1 PRIMARY KEY CLUSTERED(OrderID),
  CONSTRAINT CHK_Orders1 CHECK (OrderID < 10500))
GO

-- Run on Node2
-- Create the partitioned table on Node2
CREATE TABLE OrdersB(
  OrderID        int          NOT NULL,
  CustomerID     nchar(5)     NOT NULL,
  EmployeeID     int          NULL,
  OrderDate      datetime     NULL,
  RequiredDate   datetime     NULL,
  ShippedDate    datetime     NULL,
  ShipVia        int          NULL,
  Freight        money        NULL,
  ShipName       nvarchar(40) NULL,
  ShipAddress    nvarchar(60) NULL,
  ShipCity       nvarchar(15) NULL,
  ShipRegion     nvarchar(15) NULL,
  ShipPostalCode nvarchar(10) NULL,
  ShipCountry    nvarchar(15) NULL,
  CONSTRAINT PK_OrdersA PRIMARY KEY CLUSTERED(OrderID),
  CONSTRAINT CHK_OrdersA CHECK (OrderID between 10500 and 10750))
GO

-- Run on Node3
-- Create the partitioned table on Node3
CREATE TABLE OrdersC(
  OrderID        int          NOT NULL,
  CustomerID     nchar(5)     NOT NULL,
  EmployeeID     int          NULL,
  OrderDate      datetime     NULL,
  RequiredDate   datetime     NULL,
  ShippedDate    datetime     NULL,
  ShipVia        int          NULL,
  Freight        money        NULL,
  ShipName       nvarchar(40) NULL,
  ShipAddress    nvarchar(60) NULL,
  ShipCity       nvarchar(15) NULL,
  ShipRegion     nvarchar(15) NULL,
  ShipPostalCode nvarchar(10) NULL,
  ShipCountry    nvarchar(15) NULL,
  CONSTRAINT PK_OrdersC PRIMARY KEY CLUSTERED(OrderID),
  CONSTRAINT CHK_OrdersC CHECK (OrderID > 10750))
GO

-- Run on Node1
-- Create the partitioned view on Node1
CREATE VIEW Orders2
AS

SELECT * FROM OrdersA
UNION ALL
SELECT * FROM Node2.testdb.dbo.OrdersB
UNION ALL
SELECT * FROM Node3.testdb.dbo.OrdersC
GO

-- Run on Node1
-- Populate the view
SET XACT_ABORT ON
GO
INSERT INTO Orders2
  SELECT * FROM Northwind.dbo.Orders
GO

-- Listing 13-28: Using a JOIN Query against Two Views that are Partitioned on the Same Criteria
SELECT
  *
FROM
    Customers AS C
  JOIN
    Orders    AS O ON C.CustomerID = O.CustomerID

-- Listing 13-29: Using a JOIN Query against Two Views which are Partitioned on Different Criterions
SELECT
  *
FROM
    Customers AS C
  JOIN
    Orders2   AS O ON C.CustomerID = O.CustomerID

-- Listing 13-30: Recreate the Primary Key of the Orders� Partitions to Include Only the OrderID Column
-- Run on Node1
-- Recreate the primary key only on the OrderID column
ALTER TABLE OrdersAF
  DROP CONSTRAINT PK_OrdersAF
GO

ALTER TABLE OrdersAF
  ADD CONSTRAINT PK_OrdersAF PRIMARY KEY(OrderID)
GO

-- Create an index on CustomerID
CREATE NONCLUSTERED INDEX idx_nci_CustomerID ON OrdersAF(CustomerID)
GO

-- Run on Node2
-- Recreate the primary key only on the OrderID column
ALTER TABLE OrdersGP
  DROP CONSTRAINT PK_OrdersGP
GO

ALTER TABLE OrdersGP
  ADD CONSTRAINT PK_OrdersGP PRIMARY KEY(OrderID)
GO

-- Create an index on CustomerID
CREATE NONCLUSTERED INDEX idx_nci_CustomerID ON OrdersGP(CustomerID)
GO

-- Run on Node3
-- Recreate the primary key only on the OrderID column
ALTER TABLE OrdersQZ
  DROP CONSTRAINT PK_OrdersQZ
GO

ALTER TABLE OrdersQZ
  ADD CONSTRAINT PK_OrdersQZ PRIMARY KEY(OrderID)
GO

-- Create an index on CustomerID
CREATE NONCLUSTERED INDEX idx_nci_CustomerID ON OrdersQZ(CustomerID)
GO

-- Listing 13-31: Trying to Insert a Row to a Non-Updateable View
-- Run on Node1
-- Try to insert a new row
INSERT INTO Orders(OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry)
  VALUES(10247, N'VINET', 5, '1996-07-04 00:00:00.000', '1996-08-01 00:00:00.000', '1996-07-16 00:00:00.000', 3, 32.3800, N'Vins et alcools Chevalier', N'59 rue de l''Abbaye', N'Reims', NULL, N'51100', N'France')

-- Listing 13-32: Error for Trying to Insert a Row to a Non-Updateable View
Server: Msg 4436, Level 16, State 13, Line 1
UNION ALL view 'Orders' is not updatable because a partitioning column was not found.

-- Listing 13-33: INSTEAD OF INSERT Trigger on the Orders View
-- Run on Node1
CREATE TRIGGER trg_i_orders ON Orders INSTEAD OF INSERT
AS

-- First, ensure we have rows to process
IF @@ROWCOUNT = 0
  RETURN

-- Next, make sure that all of the data meets the CHECK constraint
IF EXISTS(SELECT *
          FROM inserted
          WHERE CustomerID < 'A'
             OR CustomerID > 'ZZZZZ')
BEGIN
  RAISERROR('Trying to insert illegal customer ids.  Transaction rolled back', 16, 1)
  ROLLBACK TRANSACTION
END
ELSE
BEGIN
  
  BEGIN DISTRIBUTED TRANSACTION

  -- insert rows to the OrdersAF table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ')
    INSERT INTO OrdersAF -- local
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'

  -- insert rows to the OrdersGP table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ')
    INSERT INTO Node2.testdb.dbo.OrdersGP
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ'

  -- insert rows to the OrdersQZ table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ')
    INSERT INTO Node3.testdb.dbo.OrdersQZ
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ'

  COMMIT TRANSACTION

END    
GO

-- Listing 13-34: INSTEAD OF DELETE Trigger on the Orders View
-- Run on Node1
CREATE TRIGGER trg_d_orders ON Orders INSTEAD OF DELETE
AS

-- ensure we have rows to process
IF @@ROWCOUNT = 0
  RETURN

BEGIN DISTRIBUTED TRANSACTION

-- delete rows from the OrdersAF table
IF EXISTS(SELECT *
          FROM deleted
          WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ')
  DELETE FROM OrdersAF -- local
  FROM OrdersAF AS O JOIN deleted AS D
    ON  O.OrderID = D.OrderID
    AND O.CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'

-- delete rows from the OrdersGP table
IF EXISTS(SELECT *
          FROM deleted
          WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ')
  DELETE FROM Node2.testdb.dbo.OrdersGP
  FROM Node2.testdb.dbo.OrdersGP AS O JOIN deleted AS D
    ON  O.OrderID = D.OrderID
    AND O.CustomerID BETWEEN 'GAAAA' AND 'PZZZZ'

-- delete rows from the OrdersQZ table
IF EXISTS(SELECT *
          FROM deleted
          WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ')
  DELETE FROM Node3.testdb.dbo.OrdersQZ
  FROM Node3.testdb.dbo.OrdersQZ AS O JOIN deleted AS D
    ON  O.OrderID = D.OrderID
    AND O.CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ'

COMMIT TRANSACTION
GO

-- Listing 13-35: INSTEAD OF UPDATE Trigger on the Orders View
-- Run on Node1
CREATE TRIGGER trg_u_orders ON Orders INSTEAD OF UPDATE
AS

-- ensure we have rows to process
IF @@ROWCOUNT = 0
  RETURN

-- Make sure that all of the data meets the CHECK constraint
IF EXISTS(SELECT *
          FROM inserted
          WHERE CustomerID < 'A'
             OR CustomerID > 'ZZZZZ')
BEGIN
  RAISERROR('Trying to insert illegal customer ids.  Transaction rolled back', 16, 1)
  ROLLBACK TRANSACTION
END
ELSE
BEGIN
  
  BEGIN DISTRIBUTED TRANSACTION

  -- delete rows from the OrdersAF table
  IF EXISTS(SELECT *
            FROM deleted
            WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ')
    DELETE FROM OrdersAF -- local
    FROM OrdersAF AS O JOIN deleted AS D
      ON  O.OrderID = D.OrderID
      AND O.CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'

  -- delete rows from the OrdersGP table
  IF EXISTS(SELECT *
            FROM deleted
            WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ')
    DELETE FROM Node2.testdb.dbo.OrdersGP
    FROM Node2.testdb.dbo.OrdersGP AS O JOIN deleted AS D
      ON  O.OrderID = D.OrderID
      AND O.CustomerID BETWEEN 'GAAAA' AND 'PZZZZ'

  -- delete rows from the OrdersQZ table
  IF EXISTS(SELECT *
            FROM deleted
            WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ')
    DELETE FROM Node3.testdb.dbo.OrdersQZ
    FROM Node3.testdb.dbo.OrdersQZ AS O JOIN deleted AS D
      ON  O.OrderID = D.OrderID
      AND O.CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ'

  -- insert rows to the OrdersAF table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ')
    INSERT INTO OrdersAF -- local
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'AAAAA' AND 'FZZZZ'

  -- insert rows to the OrdersGP table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ')
    INSERT INTO Node2.testdb.dbo.OrdersGP
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'GAAAA' AND 'PZZZZ'

  -- insert rows to the OrdersQZ table
  IF EXISTS(SELECT *
            FROM inserted
            WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ')
    INSERT INTO Node3.testdb.dbo.OrdersQZ
      SELECT * FROM inserted
      WHERE CustomerID BETWEEN 'QAAAA' AND 'ZZZZZ'

  COMMIT TRANSACTION

END    
GO

-- Listing 13-36: Modifying a View with INSTEAD OF Triggers Defined
-- Run modifications from any of the nodes to test the triggers,
-- assuming that INSTEAD OF triggers were created on all of them 
SET XACT_ABORT ON
GO

SELECT * FROM Orders

DELETE FROM Orders

SELECT * FROM Orders

INSERT INTO Orders
  SELECT * FROM Northwind.dbo.Orders

SELECT * FROM Orders

UPDATE Orders
  SET OrderID = 21325 - OrderID

SELECT * FROM Orders
