--------------------------
-- SQL Puzzle Solutions --
--------------------------

-- SQL Puzzle 1-Joins
SELECT
  *
FROM
    Departments AS D
  LEFT OUTER JOIN
    Employees   AS E ON  D.deptno = E.deptno
WHERE
    D.deptno IN(300, 400)
  AND
    E.salary > 2500.00

SELECT
  *
FROM
    Departments AS D
  LEFT OUTER JOIN
    Employees   AS E ON  D.deptno = E.deptno
                     AND E.salary > 2500.00 
WHERE
  D.deptno IN(300, 400)

-- SQL Puzzle 2.1-Bank Interest
SELECT
  R.AccountID,
  CONVERT (money,
    SUM (r.Rate * r.Balance) / 36500.00) AS Interest
FROM
(
  SELECT
    B.AccountID,
    B.Balance,
    MAX (i.Rate) AS Rate                 -- Highest rate
  FROM
      Interest AS I
    JOIN
      Balance  AS B ON I.Step <= B.Balance  -- at or below balance
  WHERE
      I.Date =
  (
    SELECT                               -- Most recent interest date
      MAX (II.Date)
    FROM
        Interest AS II
    WHERE                                -- in effect on balance date
        II.Date <= B.Date
  )
  GROUP BY
    B.AccountID,
    B.Date,
    B.Balance
) AS R
GROUP BY
  R.AccountID

-- SQL Puzzle 2.2-Managing Orders and Their Payments
SELECT
  O.orderid,
  custid,
  odate,
  SUM(qty)   AS sum_of_qty,
  SUM(value) AS sum_of_value
FROM
    Orders        AS O
  LEFT OUTER JOIN
    OrderDetails  AS OD ON O.orderid = OD.orderid
  LEFT OUTER JOIN
    OrderPayments AS OP ON O.orderid = OP.orderid
GROUP BY
  O.orderid,
  custid,
  odate

SELECT
  O.orderid,
  partno,
  qty,
  paymentno,
  value
FROM
    Orders        AS O
  LEFT OUTER JOIN
    OrderDetails  AS OD ON O.orderid = OD.orderid
  LEFT OUTER JOIN
    OrderPayments AS OP ON O.orderid = OP.orderid

SELECT
  O.orderid,
  custid,
  odate,
  sum_of_qty,
  sum_of_value
FROM
    Orders AS O
  JOIN
    (SELECT
       orderid,
       SUM(qty) AS sum_of_qty
     FROM
       OrderDetails
     GROUP BY
       orderid) AS OD ON O.orderid = OD.orderid
  JOIN
    (SELECT
       orderid,
       SUM(value) AS sum_of_value
     FROM
       OrderPayments
     GROUP BY
       orderid) AS OP ON O.orderid = OP.orderid

SELECT
  OOD.orderid,
  custid,
  odate,
  sum_of_qty,
  sum_of_value
FROM
    (SELECT
       O.orderid,
       custid,
       odate,
       SUM(qty) AS sum_of_qty
      FROM
          Orders       AS O
        LEFT OUTER JOIN
          OrderDetails AS OD ON O.orderid = OD.orderid
      GROUP BY
        O.orderid,
        custid,
        odate) AS OOD
  JOIN
    (SELECT
       O.orderid,
       SUM(value) AS sum_of_value
     FROM
         Orders        AS O
       LEFT OUTER JOIN
         OrderPayments AS OP ON O.orderid = OP.orderid
     GROUP BY O.orderid) AS OOP ON OOD.orderid = OOP.orderid

SELECT
  O.orderid,
  custid,
  odate,
  (SELECT
     SUM(qty)
   FROM
     OrderDetails AS OD
   WHERE
     O.orderid = OD.orderid) AS sum_of_qty,
  (SELECT
     SUM(value)
   FROM
     OrderPayments AS OP
   WHERE
     O.orderid = OP.orderid) AS sum_of_value
FROM
  Orders AS O

-- SQL Puzzle 2.3-Finding Unread Messages

SELECT *
FROM
    Users AS U
  CROSS JOIN
    Messages AS M

SELECT *
FROM
    (SELECT *
     FROM
         Users AS U
       CROSS JOIN
         Messages AS M) AS UM
  LEFT OUTER JOIN
    Messagesread AS MR ON  UM.userid = MR.userid
                       AND UM.msgid  = MR.msgid

SELECT
  UM.username,
  UM.msg
FROM
    (SELECT *
     FROM
         Users AS U
       CROSS JOIN
         Messages AS M) AS UM
  LEFT OUTER JOIN
    Messagesread AS MR ON  UM.userid = MR.userid
                       AND UM.msgid  = MR.msgid
WHERE
  MR.userid IS NULL

-- SQL Puzzle 3-Populating the Customers Table
CREATE TABLE FirstName
(
  FirstNameID int       NOT NULL
                        IDENTITY (1, 1)
                        PRIMARY KEY,
  FirstName   char (25) NOT NULL
)
GO

INSERT FirstName (FirstName) VALUES ('Tom')
INSERT FirstName (FirstName) VALUES ('Dick')
INSERT FirstName (FirstName) VALUES ('Harry')
GO

CREATE TABLE LastName
(
  LastNameID int       NOT NULL
                       IDENTITY (1, 1)
                       PRIMARY KEY,
  LastName   char (30) NOT NULL
)
GO

INSERT LastName (LastName) VALUES ('Smith')
INSERT LastName (LastName) VALUES ('Jones')
INSERT LastName (LastName) VALUES ('Goldman')
INSERT LastName (LastName) VALUES ('Wong')
INSERT LastName (LastName) VALUES ('Martinez')
INSERT LastName (LastName) VALUES ('Yeung')
INSERT LastName (LastName) VALUES ('Gates')
INSERT LastName (LastName) VALUES ('Croft')
INSERT LastName (LastName) VALUES ('Bush')
INSERT LastName (LastName) VALUES ('Van Halen')
INSERT LastName (LastName) VALUES ('Santana')
GO

CREATE TABLE Street
(
  StreetID int       NOT NULL
                     IDENTITY (1, 1)
                     PRIMARY KEY,
  Street   char (50) NOT NULL
)
GO

INSERT Street (Street) VALUES ('Main St.')
INSERT Street (Street) VALUES ('Colorado Blvd.')
INSERT Street (Street) VALUES ('Pine Ave.')
INSERT Street (Street) VALUES ('Elm St.')
GO

CREATE TABLE City
(
  CityID     int       NOT NULL
                       IDENTITY (1, 1)
                       PRIMARY KEY,
  City       char (30) NOT NULL,
  Province   char (2)  NOT NULL
)
GO

INSERT City (City, Province) VALUES ('Toronto', 'ON')
INSERT City (City, Province) VALUES ('Vancouver', 'BC')
INSERT City (City, Province) VALUES ('Calgary', 'AB')
INSERT City (City, Province) VALUES ('Montreal', 'QC')
GO

INSERT Customers
(
  FirstName,
  LastName,
  Number,
  Street,
  City,
  Province
)
SELECT
  F.FirstName,
  L.LastName,
  S.StreetID      *  1000 +
    L.LastNameID  *   100 +
    F.FirstNameID *    10 +
    C.CityID,
  S.Street,
  C.City,
  C.Province
FROM
    FirstName F
  CROSS JOIN
    LastName  L
  CROSS JOIN
    Street    S
  CROSS JOIN
    City      C
GO

-- SQL Puzzle 4-Euro 2000 Theme
SELECT
  *
FROM
  Results
UNION ALL
SELECT
  matchid,
  team2      AS team1,
  team1      AS team2,
  team2goals AS team1goals,
  team1goals AS team2goals
FROM
  Results

SELECT
  country,
  COUNT(*) AS P,
  SUM(CASE SIGN(team1goals - team2goals)
        WHEN 1 THEN 1
        ELSE 0
      END) AS W,
  SUM(CASE SIGN(team1goals - team2goals)
        WHEN 0 THEN 1
        ELSE 0
      END) AS D,
  SUM(CASE SIGN(team1goals - team2goals)
        WHEN -1 THEN 1
        ELSE 0
      END) AS L,
  SUM(team1goals) AS F,
  SUM(team2goals) AS A,
  SUM(CASE SIGN(team1goals - team2goals)
        WHEN 1 THEN 3
        WHEN 0 THEN 1
        ELSE 0
      END) AS Points
FROM
    Teams AS T
  LEFT OUTER JOIN
    (SELECT *
     FROM Results
     UNION ALL
     SELECT
       matchid,
       team2      AS team1,
       team1      AS team2,
       team2goals AS team1goals,
       team1goals AS team2goals
     FROM Results) AS R
  ON T.teamid = R.team1
GROUP BY
  country
ORDER BY
  Points DESC

-- SQL Puzzle 5-Management Levels
SELECT
  ISNULL(Country, '<ALL>') AS Country,
  ISNULL(Region, CASE GROUPING(Region)
                   WHEN 1 THEN '<ALL>'
                   ELSE '<N/A>'
                 END) AS Region,
  ISNULL(City, '<ALL>') AS City,
  COUNT(*) AS Custs
FROM
  Customers
GROUP BY
  Country,
  Region,
  City
WITH ROLLUP

SELECT
  C.*,
  M.MgrLvl
FROM
    (<rollup_query>) AS C
  JOIN
    Mgrlevels AS M ON  Custs >= MinCusts
                   AND Custs <= ISNULL(MaxCusts, Custs)
GO

CREATE VIEW VCusts
AS

SELECT
  ISNULL(Country, '<ALL>') AS Country,
  ISNULL(Region, CASE GROUPING(Region)
                   WHEN 1 THEN '<ALL>'
                   ELSE '<N/A>'
                 END) AS Region,
  ISNULL(City, '<ALL>') AS City,
  COUNT(*) AS Custs
FROM
  Customers
GROUP BY
  Country,
  Region,
  City
WITH ROLLUP
GO

SELECT
  C.*,
  M.MgrLvl
FROM
    VCusts AS C
  JOIN
    Mgrlevels AS M ON  Custs >= MinCusts
                   AND Custs <= ISNULL(MaxCusts, Custs)

SELECT
  CASE
    WHEN City <> '<ALL>' THEN 'City'
    WHEN Region <> '<ALL>' AND Region <> '<N/A>' THEN 'Region'
    WHEN Country <> '<ALL>' THEN 'Country'
    ELSE 'The whole world'
  END AS AreaType,
  C.*,
  M.MgrLvl
FROM
    VCusts AS C
  JOIN
    Mgrlevels AS M ON  Custs >= MinCusts
                   AND Custs <= ISNULL(MaxCusts, Custs)

-- SQL Puzzle 6-Customers with and without Sales
SELECT
  C.Country,
  C.CustomerID,
  CASE
    WHEN ISNULL (SUM (OD.Quantity * OD.UnitPrice), 0) = 0
      THEN 'None'
    ELSE CAST (SUM (OD.Quantity * OD.UnitPrice) AS sql_variant)
  END AS TotalSales
FROM
    Customers       AS C
  LEFT
  JOIN
    Orders          AS O  ON O.CustomerID = C.CustomerID
  LEFT
  JOIN
    [Order Details] AS OD ON OD.OrderID   = O.OrderID
WHERE
  C.Country IN ('Spain', 'France')
GROUP BY
  C.Country,
  C.CustomerID
ORDER BY
  C.Country,
  C.CustomerID

-- SQL Puzzle 7-Eliminating an Explicit Transaction
UPDATE titleauthor
SET
  royaltyper = CASE au_id
                 WHEN '213-46-8915' THEN 60
                 WHEN '409-56-7008' THEN 40
                 ELSE royaltyper
               END
WHERE
   au_id    IN ('213-46-8915', '409-56-7008')
  AND
   title_id = 'BU1032'

--SQL Puzzle 8-Updateable Ordered View
EXEC sp_serveroption <server_name>, 'data access', true

CREATE VIEW V1
AS

SELECT
  *
FROM
  OPENQUERY(
    <server_name>,
    'SELECT * FROM <db_name>..T1 ORDER BY data_col') AS T1

-- SQL Puzzle 9.1 - Creating a Procedure within a Procedure
CREATE PROC usp_Generate_Customer_Proc
AS

DECLARE
  @str  varchar (8000)

-- create proc script
SELECT
  @str = 'CREATE PROC usp_Customer_Proc
          (
             @CustomerID char (5)
          )
          AS
          SET NOCOUNT ON

          SELECT
            *
          FROM
            Northwind..Customers
          WHERE
            CustomerID = @CustomerID'

-- create the proc
EXEC (@str)
GO

EXEC usp_Generate_Customer_Proc
GO

EXEC usp_Customer_Proc
  'VINET'
GO

DROP PROC usp_Customer_Proc
GO

DROP PROC usp_Generate_Customer_Proc
GO

--SQL Puzzle 9.2-Automatically Creating Stored Procedures
CREATE PROC usp_Generate_Table_Proc
(
  @Table sysname
)
AS

DECLARE
  @Str      varchar (8000),
  @Column   sysname,
  @DataType sysname

-- pick up column name and datatype of primary key
SELECT
  @Column   = COLUMN_NAME,
  @DataType = CASE
                WHEN DATA_TYPE IN
                  ('char', 'nchar', 'varchar', 'nvarchar')
                  THEN DATA_TYPE
                      + '('
                      + LTRIM (STR (CHARACTER_MAXIMUM_LENGTH))
                      + ')'
                ELSE
                  DATA_TYPE
                END
FROM
  INFORMATION_SCHEMA.COLUMNS
WHERE
    TABLE_NAME       = @Table
  AND
    ORDINAL_POSITION = 1

-- create proc script
SELECT
  @Str = 'CREATE PROC usp_' + @Table + '_Proc
          (
             @' + @Column + ' ' + @DataType + '
          )
          AS
          SET NOCOUNT ON

          SELECT
            *
          FROM
            Northwind..' + @Table + '
          WHERE
            ' + @Column + ' = @' + @Column

print @str
-- create the proc
EXEC (@Str)
GO


EXEC usp_Generate_Table_Proc
  'Customers'
GO


EXEC usp_Customers_Proc
  'VINET'
GO

DROP PROC usp_Customers_Proc
GO

DROP PROC usp_Generate_Table_Proc
GO

-- SQL Puzzle 10-Pending Deletes
CREATE TRIGGER trd_Customers ON Customers AFTER DELETE
AS

-- check if there is anything to do
IF @@ROWCOUNT = 0
  RETURN

-- move all rows not belonging to employee
-- to PendingDeleteCustomers
INSERT PendingDeleteCustomers
(
  CustomerID,
  CustomerName,
  Address,
  Phone,
  EmployeeID
)
SELECT
  CustomerID,
  CustomerName,
  Address,
  Phone,
  EmployeeID
FROM
  deleted
WHERE
  EmployeeID <> USER_NAME ()
GO

CREATE TRIGGER trd_PendingDeleteCustomers
  ON PendingDeleteCustomers INSTEAD OF DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

DELETE P
FROM
    PendingDeleteCustomers P
  JOIN
    deleted                D ON D.CustomerID = P.CustomerID
WHERE
    D.EmployeeID = USER_NAME ()
GO

-- SQL Puzzle 11-Formatting Dates
/* function dbo.format_date

   input:

     @date AS datetime -
       any given date

     @formatstring AS varchar(100) -
       a formatted string with codes
       to be replaced by datetime values:

       yyyy - year four digits
       yy   - year two digits
       mm   - month with leading zero
       m    - month without leading zero
       dd   - day with leading zero
       d    - day without leading zero
       hh   - hour with leading zero
       h    - hour without leading zero
       nn   - minutes with leading zero
       n    - minutes without leading zero
       ss   - seconds with leading zero
       s    - seconds without leading zero
       ms   - milliseconds three digits with leading zeros

    process:
      
      The function is a series of calls to the
      replace(@s1, @s2, @s3) function, which accepts three
      strings as parameters, and replaces each occurrence of
      @s2 in @s1 with @s3.
      You use it to replace a code representing a certain
      date part with the actual date part extracted from
      the @date parameter.
      Notice that there is an importance to the order of
      date parts manipulation.  For example, if you replaced
      each occurrence of the code m (month without leading zeros)
      with the month before replacing the code ms (milliseconds)
      you would get a wrong output.
      Similarly, you need to replace the seconds without leading
      zeros (s) after you replace milliseconds.

    output:
      
      SELECT dbo.format_date('2000-09-08 07:06:05.432',
                             'yyyy-mm-dd hh:nn:ss.ms')

      2000-09-08 07:06:05.433

      SELECT dbo.format_date('2000-09-08 07:06:05.432',
                             'yy-m-d h:n:s.ms')

      00-9-8 7:6:5.433

      SELECT dbo.format_date('2000-09-08 07:06:05.432',
                             'dd/mm/yy')

      08/09/00
*/

CREATE FUNCTION dbo.format_date
(
  @date AS datetime,
  @formatstring AS varchar(100)
)
RETURNS varchar(100)
AS

BEGIN
  DECLARE @datestring AS varchar(100)

  SET @datestring = @formatstring

  -- handle year - yyyy
  SET @datestring =
    replace(
      @datestring,
      'yyyy',
      cast(year(@date) AS char(4)))

  -- handle year - yy
  SET @datestring =
    replace(
      @datestring,
      'yy',
      right(cast(year(@date) AS char(4)), 2))

  -- handle milliseconds - ms
  -- handle before months and seconds not to confuse a single m or s
  SET @datestring =
    replace(
      @datestring,
      'ms',
      replicate('0', 3 - len(cast(datepart(ms, @date) AS varchar(3)))) +
                     cast(datepart(ms, @date) AS varchar(3)))

  -- handle month - mm - leading zero, m - no leading zero
  SET @datestring =
    replace(
      @datestring,
      'mm',
      replicate('0', 2 - len(cast(month(@date) AS varchar(2)))) +
                     cast(month(@date) AS varchar(2)))

  SET @datestring =
    replace(@datestring,
            'm',
            cast(month(@date) AS varchar(2)))

  -- handle day - dd - leading zero, d - no leading zero
  SET @datestring =
    replace(
      @datestring,
      'dd',
      replicate('0', 2 - len(cast(day(@date) AS varchar(2)))) +
                     cast(day(@date) AS varchar(2)))

  SET @datestring =
    replace(@datestring,
            'd',
            cast(day(@date) AS varchar(2)))

  -- handle hour - hh - leading zero, h - no leading zero
  SET @datestring =
    replace(
      @datestring,
      'hh',
      replicate('0', 2 - len(cast(datepart(hh, @date) AS varchar(2)))) +
                     cast(datepart(hh, @date) AS varchar(2)))

  SET @datestring =
    replace(@datestring,
            'h',
            cast(datepart(hh, @date) AS varchar(2)))

  -- handle minute - nn - leading zero, n - no leading zero
  SET @datestring =
    replace(
      @datestring,
      'nn',
      replicate('0', 2 - len(cast(datepart(n, @date) AS varchar(2)))) +
                     cast(datepart(n, @date) AS varchar(2)))

  SET @datestring =
    replace(@datestring,
            'n',
            cast(datepart(n, @date) AS varchar(2)))

  -- handle second - ss - leading zero, s - no leading zero
  SET @datestring =
    replace(
      @datestring,
      'ss',
      replicate('0', 2 - len(cast(datepart(ss, @date) AS varchar(2)))) +
                     cast(datepart(ss, @date) AS varchar(2)))

  SET @datestring =
    replace(@datestring,
            's',
            cast(datepart(ss, @date) AS varchar(2)))

  RETURN @datestring
END
GO

-- SQL Puzzle 12-Creating a Temporary Table and Cursor-Free Solution
SELECT
  A.au_id,
  ISNULL (SUM (qty), 0) AS Sales,
  3 AS Quartile
INTO
  #Sales
FROM
    authors     AS A
  LEFT JOIN
    titleauthor AS TA ON TA.au_id   = A.au_id
  LEFT JOIN
    sales       AS S  ON S.title_id = TA.title_id
GROUP BY
  A.au_id

UPDATE #Sales
SET
  Quartile = 1
WHERE
  au_id IN
(
  SELECT TOP 25 PERCENT WITH TIES
    au_id
  FROM
    #Sales
  ORDER BY
    Sales DESC
)

UPDATE #Sales
SET
  Quartile = 2
WHERE
  au_id IN
(
  SELECT TOP 25 PERCENT WITH TIES
    au_id
  FROM
    #Sales
  WHERE
    Au_id NOT IN
  (
    SELECT TOP 25 PERCENT WITH TIES
      Au_id
    FROM
      #Sales
    ORDER BY
      Sales DESC
  )
  ORDER BY
    Sales DESC
)

UPDATE #Sales
SET
  Quartile = 4
WHERE
  au_id IN
(
  SELECT TOP 25 PERCENT WITH TIES
    au_id
  FROM
    #Sales
  ORDER BY
    Sales
)

SELECT
  *,
  (4 - Quartile) * 1000 As Bonus
FROM
  #Sales
ORDER BY
  Sales DESC

-- SQL Puzzle 14-Implementing Cascading Operations
CREATE TRIGGER trg_u_orders_ON_UPDATE_CASCADE ON Orders INSTEAD OF UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount

-- updates to surrogate_key are not allowed
IF UPDATE(surrogate_key)
BEGIN
  RAISERROR('Updates to surrogate_key are not allowed.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRAN
END
ELSE
BEGIN

  -- if orderid was updated, perform cascade
  IF UPDATE(orderid) AND @numrows > 0
  BEGIN
    UPDATE OrderDetails
      SET orderid = I.orderid
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid
      JOIN
        inserted     AS I ON D.surrogate_key = I.surrogate_key
  END

  -- resubmit the update only if at least one row was updated
  -- perform it as a delete / insert operation
  IF @numrows > 0
  BEGIN
    DELETE FROM Orders
    FROM
        Orders  AS O
      JOIN
        deleted AS D ON O.orderid = D.orderid

    INSERT INTO Orders(orderid, customerid, orderdate)
      SELECT
        orderid,
        customerid,
        orderdate
      FROM
        inserted
  END

END
GO

UPDATE Orders
  SET orderid = orderid + 1

ALTER TRIGGER trg_u_orders_ON_UPDATE_CASCADE ON Orders INSTEAD OF UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount
-- updates to surrogate_key are not allowed
IF UPDATE(surrogate_key)
BEGIN
  RAISERROR('Updates to surrogate_key are not allowed.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRAN
END
ELSE
BEGIN

  -- if orderid was updated, perform cascade in a temporary table
  IF UPDATE(orderid) AND @numrows > 0
  BEGIN
    -- copy the affected order parts to a temp table
    SELECT
      OD.*
    INTO
      #OrderDetails
    FROM 
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid
    
    -- delete the affected rows from OrderDetails
    DELETE FROM OrderDetails
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid
    
    -- perform the update to the order parts in the temp table
    UPDATE #OrderDetails
      SET orderid = I.orderid
    FROM
        #OrderDetails AS OD
      JOIN
        deleted       AS D ON OD.orderid      = D.orderid
      JOIN
        inserted      AS I ON D.surrogate_key = I.surrogate_key
  END

  -- resubmit the update only if at least one row was updated
  IF @numrows > 0
  BEGIN
    UPDATE Orders
      SET orderid    = I.orderid,
          customerid = I.customerid,
          orderdate  = I.orderdate
    FROM
        Orders   AS O
      JOIN
        inserted AS I ON O.surrogate_key = I.surrogate_key
  END

  -- copy modified order parts back to the Orders table
  IF UPDATE(orderid) AND @numrows > 0
    INSERT INTO OrderDetails
      SELECT
        *
      FROM
        #OrderDetails

END
GO

BEGIN TRAN

SELECT
  *
FROM
  Orders

SELECT
  *
FROM
  OrderDetails

UPDATE Orders
  SET orderid = orderid + 1

SELECT
  *
FROM
  Orders

SELECT
  *
FROM
  OrderDetails

ROLLBACK TRAN

ALTER TRIGGER trg_u_orders_ON_UPDATE_CASCADE ON Orders INSTEAD OF UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount
-- updates to surrogate_key are not allowed
IF UPDATE(surrogate_key)
BEGIN
  RAISERROR('Updates to surrogate_key are not allowed.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRAN
END
ELSE
BEGIN

  -- if orderid was updated, perform cascade in a temporary table
IF UPDATE(orderid) AND @numrows > 0
  BEGIN

    -- copy the affected order parts to a temp table
    SELECT
      OD.*
    INTO
      #OrderDetails
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid

    -- create the signal for the false delete    
    SELECT 1 AS col1 INTO #falsedelete

    -- delete the affected rows from OrderDetails
    DELETE FROM OrderDetails
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid

    -- perform the update to the rows in the temp table
    UPDATE #OrderDetails
      SET orderid = I.orderid
    FROM
        #OrderDetails AS OD
      JOIN
        deleted       AS D ON OD.orderid      = D.orderid
      JOIN
        inserted      AS I ON D.surrogate_key = I.surrogate_key
  END

  -- resubmit the update only if at least one row was updated
  IF @numrows > 0
  BEGIN
    UPDATE Orders
      SET orderid    = I.orderid,
          customerid = I.customerid,
          orderdate  = I.orderdate
    FROM
        Orders   AS O
      JOIN
        inserted AS I ON O.surrogate_key = I.surrogate_key
  END

  IF UPDATE(orderid) AND @numrows > 0
  BEGIN
    -- create the signal for a false insert
    SELECT 1 AS col1 INTO #falseinsert

    -- copy modified rows back to the order details table
    INSERT INTO OrderDetails
      SELECT
        *
      FROM
        #OrderDetails

    -- perform a dummy update to fire the instead of update trigger on OrderDetails
    UPDATE OrderDetails
      SET orderid = I.orderid
    FROM
        OrderDetails AS OD
      JOIN
        inserted AS I ON OD.orderid = I.orderid
  END

END
GO

ALTER TRIGGER trg_d_orderdetails_on_delete_print_hello ON OrderDetails  INSTEAD OF DELETE
AS

-- check if a signal exists that tells us not to perform the usual activity
IF OBJECT_ID('tempdb..#falsedelete') IS NOT NULL
  DELETE FROM OrderDetails
  FROM
      OrderDetails AS OD
    JOIN
      deleted      AS D  ON  OD.orderid = D.orderid
                         AND OD.partid  = D.partid
ELSE -- perform the usual activity
BEGIN
  PRINT 'Hello from instead of delete trigger on OrderDetails'

  DELETE FROM OrderDetails
  FROM
      OrderDetails AS OD
    JOIN
      deleted      AS D ON  OD.orderid = D.orderid
                        AND OD.partid  = D.partid
END
GO

ALTER TRIGGER trg_d_orderdetails_on_insert_print_hello ON OrderDetails  INSTEAD OF INSERT
AS

-- check if a signal exists that tells us not to perform the usual activity
IF OBJECT_ID('tempdb..#falsedelete') IS NOT NULL
  INSERT INTO OrderDetails
    SELECT
      *
    FROM
      inserted
ELSE -- perform the usual activity
BEGIN
  PRINT 'Hello from instead of insert trigger on OrderDetails'

  INSERT INTO OrderDetails
    SELECT
      *
    FROM
      inserted
END
GO

BEGIN TRAN

SELECT
  *
FROM
  Orders

SELECT
  *
FROM
  OrderDetails

UPDATE Orders
  SET orderid = orderid + 1

SELECT
  *
FROM
  Orders

SELECT
  *
FROM
  OrderDetails

ROLLBACK TRAN

-- SQL Puzzle 15-Discounting Scheme
DECLARE
    @Sum    money,
    @Total  money

-- set up cursor for 3 most-recent orders
DECLARE c INSENSITIVE SCROLL CURSOR FOR
SELECT TOP 3
   sum (od.Quantity * od.UnitPrice) AS Total
FROM
        Orders          O
JOIN    [Order Details] OD   ON O.OrderID = OD.OrderID
WHERE
    O.CustomerID = 'FRANK'
GROUP BY
    OD.OrderID,
    O.OrderDate
ORDER BY
   O.OrderDate    DESC

OPEN c

FETCH LAST FROM c INTO              -- earliest order
    @Total

IF @@CURSOR_ROWS < 3                -- fewer than 3 orders
  SELECT
    0.00 AS Discount
ELSE
BEGIN
  SET
      @Sum = @Total * 2.0

  FETCH PRIOR FROM c INTO
      @Total

  SET
      @Sum = @Sum + @Total * 3.0      -- 2nd most-recent order

  FETCH PRIOR FROM c INTO
      @Total

  SET
      @Sum = @Sum + @Total * 5.0      -- most-recent order

  SET
      @Sum = ISNULL (@Sum, 0) / 10.0  -- calculate weighted average

  SELECT                              -- display discount
      CASE
          WHEN @Sum < 1000 THEN 0.00
          WHEN @Sum >= 1000 AND @Sum < 2000.00 THEN 0.10
          WHEN @Sum >= 2000 AND @Sum < 4000.00 THEN 0.20
                                               ELSE 0.25
      END  AS Discount
END

-- clean up
CLOSE c
DEALLOCATE c

-- SQL Puzzle 16-Hierarchies and User-Defined Functions
CREATE FUNCTION dbo.NODELEVEL(@empid int) RETURNS int
AS
BEGIN
  DECLARE @nodelevel AS int
  SET @nodelevel = -1
  
  -- go up one level and increment @nodelevel each iteration
  WHILE @empid IS NOT NULL
    SELECT 
      @empid     = mgrid,
      @nodelevel = @nodelevel + 1
    FROM
      Employees
    WHERE
      empid = @empid

  RETURN @nodelevel
END
GO

  -- if node does not exist return NULL
  IF NOT EXISTS (SELECT *
                 FROM
                   Employees
                 WHERE
                   empid = @empid)
    RETURN NULL

CREATE FUNCTION dbo.NODEPATH(@empid int) RETURNS varchar(900)
AS
BEGIN
  DECLARE @nodepath AS varchar(900)
  SET @nodepath = '.' + CAST(@empid AS varchar(10)) + '.'
  
  -- go up one level and increment @nodelevel each iteration
  WHILE @empid IS NOT NULL
    SELECT
      @empid    = mgrid,
      @nodepath = CASE
                    WHEN mgrid IS NULL THEN ''
                    ELSE '.' + CAST(mgrid AS varchar(10))
                  END + @nodepath
    FROM
      Employees
    WHERE
      empid = @empid

  RETURN @nodepath
END
GO

SELECT
  *,
  dbo.NODELEVEL(empid) AS lvl,
  dbo.NODEPATH(empid)  AS hierarchy
FROM
  Employees

ALTER TABLE Employees
  ADD lvl AS dbo.NODELEVEL(empid),
      hierarchy AS dbo.NODEPATH(empid)
GO

SELECT
  *
FROM
  Employees

-- SQL Puzzle 17.1-Top Gun: The Best of the Best
SELECT
  O1.ShipCountry,
  O1.EmployeeID,
  COUNT (*) AS Orders
INTO
  #Temp
FROM
    Orders O1
GROUP BY
    O1.ShipCountry,
    O1.EmployeeID

SELECT
  EmployeeID,
  COUNT (*) AS Countries
FROM
(
  SELECT
    T1.*
  FROM
    #Temp T1
  WHERE
    T1.Orders =
  (
    SELECT
      MAX (T2.Orders)
    FROM
      #Temp T2
    WHERE
        T2.ShipCountry = T1.ShipCountry
  )
) X
GROUP BY
  EmployeeID
ORDER BY
  Countries DESC

-- SQL Puzzle 17.2.1-Filling a Table with a Magic Square's Data in T-SQL
CREATE PROC FillMagicSquare
  @size AS int
AS

DELETE MagicSquare

-- Insert the first number to the middle cell in the first row
INSERT INTO MagicSquare
  (row, col, value)
VALUES
  (1, @size / 2 + 1, 1)

-- Insert the rest of the numbers while
-- the last number does not exist in the table
WHILE NOT EXISTS (SELECT * FROM MagicSquare WHERE value = SQUARE(@size))

  INSERT INTO MagicSquare(row, col, value)
    -- decide which coordinates to use (above / right cell or cell beneath)
    -- based on the NULLs returned from the ROJ
    SELECT
      CASE
        WHEN MS.row IS NULL THEN O1.row
        ELSE O2.row
      END AS row,
      CASE
        WHEN MS.col IS NULL THEN O1.col
        ELSE O2.col
      END AS col,
      O1.value
    FROM
      -- Input 1: base table      
        MagicSquare AS MS
      -- Join 1: existing_cell ROJ above / right cell
      -- NULLs indicate cell is not occupied
      RIGHT OUTER JOIN
      -- Input 2: above / right cell info
        (SELECT
           CASE
             WHEN row - 1 = 0 THEN @size
             ELSE row - 1
           END AS row,
           CASE
             WHEN col + 1 > @size THEN 1
             ELSE col + 1
           END AS col,
           value + 1 AS value
         FROM MagicSquare
         WHERE
           value = (SELECT
                      MAX(value)
                    FROM
                      MagicSquare)) AS O1 ON  MS.row = O1.row
                                          AND MS.col = O1.col
      -- Join 2: existing_cell ROJ above / right cell CJ cell beneath
      CROSS JOIN
      -- Input 3: cell beneath info.
        (SELECT
           CASE
             WHEN row + 1 > @size THEN 1
             ELSE row + 1
           END AS row,
           col,
           value + 1 AS value
         FROM MagicSquare
         WHERE
           value = (SELECT
                      MAX(value)
                    FROM
                      MagicSquare)) AS O2
GO

EXEC FillMagicSquare 3

SELECT * FROM MagicSquare ORDER BY row, col

-- SQL Puzzle 17.2.2-Displaying the Magic Square as a Cross-Tab Table
SELECT
  SUM(CASE col
        WHEN 1 THEN value
        ELSE 0
      END) AS col1,
  SUM(CASE col
        WHEN 2 THEN value
        ELSE 0
      END) AS col2,
  SUM(CASE col
        WHEN 3 THEN value
        ELSE 0
      END) AS col3
FROM
  MagicSquare
GROUP BY
  row
ORDER BY
  row

CREATE PROC ShowMagicSquare
AS

DECLARE
  @size  AS int,
  @cmd   AS varchar(8000),
  @col   AS int,
  @ENTER AS char(1)

SET @ENTER = CHAR(13) + CHAR(10)

SELECT @size = SQRT(COUNT(*)) FROM MagicSquare

SET @cmd = 'SELECT' + @ENTER

SET @col = 1
WHILE @col < = @size
BEGIN
  SET @cmd = @cmd +
    '  SUM(CASE col' + @ENTER +
    '    WHEN ' + CAST(@col AS varchar) + ' THEN value' + @ENTER +
    '    ELSE 0' + @ENTER +
    '  END) AS col' + CAST(@col AS varchar) +
    CASE
      WHEN @col < @size THEN ','
      ELSE ''
    END +
    @ENTER

  SET @col = @col + 1
END

SET @cmd = @cmd +
  'FROM' + @ENTER +
  '  MagicSquare' + @ENTER +
  'GROUP BY'  + @ENTER +
  '  row' + @ENTER +
  'ORDER BY'  + @ENTER +
  '  row' + @ENTER

EXEC (@cmd)
GO

EXEC FillMagicSquare 5
EXEC ShowMagicSquare

-- SQL Puzzle 17.2.3-Checking whether the Table Represents a Magic Square Correctly
SELECT
  'row'      AS line,
  row        AS ordinal,
  SUM(value) AS sum_line
FROM
  MagicSquare
GROUP BY
  row

UNION ALL

SELECT
  'col'      AS line,
   col       AS ordinal,
  SUM(value) AS sum_line
  FROM
    MagicSquare
  GROUP BY
    col

UNION ALL

SELECT
  'diagonal' AS line,
  1          AS ordinal,
  SUM(value) AS sum_line
FROM
  MagicSquare
WHERE
  row = col

UNION ALL

SELECT
  'diagonal' AS line,
  2          AS ordinal,
  SUM(value) AS sum_line
FROM
  MagicSquare
WHERE
  col - 1 = (SELECT
               SQRT(COUNT(*))
             FROM
               MagicSquare) - row

IF EXISTS(SELECT
            MIN(sum_line) AS min_line,
            MAX(sum_line) AS max_line
          FROM
           (SELECT
              'row'      AS line,
              row        AS ordinal,
              SUM(value) AS sum_line
            FROM
              MagicSquare
            GROUP BY
              row

            UNION ALL

            SELECT
              'col'      AS line,
               col       AS ordinal,
              SUM(value) AS sum_line
              FROM
                MagicSquare
              GROUP BY
                col

            UNION ALL

            SELECT
              'diagonal' AS line,
              1          AS ordinal,
              SUM(value) AS sum_line
            FROM
              MagicSquare
            WHERE
              row = col

            UNION ALL

            SELECT
              'diagonal' AS line,
              2          AS ordinal,
              SUM(value) AS sum_line
            FROM
              MagicSquare
            WHERE
              col - 1 = (SELECT
                           SQRT(COUNT(*))
                         FROM
                           MagicSquare) - row) AS lines
          HAVING
            MIN(sum_line) = MAX(sum_line))
  PRINT 'This is a Magic Square. :-)'
ELSE
  PRINT 'This is not a Magic Square. :-('

IF (SELECT
      SUM(value)
    FROM
      MagicSquare
    WHERE
      row = 1) = ALL(SELECT
                       SUM(value) AS sum_line
                     FROM
                       MagicSquare
                     GROUP BY
                       row

                     UNION ALL

                     SELECT
                       SUM(value) AS sum_line
                       FROM
                         MagicSquare
                       GROUP BY
                         col

                     UNION ALL

                     SELECT
                       SUM(value) AS sum_line
                     FROM
                       MagicSquare
                     WHERE
                       row = col

                     UNION ALL

                     SELECT
                       SUM(value) AS sum_line
                     FROM
                       MagicSquare
                     WHERE
                       col - 1 = (SELECT
                                    SQRT(COUNT(*))
                                  FROM
                                    MagicSquare) - row) AS lines)
  PRINT 'This is a Magic Square. :-)'
ELSE
  PRINT 'This is not a Magic Square. :-('

