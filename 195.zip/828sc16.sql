----------------------------------------
-- Chapter 16 - Expanding Hierarchies --
----------------------------------------

-- Listing 16-2: Schema Creation Script for the Employees Table
CREATE TABLE Employees
(
  empid   int         NOT NULL,
  mgrid   int         NULL,
  empname varchar(25) NOT NULL,
  salary  money       NOT NULL,
  CONSTRAINT PK_Employees_empid PRIMARY KEY(empid),
  CONSTRAINT FK_Employees_mgrid_empid
    FOREIGN KEY(mgrid)
    REFERENCES Employees(empid))
GO

INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(1, NULL, 'Nancy', $10000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(2, 1, 'Andrew', $5000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(3, 1, 'Janet', $5000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(4, 1, 'Margaret', $5000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(5, 2, 'Steven', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(6, 2, 'Michael', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(7, 3, 'Robert', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(8, 3, 'Laura', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(9, 3, 'Ann', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(10, 4, 'Ina', $2500.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(11, 7, 'David', $2000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(12, 7, 'Ron', $2000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(13, 7, 'Dan', $2000.00)
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(14, 11, 'James', $1500.00)

-- Listing 16-3: Senior Manager Query
SELECT *
FROM
  Employees
WHERE
  mgrid IS NULL

-- Listing 16-4: Employees and their Managers
SELECT
  E.empname AS EmployeeName,
  M.empname AS ManagerName
FROM
    Employees AS E
  LEFT OUTER JOIN
    Employees AS M ON E.mgrid = M.empid

-- Listing 16-5: Subordinates Query
SELECT
  *
FROM
  Employees
WHERE
  mgrid = 7

-- Listing 16-6: Leaf-Level Employees (Employees with No Subordinates), Correlated Subquery Syntax
SELECT *
FROM
  Employees AS M
WHERE
  NOT EXISTS
             (
              SELECT
                empid
	        FROM
                Employees AS E
               WHERE
                 E.mgrid = M.empid
              )

-- Listing 16-7: Leaf-Level Employees (Employees with No Subordinates), Join Syntax
SELECT
  M.*
FROM
    Employees AS M
  LEFT OUTER JOIN
    Employees AS E ON M.empid = E.mgrid
WHERE
  E.mgrid IS NULL

-- Listing 16-8: Schema Creation Script for the New Employees Table
IF object_id('Employees', 'U') IS NOT NULL
  DROP TABLE Employees
GO

CREATE TABLE Employees
(
  empid     int          NOT NULL,
  mgrid     int          NULL,
  empname   varchar(25)  NOT NULL,
  salary    money        NOT NULL,
  lvl       int          NULL,
  hierarchy varchar(900) NULL,
  CONSTRAINT PK_Employees_empid PRIMARY KEY(empid),
  CONSTRAINT FK_Employees_mgrid_empid
    FOREIGN KEY(mgrid)
    REFERENCES Employees(empid)
)

-- Listing 16-9: Creation Script for the Trigger - trg_employees_i_calchierarchy
CREATE TRIGGER trg_employees_i_calchierarchy ON Employees FOR INSERT
AS
DECLARE @numrows AS int
SET @numrows = @@rowcount
IF @numrows > 1
BEGIN
  RAISERROR('Only single row inserts are supported!', 16, 1)
  ROLLBACK TRAN
END
ELSE
IF @numrows = 1
BEGIN
  UPDATE E
    SET lvl = CASE
                WHEN E.mgrid IS NULL THEN 0
                ELSE M.lvl + 1
              END,
        hierarchy = CASE
                      WHEN E.mgrid IS NULL THEN '.' 
                      ELSE M.hierarchy
                    END + CAST(E.empid AS varchar(10)) + '.'
  FROM
      Employees AS E
    JOIN
      inserted  AS I ON I.empid = E.empid
    LEFT OUTER JOIN
      Employees AS M ON E.mgrid = M.empid
END

-- Listing 16-10: Testing the trg_employees_i_calchierarchy Trigger
INSERT INTO employees(empid, mgrid, empname, salary)
  VALUES(15, 12, 'Sean', $1500.00)

-- Listing 16-11: Calculating the lvl Column
lvl = CASE
        WHEN E.mgrid IS NULL THEN 0
        ELSE M.lvl + 1
      END

-- Listing 16-12: Calculating the hierarchy Column
hierarchy = CASE
              WHEN E.mgrid IS NULL THEN '.' 
              ELSE M.hierarchy
            END + CAST(E.empid AS varchar(10)) + '.'

-- Listing 16-13: Creation Script for the Trigger trg_employees_ioi_splitinsertstolevels
-- add support for multi-row inserts by splitting the inserts to levels
CREATE TRIGGER trg_employees_ioi_splitinsertstolevels ON Employees INSTEAD OF INSERT
AS

DECLARE @curlvlemps table -- will be filled with employee ids
(
  empid int NOT NULL,
  lvl   int NOT NULL
)
DECLARE @curlvl AS int -- indicates the level of the employees in the subtree

SET @curlvl = 0

-- insert first top-level employees in the subtree to @curlvlemps
INSERT INTO @curlvlemps
  SELECT
    empid,
    @curlvl
  FROM
    inserted AS I
  WHERE
    NOT EXISTS(
               SELECT
                 *
               FROM
                 inserted AS I2
               WHERE
                 I.mgrid = I2.empid
               )

-- loop while there are employees in the last checked level 
WHILE @@ROWCOUNT > 0
BEGIN
  -- insert current level's employees to the Employees table
  -- this will invoke the after trigger that takes care of the lvl and hierarchy columns
  INSERT INTO Employees
    SELECT
      I.*
    FROM
        inserted    AS I
      JOIN
        @curlvlemps AS C ON  I.empid = C.empid
                         AND C.lvl   = @curlvl

  -- adjust current level
  SET @curlvl = @curlvl + 1

  -- add next level employees to @curlvlemps
  INSERT INTO @curlvlemps
    SELECT
      I.empid, @curlvl
    FROM
        inserted    AS I
      JOIN
        @curlvlemps AS C ON  I.mgrid = C.empid
                         AND C.lvl   = @curlvl - 1
END
GO

-- Listing 16-14: Altering the Trigger trg_employees_i_calchierarchy to Support Multi-Row Inserts
-- alter the insert trigger that maintains the columns lvl and hierarchy
-- to support multi-row inserts
ALTER TRIGGER trg_employees_i_calchierarchy ON Employees FOR INSERT
AS
DECLARE @numrows AS int
SET @numrows = @@rowcount
IF @numrows >= 1
BEGIN
  UPDATE E
  SET lvl =
        CASE
          WHEN E.mgrid IS NULL THEN 0
          ELSE M.lvl + 1
        END,
      hierarchy =
        CASE
          WHEN E.mgrid IS NULL THEN '.' 
          ELSE M.hierarchy
        END + CAST(E.empid AS varchar(10)) + '.'
  FROM
      Employees AS E
    JOIN
      inserted  AS I ON I.empid = E.empid
    LEFT OUTER JOIN
      Employees AS M ON E.mgrid = M.empid
END
GO

-- Listing 16-15: Testing a Subtree Insert
-- test a subtree insert
DELETE FROM Employees
GO

CREATE TABLE #Employees
(
  empid   int         NOT NULL,
  mgrid   int         NULL,
  empname varchar(25) NOT NULL,
  salary  money       NOT NULL
)
GO

INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(1, NULL, 'Nancy', $10000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(2, 1, 'Andrew', $5000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(3, 1, 'Janet', $5000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(4, 1, 'Margaret', $5000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(5, 2, 'Steven', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(6, 2, 'Michael', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(7, 3, 'Robert', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(8, 3, 'Laura', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(9, 3, 'Ann', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(10, 4, 'Ina', $2500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(11, 7, 'David', $2000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(12, 7, 'Ron', $2000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(13, 7, 'Dan', $2000.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(14, 11, 'James', $1500.00)
INSERT INTO #Employees(empid, mgrid, empname, salary) VALUES(15, 12, 'Sean', $1500.00)
GO

INSERT INTO Employees(empid, mgrid, empname, salary)
  SELECT
    *
  FROM
    #Employees

SELECT * FROM Employees

-- Listing 16-16: Senior Manager Query
SELECT *
FROM
  Employees
WHERE
  lvl = 0

-- Listing 16-17: Listing the Employees by Their Hierarchical Dependencies
SELECT *
FROM
  Employees
ORDER BY
  hierarchy

-- Listing 16-18: Showing Hierarchical Dependencies with Indentation
SELECT
  replicate(' | ', lvl) + empname AS EmployeeName
FROM
  Employees
ORDER BY
  hierarchy

-- Listing 16-19: Details about Robert (Employee ID 7) and All of His Subordinates in All Levels
SELECT
  *
FROM
  Employees
WHERE
  hierarchy LIKE (SELECT
                    hierarchy
                  FROM
                    Employees
                  WHERE
                    empid = 7) + '%'
ORDER BY
  Hierarchy

-- Listing 16-20: Details about Robert�s Subordinates in All Levels, Excluding Robert
SELECT
  *
FROM
  Employees
WHERE
  hierarchy LIKE (SELECT
                    hierarchy
                  FROM
                    Employees
                  WHERE
                    empid = 7) + '_%'
ORDER BY
  hierarchy

-- Listing 16-21: The Total Salary of Robert and All of His Subordinates in All Levels
SELECT
  sum(salary) AS total_salary
FROM
  Employees
WHERE
  hierarchy LIKE (SELECT
                    hierarchy
                  FROM
                    Employees
                  WHERE
                    empid = 7) + '%'

-- Listing 16-22: Details of All the Leaf-Level Employees Under Janet (employee ID 3)
SELECT *
FROM
  Employees AS M
WHERE
    hierarchy LIKE (SELECT
                      hierarchy
                    FROM
                      Employees
                    WHERE
                      empid = 3) + '%'
  AND
    NOT EXISTS(SELECT
                 Mgrid
               FROM
                 Employees AS E
               WHERE
                 M.empid = E.mgrid)

-- Listing 16-23: Details of All of the Employees Who Are Two Levels Under Janet, Correlated Subquery Syntax
SELECT
  *
FROM
  Employees AS M
WHERE
    hierarchy LIKE (SELECT
                      hierarchy
                    FROM
                      Employees
                    WHERE
                      empid = 3) + '%'
  AND
    lvl - (SELECT
             lvl
           FROM
             Employees
           WHERE
             empid = 3) = 2

-- Listing 16-24: Details of All of the Employees Who Are Two Levels Under Janet, Join Syntax
SELECT
  E.*
FROM
    Employees AS E
  JOIN
    Employees AS M ON E.hierarchy LIKE M.hierarchy + '%'
WHERE
    M.empid = 3
  AND
    E.lvl - M.lvl = 2

-- Listing 16-25: The Chain of Management Leading to James (employee ID 14)
SELECT
  *
FROM
  Employees
WHERE
  (SELECT
     hierarchy
   FROM
     Employees
   WHERE
     empid = 14) LIKE hierarchy + '%'
ORDER BY
  hierarchy

-- Listing 16-26: Creation Script for the get_mgremps() User Defined Function
CREATE FUNCTION get_mgremps
(
  @mgrid AS int
)
RETURNS @tree table
(
  empid   int         NOT NULL,
  mgrid   int         NULL,
  empname varchar(25) NOT NULL,
  salary  money       NOT NULL,
  lvl     int         NOT NULL
)
AS

BEGIN
  
  DECLARE @lvl AS int
  SET @lvl = 0

  INSERT INTO @tree
    SELECT
      empid,
      mgrid,
      empname,
      salary,
      @lvl
    FROM
      Employees
    WHERE
      empid = @mgrid

  WHILE @@ROWCOUNT > 0
  BEGIN
    SET @lvl = @lvl + 1

    INSERT INTO @tree
      SELECT
        E.empid,
        E.mgrid,
        E.empname,
        E.salary,
        @lvl
      FROM
          Employees AS E
        JOIN
          @tree AS T ON  E.mgrid = T.empid
                     AND T.lvl   = @lvl - 1
  END  
  
  RETURN

END
GO

-- Listing 16-27: Using the get_mgremps() User-Defined Function for Details about Robert and All of His Subordinates in All Levels
SELECT
  *
FROM
  get_mgremps(7)

-- Listing 16-28: Creation Script for the trg_employees_u_calchierarchy Trigger 
CREATE TRIGGER trg_employees_u_calchierarchy ON Employees FOR UPDATE
AS
IF @@ROWCOUNT = 0
  RETURN

IF UPDATE(empid)
BEGIN
  RAISERROR('Updates to empid not allowed!', 16, 1)
  ROLLBACK TRAN
END
ELSE IF UPDATE(mgrid)
BEGIN
  UPDATE E
    SET lvl = E.lvl - I.lvl + CASE
                                WHEN I.mgrid IS NULL THEN 0
                                ELSE M.lvl + 1
                              END,
        hierarchy = ISNULL(M.hierarchy, '.') +
                    CAST(I.empid AS varchar(10)) + '.' +
                    right(E.hierarchy, len(E.hierarchy) - len(I.hierarchy))
  FROM
      Employees AS E
    JOIN
      inserted  AS I ON E.hierarchy LIKE I.hierarchy + '%'
    LEFT OUTER JOIN
      Employees AS M ON I.mgrid = M.empid
END

-- Listing 16-29: Testing the trg_employees_u_calchierarchy Trigger
UPDATE employees
  SET mgrid = 3
WHERE empid = 2

-- Listing 16-30: Creation Script for the RemoveSubtree Stored Procedure 
CREATE PROC RemoveSubtree
(
  @empid int
)
AS

DELETE FROM Employees
WHERE
  hierarchy LIKE (SELECT
                    hierarchy
                  FROM
                    Employees
                  WHERE
                    empid = @empid) + '%'
GO

-- Listing 16-31: Testing the RemoveSubtree Stored Procedure
EXEC RemoveSubtree
  @empid = 7

-- Listing 16-32: Creation Script for Stored Procedure RemoveEmployeeUpgradeSubs
CREATE PROC RemoveEmployeeUpgradeSubs
(
  @empid int
)
AS

BEGIN TRAN

UPDATE E
  SET mgrid = M.mgrid
FROM
    Employees AS E
  JOIN
    Employees AS M ON E.mgrid = M.empid
WHERE
  M.empid = @empid

DELETE FROM Employees
WHERE
  empid = @empid

COMMIT TRAN
GO

-- Listing 16-33: Testing the RemoveEmployeeUpgradeSubs Stored Procedure
EXEC RemoveEmployeeUpgradeSubs
  @empid = 2

-- Listing 16-34: Creation Script for the RemoveEmployeeMoveSubs Stored Procedure
CREATE PROC RemoveEmployeeMoveSubs
(
  @empid  int,
  @newmgr int
)
AS

BEGIN TRAN

UPDATE E
  SET mgrid = @newmgr
FROM
    Employees AS E
  JOIN
    Employees AS M ON E.mgrid = M.empid
WHERE
  M.empid = @empid

DELETE FROM Employees
WHERE
  empid = @empid

COMMIT TRAN
GO

-- Listing 16-35: Testing the RemoveEmployeeMoveSubs Stored Procedure
EXEC RemoveEmployeeMoveSubs
  @empid  = 3,
  @newmgr = 4

-- Listing 16-36: Repopulating the Employees Table for Performance Tests
-- clear the Employees table
TRUNCATE TABLE Employees

-- fill the table with 10,000 employees:
-- 1000 employees in level 0, each of which has 3 subordinates in level 1,
-- each of which has two subordinates in level 2
-- (there is no president in this case)

SET NOCOUNT ON
DECLARE @emplvl0 AS int, @emplvl1 AS int, @emplvl2 AS int
SET @emplvl0 = 1
WHILE @emplvl0 <= 9991
BEGIN
  -- insert level 0 employees with ids 1, 11, ..., 9991
  INSERT INTO employees(empid, mgrid, empname, salary)
    VALUES(@emplvl0, NULL , 'EmpName' + CAST(@emplvl0 AS varchar), $3000.00)
  SET @emplvl1 = @emplvl0 + 1
  WHILE @emplvl1 <= @emplvl0 + 7
  BEGIN
    -- insert three level 1 employees with ids emplvl0 + 1, + 4, + 7
    INSERT INTO employees(empid, mgrid, empname, salary)
      VALUES(@emplvl1, @emplvl0, 'EmpName' + CAST(@emplvl1 AS varchar), $2000.00)
    SET @emplvl2 = @emplvl1 + 1
    WHILE @emplvl2 <= @emplvl1 + 2
    BEGIN
      -- insert two level 2 employees with ids emplvl1 + 1, + 2
      INSERT INTO employees(empid, mgrid, empname, salary)
        VALUES(@emplvl2, @emplvl1, 'EmpName' + CAST(@emplvl2 AS varchar), $1000.00)
      SET @emplvl2 = @emplvl2 + 1
    END
    SET @emplvl1 = @emplvl1 + 3
  END
  SET @emplvl0 = @emplvl0 + 10
END
SET NOCOUNT OFF

-- Listing 16-37: Getting the First 20 Employees
SELECT TOP 20
  *
FROM
  Employees
ORDER BY
  empid

-- Listing 16-38: Adding an Index on the hierarchy Column
CREATE NONCLUSTERED INDEX idx_nc_hierarchy ON Employees(hierarchy)

-- Listing 16-39: Testing Performance, Query 1
SELECT
  *
FROM
  Employees
WHERE
  hierarchy LIKE (SELECT
                    hierarchy
                  FROM
                    Employees
                  WHERE
                    empid = 5) + '%'
ORDER BY
  hierarchy

-- Listing 16-40: I/O Statistics Report of a Performance Test Using a Subquery
Table 'Employees'.  Scan count 2,     logical reads 90,
                   physical reads 0, read-ahead reads 0.

-- Listing 16-41: Textual Execution Plan � Testing Performance Using a Subquery
  6 |--Sort(ORDER BY:([Employees].[hierarchy] ASC))
    5 |--Filter(WHERE:(like([Employees].[hierarchy],
         [Employees].[hierarchy]+'%', NULL)))
      4 |--Nested Loops(Left Outer Join)
        1 |--Clustered Index Scan(OBJECT:
             ([testdb].[dbo].[Employees].[PK_Employees_empid]))
        3 |--Table Spool
          2 |--Clustered Index Seek(OBJECT:
               ([testdb].[dbo].[Employees].[PK_Employees_empid]),
               SEEK:([Employees].[empid]=5) ORDERED FORWARD)

-- Listing 16-42: Testing Performance, Query 2
SELECT
  *
FROM
  Employees
WHERE
  hierarchy LIKE '.1.5.%'
ORDER BY
  Hierarchy

-- Listing 16-43: I/O Statistics Report of a Performance Test Using a Constant
Table 'Employees'.  Scan count 1, logical reads 8,
                   physical reads 0, read-ahead reads 0.

-- Listing 16-44: Textual Execution Plan � Testing Performance Using a Constant
2 |--Bookmark Lookup(BOOKMARK:([Bmk1000]),
                     OBJECT:([testdb].[dbo].[Employees]))
  1 |--Index Seek(
       OBJECT:([testdb].[dbo].[Employees].[idx_nc_hierarchy]),
               SEEK:([Employees].[hierarchy] >= '.1.5.' AND
                     [Employees].[hierarchy] < '.1.5/'),
                     WHERE:(like([Employees].[hierarchy],
                                 '.1.5.%', NULL)) ORDERED FORWARD)

-- Listing 16-45: Testing Performance, Query 3
DECLARE @cmd AS varchar(8000)

SET @cmd =
  'SELECT * FROM Employees WHERE hierarchy LIKE ''' +
  (SELECT hierarchy + '%'
   FROM Employees
   WHERE empid = 5) +
  ''' ORDER BY hierarchy'

EXECUTE(@cmd)

-- Listing 16-46: I/O Statistics Report of a Performance Test Building the Query Dynamically
Table 'Employees'.  Scan count 1, logical reads 2,
                   physical reads 0, read-ahead reads 0.

-- Listing 16-47: Textual Execution Plan � Building the Query Dynamically
4 |--Compute Scalar(DEFINE:([Expr1003]=
     Convert('SELECT * FROM Employees WHERE hierarchy LIKE
     ''+[Employees].[hierarchy]+'%'+''ORDER BY hierarchy')))
  3 |--Nested Loops(Left Outer Join)
    1 |--Constant Scan
    2 |--Clustered Index Seek(OBJECT:
         ([testdb].[dbo].[Employees].[PK_Employees_empid]),
         SEEK:([Employees].[empid]=5) ORDERED FORWARD)

-- Listing 16-48: I/O Statistics Report of a Performance Test Using Dynamic Execution
Table 'Employees'.  Scan count 1, logical reads 8,
                   physical reads 0, read-ahead reads 0.

-- Listing 16-49: Textual Execution Plan � Dynamic Execution
2 |--Bookmark Lookup(BOOKMARK:([Bmk1000]),
                     OBJECT:([testdb].[dbo].[Employees]))
  1 |--Index Seek(
       OBJECT:([testdb].[dbo].[Employees].[idx_nc_hierarchy]),
               SEEK:([Employees].[hierarchy] >= '.1.5.' AND
                     [Employees].[hierarchy] < '.1.5/'),
                     WHERE:(like([Employees].[hierarchy],
                                 '.1.5.%', NULL)) ORDERED FORWARD)

-- Listing 16-50: Testing Performance, Query 4
SELECT
  *
FROM
    Employees AS E
  JOIN
    (SELECT
       hierarchy
     FROM
       Employees
     WHERE empid = 5) as M ON E.hierarchy LIKE M.Hierarchy + '%'

-- Listing 16-51: I/O Statistics Report of a Performance Test Using a Join
Table 'Employees'.  Scan count 2, logical reads 10,
                   physical reads 0, read-ahead reads 0.

-- Listing 16-52: Textual Execution Plan � Testing Performance Using a Join
8 |--Bookmark Lookup(BOOKMARK:([Bmk1000]),
     OBJECT:([testdb].[dbo].[Employees] AS [E]))
  7 |--Nested Loops(Inner Join,
       OUTER REFERENCES:([Employees].[hierarchy]))
    1 |--Clustered Index Seek(
         OBJECT:([testdb].[dbo].[Employees].[PK_Employees_empid]),
         SEEK:([Employees].[empid]=5) ORDERED FORWARD)
    6 |--Filter(WHERE:(like([E].[hierarchy],
               [Employees].[hierarchy]+'%', NULL)))
      5 |--Nested Loops(Inner Join, OUTER REFERENCES:([Expr1003],
                        [Expr1004], [Expr1005]))
        3 |--Compute Scalar(
             DEFINE:([Expr1003]=Convert(
             LikeRangeStart([Employees].[hierarchy]+'%', NULL)),
             [Expr1004]=Convert(
             LikeRangeEnd([Employees].[hierarchy]+'%', NULL)),
             [Expr1005]=
             LikeRangeInfo([Employees].[hierarchy]+'%', NULL)))
          | 2 |--Constant Scan
        4 |--Index Seek(OBJECT:(
             [testdb].[dbo].[Employees].[idx_nc_hierarchy] AS [E]),
             SEEK:([E].[hierarchy] > [Expr1003] AND
             [E].[hierarchy] < [Expr1004]) ORDERED FORWARD)

