---------------------------------------------------------------------------
-- Chapter 14 - Implementing Referential Integrity and Cascading Actions --
---------------------------------------------------------------------------

-- Listing 14-1: Schema Creation Script for the Orders and OrderDetails Tables
CREATE TABLE Orders(
OrderID    int NOT  NULL,
CustomerID char(5)  NOT NULL,
OrderDate  datetime NOT NULL,
CONSTRAINT PK_Orders_OrderID PRIMARY KEY(Orderid))

CREATE TABLE OrderDetails(
OrderID  int NOT NULL,
PartID   int NOT NULL,
Quantity int NOT NULL,
CONSTRAINT PK_OrderDetails_OrderID_partid PRIMARY KEY(OrderID, PartID))

INSERT INTO Orders VALUES(10001, 'FRODO', '19990417')
INSERT INTO Orders VALUES(10002, 'GNDLF', '19990418')
INSERT INTO Orders VALUES(10003, 'BILBO', '19990419')

INSERT INTO OrderDetails VALUES(10001, 11, 12)
INSERT INTO OrderDetails VALUES(10001, 42, 10)
INSERT INTO OrderDetails VALUES(10001, 72, 5)
INSERT INTO OrderDetails VALUES(10002, 14, 9)
INSERT INTO OrderDetails VALUES(10002, 51, 40)
INSERT INTO OrderDetails VALUES(10003, 41, 10)
INSERT INTO OrderDetails VALUES(10003, 61, 35)
INSERT INTO OrderDetails VALUES(10003, 65, 15)

-- Listing 14-1: Schema Creation Script for the Orders and OrderDetails Tables
CREATE TABLE Orders(
OrderID    int NOT  NULL,
CustomerID char(5)  NOT NULL,
OrderDate  datetime NOT NULL,
CONSTRAINT PK_Orders_OrderID PRIMARY KEY(Orderid))

CREATE TABLE OrderDetails(
OrderID  int NOT NULL,
PartID   int NOT NULL,
Quantity int NOT NULL,
CONSTRAINT PK_OrderDetails_OrderID_partid PRIMARY KEY(OrderID, PartID))

INSERT INTO Orders VALUES(10001, 'FRODO', '19990417')
INSERT INTO Orders VALUES(10002, 'GNDLF', '19990418')
INSERT INTO Orders VALUES(10003, 'BILBO', '19990419')

INSERT INTO OrderDetails VALUES(10001, 11, 12)
INSERT INTO OrderDetails VALUES(10001, 42, 10)
INSERT INTO OrderDetails VALUES(10001, 72, 5)
INSERT INTO OrderDetails VALUES(10002, 14, 9)
INSERT INTO OrderDetails VALUES(10002, 51, 40)
INSERT INTO OrderDetails VALUES(10003, 41, 10)
INSERT INTO OrderDetails VALUES(10003, 61, 35)
INSERT INTO OrderDetails VALUES(10003, 65, 15)

-- Listing 14-3: Adding a FOREIGN KEY to the OrderDetails Table
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Orders
  FOREIGN KEY(orderid)
  REFERENCES Orders(orderid)

-- Listing 14-4: Adding a FOREIGN KEY to the Employees Table
ALTER TABLE Employees ADD CONSTRAINT FK_Employees_Employees
  FOREIGN KEY(mgrid)
  REFERENCES Employees(empid)

-- Listing 14-5: Add a FOREIGN KEY with NO ACTION to the OrderDetails Table
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Orders
  FOREIGN KEY(orderid)
  REFERENCES Orders(orderid)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION

-- Listing 14-6: Adding a FOREIGN KEY with CASCADE to the OrderDetails Table
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Orders
  FOREIGN KEY(orderid)
  REFERENCES Orders(orderid)
  ON DELETE CASCADE
  ON UPDATE CASCADE

-- Listing 14-7: Testing ON DELETE CASCADE
DELETE FROM Orders
WHERE orderid = 10002

-- Listing 14-8: Testing ON UPDATE CASCADE
UPDATE Orders
  SET orderid = 10004
WHERE orderid = 10002

-- Listing 14-9: Testting ON UPDATE CASCADE with a Multi-Row Update
UPDATE Orders
  SET orderid = orderid + 1

-- Listing 14-10: Recreating the FOREIGN KEY with NO ACTION (Implicitly)
ALTER TABLE Employees DROP CONSTRAINT FK_Employees_Employees
GO

ALTER TABLE Employees ADD CONSTRAINT FK_Employees_Employees
  FOREIGN KEY(mgrid)
  REFERENCES Employees(empid)
GO

-- Listing 14-11: Creation Script for the usp_OrdersDelete Stored Procedure
CREATE PROC dbo.usp_OrdersDelete
  @orderid int
AS

BEGIN TRAN

-- delete matching rows from OrderDetails
DELETE FROM OrderDetails
WHERE orderid = @orderid

-- delete row from Orders
DELETE FROM Orders
WHERE orderid = @orderid

COMMIT TRAN
GO

-- Listing 14-12: Creation Script for the usp_OrdersUpdate Stored Procedure
CREATE PROC dbo.usp_OrdersUpdate
  @orderid    int,
  @neworderid int      = NULL,
  @customerid char(5)  = NULL,
  @orderdate  datetime = NULL
AS

-- perform cascade update only if the orderid column is modified
--   and also, it is different from the existing order id
-- split the update to insert and then delete so the foreign key will not be broken
IF @neworderid IS NOT NULL AND @orderid <> @neworderid
BEGIN
  BEGIN TRAN

  -- insert a row with the new order id to Orders
  INSERT INTO Orders(orderid, customerid, orderdate)
    SELECT
      @neworderid,
      ISNULL(@customerid, customerid),
      ISNULL(@orderdate, orderdate)
    FROM
      Orders
    WHERE
      orderid = @orderid

  -- update the orderid column for the matching rows in OrderDetails
  UPDATE OrderDetails
    SET orderid = @neworderid
  WHERE orderid = @orderid

  -- delete the row with the old order id from Orders
  DELETE FROM Orders
  WHERE orderid = @orderid

  COMMIT TRAN
END
-- if the orderid column was not modified, perform a regular update
ELSE
  UPDATE Orders
    SET customerid = ISNULL(@customerid, customerid),
        orderdate  = ISNULL(@orderdate, orderdate)
  WHERE
      orderid = @orderid
GO

-- Listing 14-13: Creation Script for the usp_ OrdersInsert Stored Procedure
CREATE PROC dbo.usp_OrdersInsert
  @orderid    int,
  @customerid char(5),
  @orderdate  datetime
AS

INSERT INTO Orders(orderid, customerid, orderdate)
  VALUES(@orderid, @customerid, @orderdate)
GO

-- Listing 14-14: Creation Script for the usp_ OrdersInsert Stored Procedure, with Defaults Included
CREATE PROC dbo.usp_OrdersInsert
  @orderid    int,
  @customerid char(5) = 'ZZZZZ',
  @orderdate  datetime
AS

INSERT INTO Orders(orderid, customerid, orderdate)
  VALUES(@orderid, @customerid, @orderdate)
GO

-- Listing 14-15: Creation Script for the usp_ OrderDetailsInsert, usp_OrderDetailsUpdate, and usp_OrderDetailsDelete Stored Procedures
CREATE PROC dbo.usp_OrderDetailsInsert
  @orderid  int,
  @partid   int,
  @quantity int
AS

INSERT INTO OrderDetails(orderid, partid, quantity)
  VALUES(@orderid, @partid, @quantity)
GO

CREATE PROC dbo.usp_OrderDetailsUpdate
  @orderid    int,
  @partid     int,
  @neworderid int = NULL,
  @newpartid  int = NULL,
  @quantity   int = NULL
AS

UPDATE OrderDetails
  SET orderid = ISNULL(@neworderid, orderid),
      partid = ISNULL(@newpartid, partid),
      quantity = ISNULL(@quantity, quantity)
WHERE
    orderid = @orderid
  AND
    partid = @partid
GO

CREATE PROC dbo.usp_OrderDetailsDelete
  @orderid int,
  @partid  int
AS

DELETE FROM OrderDetails
WHERE
    orderid = @orderid
  AND
    partid = @partid
GO

-- Listing 14-16: Dropping the Foreign Keys
ALTER TABLE OrderDetails DROP CONSTRAINT FK_OrderDetails_Orders
GO
ALTER TABLE Employees DROP CONSTRAINT FK_Employees_Employees
GO

-- Listing 14-17: Creation Script for Trigger - trg_d_orders_on_delete_cascade
CREATE TRIGGER trg_d_orders_on_delete_cascade ON Orders FOR DELETE
AS

DELETE FROM OrderDetails
FROM
    OrderDetails AS OD
  JOIN
    deleted      AS D ON OD.orderid = D.orderid
GO

-- Listing 14-18: Testing the trg_d_orders_on_delete_cascade Trigger
DELETE FROM Orders
WHERE orderid = 10002

-- Listing 14-19: Testing a DELETE CASCADE Trigger on the Employees Table with Recursive Triggers Enabled
DELETE FROM Employees
WHERE empid = 7

-- Listing 14-20: Creation Script for Trigger - trg_d_employees_on_delete_cascade
CREATE TRIGGER trg_d_employees_on_delete_cascade ON Employees FOR DELETE
AS

IF EXISTS(SELECT *
          FROM
              Employees AS E
            JOIN
              deleted   AS D ON E.mgrid = D.empid)
  DELETE FROM Employees
  FROM
      Employees AS E
    JOIN
      deleted   AS D ON E.mgrid = D.empid
GO

-- Listing 14-21: Creation Script for the trg_d_orders_prevent_delete Trigger
CREATE TRIGGER trg_d_orders_prevent_delete ON Orders FOR DELETE
AS

IF EXISTS(SELECT *
          FROM
              OrderDetails AS OD
            JOIN
              deleted      AS D ON OD.orderid = D.orderid)
BEGIN 
  RAISERROR('The Orders you are trying to delete have related rows in OrderDetails.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
GO

-- Listing 14-22: Creation Script for the trg_d_employees_prevent_delete Trigger
CREATE TRIGGER trg_d_employees_prevent_delete ON Employees FOR DELETE 
AS

IF EXISTS(SELECT *
          FROM
              Employees AS E
            JOIN
              deleted   AS D ON E.mgrid = D.empid)
BEGIN 
  RAISERROR('The employees you are trying to delete have subordinates.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
GO

-- Listing 14-23: Creation Script for the  trg_u_orders_on_update_cascade Trigger
CREATE TRIGGER trg_u_orders_on_update_cascade ON Orders FOR UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount
IF UPDATE(orderid)
  IF @numrows = 1
    UPDATE OrderDetails
      SET orderid = (SELECT orderid FROM inserted)
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid = D.orderid
  ELSE IF @numrows > 1
  BEGIN
    RAISERROR('Updates to more than one row in Orders are not allowed.  TRANSACTION rolled back.', 10, 1)
    ROLLBACK TRANSACTION
  END
GO

-- Listing 14-24: Testing the trg_u_orders_on_update_cascade Trigger
UPDATE Orders
  SET orderid = 10004
WHERE orderid = 10002

-- Listing 14-25: Adding a Surrogate Key to the Orders Table
ALTER TABLE Orders
  ADD surrogate_key int NOT NULL IDENTITY(1,1)
      CONSTRAINT UNQ_orders_surrogate_key UNIQUE

-- Listing 14-26: Adding Multi-Row Support for the  trg_u_orders_on_update_cascade Trigger
ALTER TRIGGER trg_u_orders_on_update_cascade ON Orders FOR UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount
IF UPDATE(surrogate_key)
BEGIN
  RAISERROR('Updates to surrogate_key are not allowed.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
ELSE
  IF UPDATE(orderid) AND @numrows > 0
    UPDATE OrderDetails
      SET orderid = I.orderid
    FROM
        OrderDetails AS OD
      JOIN
        deleted      AS D ON OD.orderid      = D.orderid
      JOIN
        inserted     AS I ON D.surrogate_key = I.surrogate_key
GO

-- Listing 14-27: Testing the trg_u_orders_on_update_cascade Trigger with a Multi-Row Update
UPDATE Orders
  SET orderid = 20004 - orderid

-- Listing 14-28: Adding a Surrogate Key to the Employees Table
ALTER TABLE Employees
  ADD surrogate_key int NOT NULL IDENTITY(1,1)
      CONSTRAINT UNQ_employees_surrogate_key UNIQUE
GO

-- Listing 14-29: Creation Script for the trg_u_employees_on_update_cascade Trigger
CREATE TRIGGER trg_u_employees_on_update_cascade ON Employees FOR UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount
IF UPDATE(surrogate_key)
BEGIN
  RAISERROR('Updates to surrogate_key are not allowed.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
ELSE
  IF UPDATE(empid) AND @numrows > 0
    UPDATE Employees
      SET mgrid = I.empid
    FROM
        Employees AS E
      JOIN
        deleted   AS D ON E.mgrid         = D.empid
      JOIN
        inserted  AS I ON D.surrogate_key = I.surrogate_key
GO

-- Listing 14-30: Testing the trg_u_employees_on_update_cascade Trigger
UPDATE Employees
  SET empid = 15 - empid

-- Listing 14-31: Creation Script for the trg_u_orders_prevent_update Trigger
CREATE TRIGGER trg_u_orders_prevent_update ON Orders FOR UPDATE
AS

IF EXISTS(SELECT *
          FROM
              OrderDetails AS OD
            JOIN
              deleted      AS D ON OD.orderid = D.orderid)
BEGIN 
  RAISERROR('The Orders you are trying to update have related rows in OrderDetails.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
GO

-- Listing 14-32: Creation Script for the trg_u_employees_prevent_update Trigger
CREATE TRIGGER trg_u_employees_prevent_update ON Employees FOR UPDATE 
AS

IF EXISTS(SELECT *
          FROM
              Employees AS E
            JOIN
              deleted   AS D ON E.mgrid = D.empid)
BEGIN 
  RAISERROR('The employees you are trying to update have subordinates.  TRANSACTION rolled back.', 10, 1)
  ROLLBACK TRANSACTION
END
GO

-- Listing 14-33: Creation Script for the trg_iu_orderdetails_prevent_insupd Trigger
CREATE TRIGGER trg_iu_orderdetails_prevent_insupd ON OrderDetails FOR INSERT, UPDATE
AS

DECLARE @numrows int
SET @numrows = @@rowcount

IF UPDATE(orderid) AND @numrows > 0
  IF @numrows <> (SELECT COUNT(*)
                  FROM Orders AS O JOIN inserted AS I
                    ON O.orderid = I.orderid)
  BEGIN
    RAISERROR('Result rows in OrderDetails are orphaned. TRANSACTION rolled back.', 10, 1)
    ROLLBACK TRANSACTION
  END
GO

-- Listing 14-34: Creation Script for the trg_iu_employees_prevent_insupd Trigger
CREATE TRIGGER trg_iu_employees_prevent_insupd ON Employees FOR INSERT, UPDATE
AS

IF @@rowcount > 0 AND UPDATE(mgrid)
BEGIN
  DECLARE @numrows int

  SELECT
    @numrows = COUNT(*)
  FROM
    inserted
  WHERE
    mgrid IS NOT NULL

  IF @numrows <> (SELECT COUNT(*)
                  FROM Employees AS E JOIN inserted AS I
                    ON E.empid = I.mgrid)
  BEGIN
    RAISERROR('Result rows in Employees are orphaned. TRANSACTION rolled back.', 10, 1)
    ROLLBACK TRANSACTION
  END
END
GO

-- Listing 14-35: Invoking the sp_CreateRelationship Stored Procedure
EXEC sp_CreateRelationship
  @prmtbl        = Orders,
  @sectbl        = OrderDetails,
  @prmcol        = orderid,
  @seccol        = orderid,
  @deletecascade = 1,
  @updatecascade = 1

EXEC sp_CreateRelationship
  @prmtbl        = Employees,
  @sectbl        = Employees,
  @prmcol        = empid,
  @seccol        = mgrid,
  @deletecascade = 1,
  @updatecascade = 1

-- Listing 14-36: Creation Script for the trg_d_orders_on_delete_set_null Trigger
CREATE TRIGGER trg_d_orders_on_delete_set_null ON Orders FOR DELETE
AS

UPDATE OrderDetails
  SET orderid = NULL
FROM
    OrderDetails AS OD
  JOIN
    deleted      AS D ON OD.orderid = D.orderid
GO

-- Listing 14-37: Creation Script for the trg_d_orders_on_delete_set_default Trigger
CREATE TRIGGER trg_d_orders_on_delete_set_default ON Orders FOR DELETE
AS

UPDATE OrderDetails
  SET orderid = DEFAULT
FROM
    OrderDetails AS OD
  JOIN
    deleted      AS D ON OD.orderid = D.orderid
GO

-- Listing 14-38: Creation Script for the trg_d_orderdetails_on_delete_print_hello Trigger
CREATE TRIGGER trg_d_orderdetails_on_delete_print_hello ON OrderDetails  INSTEAD OF DELETE
AS

PRINT 'Hello from instead of delete trigger on OrderDetails'

-- resubmit the delete
DELETE FROM OrderDetails
FROM
    OrderDetails AS OD
  JOIN
    deleted AS D ON  OD.orderid = D.orderid
                 AND OD.partid  = D.partid
GO

-- Listing 14-39: Adding a Foreign Key to the OrderDetails Table with ON DELETE NO ACTION
ALTER TABLE OrderDetails ADD CONSTRAINT FK_OrderDetails_Orders
  FOREIGN KEY(orderid)
  REFERENCES Orders(orderid)
  ON DELETE NO ACTION
  ON UPDATE CASCADE
GO

-- Listing 14-40: Creation Script for the trg_d_orders_ON_DELETE_CASCADE Trigger
CREATE TRIGGER trg_d_orders_ON_DELETE_CASCADE ON Orders INSTEAD OF DELETE
AS

-- perform the delete cascade action
DELETE FROM OrderDetails
FROM
    OrderDetails AS OD
  JOIN
    deleted      AS D ON OD.orderid = D.orderid

-- resubmit the delete
DELETE FROM Orders
FROM
    Orders  AS O
  JOIN
    deleted AS D ON O.orderid = D.orderid
GO

-- Listing 14-41: Testing an UPDATE to See If the DRI UPDATE CASCADE Works
UPDATE Orders
  SET orderid = 10004
WHERE orderid = 10002

-- Listing 14-42: Testing the trg_d_orders_ON_DELETE_CASCADE Trigger
DELETE FROM Orders
WHERE orderid = 10002

Hello from instead of delete trigger on OrderDetails
