----------------------------------------------------------
-- Chapter 10 - Triggers - The Hidden Stored Procedures ==
----------------------------------------------------------


-- Listing 10-1: Syntax for the CREATE TRIGGER Statement
CREATE TRIGGER trigger_name 
ON { table | view } 
[ WITH ENCRYPTION ] 
{ 
  { { FOR | AFTER | INSTEAD OF } 
  { [ DELETE ] [ , ] [ INSERT ] [ , ] [ UPDATE ] } 
  [ WITH APPEND ] 
  [ NOT FOR REPLICATION ] 
AS 
  sql_statement [ ...n ] 
} 
| 
{ ( FOR | AFTER | INSTEAD OF ) { [ INSERT ] [ , ] [ UPDATE ] } 
  [ WITH APPEND ] 
  [ NOT FOR REPLICATION ] 
AS 
{ IF UPDATE ( column ) 
  [ { AND | OR } UPDATE ( column ) ] 
  [ ...n ] 
  | IF ( COLUMNS_UPDATED ( ) { bitwise_operator } updated_bitmask ) 
  { comparison_operator } column_bitmask [ ...n ] 
} 
  sql_statement [ ...n ] 
} 
} 

-- Listing 10-2: Sample CREATE TRIGGER Header
CREATE TRIGGER tri_Customers ON CUSTOMERS AFTER UPDATE
AS

-- Listing 10-3: Modifying a Trigger in a Transaction
BEGIN TRAN
ALTER TRIGGER tri_MyTable ON MyTable AFTER INSERT
AS
-- code goes here
GO

-- Listing 10-4: Syntax for the DROP TRIGGER Statement
DROP TRIGGER tri_MyTable

-- Listing 10-5: Cascaded Delete Using a Trigger
CREATE TRIGGER trd_Orders ON Orders AFTER DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

DELETE OD
FROM
    deleted         AS D
  JOIN
    [Order Details] AS OD ON OD.OrderID = D.OrderID
GO

-- Listing 10-6: Example of Enabling Cascaded Deletes through DRI
CREATE TABLE NewOrderDetails
(
  OrderID   int     NOT NULL
                    CONSTRAINT FK1_NewOrderDetails REFERENCES Orders (OrderID)
                      ON DELETE CASCADE,
  ProductID int     NOT NULL
                    CONSTRAINT FK2_NewOrderDetails REFERENCES Products (ProductID)
                      ON DELETE NO ACTION,
 Quantity  smallint NOT NULL,
                    CONSTRAINT PK_NewOrderDetails PRIMARY KEY (OrderID, ProductID),
)

-- Listing 10-7: Syntax for sp_settriggerorder
sp_settriggerorder [@triggername = ] 'triggername' 
    , [@order = ] 'value' 
    , [@stmttype = ] 'statement_type' 

-- Listing 10-8: Testing for Rows Affected in a Trigger
IF @@ROWCOUNT = 0
  RETURN

-- Listing 10-9: Using IF UPDATE() in a Trigger
CREATE TRIGGER tru_Products ON PRODUCTS FOR UPDATE
AS
IF @@ROWCOUNT = 0
  RETURN

IF UPDATE (UnitsInStock) OR UPDATE (ReorderLevel)
BEGIN
  IF EXISTS (SELECT * FROM inserted WHERE UnitsInStock < ReorderLevel)
  BEGIN
    -- take appropriate action here
  END
END
GO

-- Listing 10-10: Using IF COLUMNS_UPDATED() to Test for Updates to Columns 2, 3, and 5
IF COLUMNS_UPDATED () & 22 = 22

-- Listing 10-11: Using IF COLUMNS_UPDATED() for Testing Updates on Columns 7 and 9
CREATE TRIGGER truProducts ON PRODUCTS FOR UPDATE
AS
IF @@ROWCOUNT = 0
  RETURN

IF SUBSTRING (COLUMNS_UPDATED (), 1, 1) & 64 = 64
  OR SUBSTRING (COLUMNS_UPDATED(), 2, 1) = 1
BEGIN
  IF EXISTS (SELECT * FROM inserted WHERE UnitsInStock < ReorderLevel)
  BEGIN
    -- take appropriate action here
  END
END
GO

-- Listing 10-12: Sample Code for Disabling a Constraint
ALTER TABLE MyTable NOCHECK CONSTRAINT FK1_MyTable

-- Listing 10-13: Sample Code to Disable a Trigger
ALTER TABLE MyTable DISABLE TRIGGER tri_MyTable

-- Listing 10-14: Disabling a Constraint to Permit a FOREIGN KEY Violation
CREATE TABLE InventoryItems
(
  ItemID     int NOT NULL
                 IDENTITY (1, 1)
                 CONSTRAINT PK_InventoryItems  PRIMARY KEY,
  ProductID  int NOT NULL
                 CONSTRAINT FK1_InventoryItems
                   REFERENCES Product (ProductID),
  CustomerID int NOT NULL
                 CONSTRAINT FK2_InventoryItems
                   REFERENCES Customer (CustomerID)
)
GO

ALTER TABLE InventoryItem NOCHECK CONSTRAINT FK2_InventoryItems
GO

INSERT InventoryItems (ProductID, CustomerID) VALUES (1, 0)
INSERT InventoryItems (ProductID, CustomerID) VALUES (1, 0)
INSERT InventoryItems (ProductID, CustomerID) VALUES (1, 0)
INSERT InventoryItems (ProductID, CustomerID) VALUES (2, 0)
INSERT InventoryItems (ProductID, CustomerID) VALUES (2, 0)
GO

ALTER TABLE InventoryItems CHECK CONSTRAINT FK2_InventoryItems
GO

-- Listing 10-15: Table Creation Scripts for Raw and Summary Tables
CREATE TABLE Raw
(
  ID      int       NOT NULL IDENTITY,
  RawData char (10) NOT NULL
)
GO

CREATE TABLE Summary
(
  ID        int       NOT NULL IDENTITY,
  TotalRows int       NOT NULL
)
GO

CREATE TRIGGER tri_Raw on Raw AFTER INSERT
AS

INSERT Summary (TotalRows) VALUES (@@ROWCOUNT)
GO

-- Listing 10-16: Testing a Trigger on a Table with an Identity Property
INSERT Raw
(
  RawData
)
SELECT
  'First'
FROM
  sysobjects
WHERE
  type = 'U'

SELECT
  @@IDENTITY                 AS 'IDENTITY',
  SCOPE_IDENTITY ()          AS 'SCOPE IDENTITY',
  IDENT_CURRENT ('Summary')  AS 'Summary',
  IDENT_CURRENT ('Raw')      AS 'Raw'

INSERT Raw
(
  RawData
)
SELECT
  'Second'
FROM
  sysobjects
WHERE
  type = 'S'

SELECT
  @@IDENTITY                 AS 'IDENTITY',
  SCOPE_IDENTITY ()          AS 'SCOPE IDENTITY',
  IDENT_CURRENT ('Summary')  AS 'Summary',
  IDENT_CURRENT ('Raw')      AS 'Raw'

-- Listing 10-17: Using an AFTER Trigger to Remove Time from a datetime Column
CREATE TABLE DateTable
(
  ID        int       NOT NULL IDENTITY (1, 1)
                      PRIMARY KEY,
  Txt       char (10) NOT NULL,
  EntryDate datetime  NOT NULL
)
GO

CREATE TRIGGER triu_DateTable ON DateTable AFTER INSERT, UPDATE
AS

IF @@ROWCOUNT = 0
  RETURN

IF UPDATE (EntryDate)
  UPDATE D
  SET
    EntryDate = CONVERT (char (10), I.EntryDate, 112)
  FROM
      inserted  I
    JOIN
      DateTable D ON D.ID = I.ID
GO

-- Listing 10-18. Table Creation Script for Parent, Child, and Grandchild
CREATE TABLE Parent
(
  ID int NOT NULL PRIMARY KEY
)
GO

CREATE TABLE Child
(
  ID int NOT NULL PRIMARY KEY
                  REFERENCES Parent (ID)
                  ON DELETE CASCADE
)
GO

CREATE TABLE GrandChild
(
  ID int NOT NULL PRIMARY KEY
                  REFERENCES Child (ID)
                  ON DELETE CASCADE
)
GO

INSERT Parent VALUES (1)
INSERT Parent VALUES (2)
INSERT Parent VALUES (3)
INSERT Parent VALUES (4)
GO

INSERT Child VALUES (1)
INSERT Child VALUES (2)
INSERT Child VALUES (3)
INSERT Child VALUES (4)
GO

INSERT GrandChild VALUES (1)
INSERT GrandChild VALUES (2)
INSERT GrandChild VALUES (3)
INSERT GrandChild VALUES (4)
GO

-- Listing 10-19: Trigger Scripts for Cascading DELETEs
CREATE TRIGGER trd_Parent ON Parent AFTER DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside Parent trigger.'
GO

CREATE TRIGGER trd_Child ON Child AFTER DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside Child trigger.'
GO

CREATE TRIGGER trd_GrandChild ON GrandChild AFTER DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside GrandChild trigger.'
GO

-- Listing 10-20: Firing the Cascaded DELETE
DELETE Parent
WHERE
  ID BETWEEN 2 AND 3

-- Listing 10-21. Table Creation Script for Parent and Child with FOREIGN KEY Constraint and INSTEAD OF Trigger
CREATE TABLE Parent
(
  ID int NOT NULL PRIMARY KEY
)
GO

CREATE TABLE Child
(
  ID int NOT NULL PRIMARY KEY
                  REFERENCES Parent (ID)
                  ON DELETE CASCADE
)
GO

CREATE TRIGGER trd_Parent ON Parent INSTEAD OF DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside Parent trigger.'
GO

INSERT Parent VALUES (1)
INSERT Parent VALUES (2)
INSERT Parent VALUES (3)
INSERT Parent VALUES (4)
GO

INSERT Child VALUES (1)
INSERT Child VALUES (2)
INSERT Child VALUES (3)
INSERT Child VALUES (4)
GO

-- Listing 10-22: INSTEAD OF Trigger That Duplicates DELETE Action
ALTER TRIGGER trd_Parent ON Parent INSTEAD OF DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside Parent trigger.'

DELETE P
FROM
    Parent P
  JOIN
    deleted D ON D.ID = P.ID
GO

-- Listing 10-23: AFTER Trigger on Child Table
CREATE TRIGGER trd_Child ON Child AFTER DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

PRINT 'Inside Child trigger.'
GO

-- Listing 10-24: Table for INSTEAD OF Trigger for Logical Deletes
CREATE TABLE MyTable
(
  ID  int      NOT NULL PRIMARY KEY,
  del char (1) NOT NULL DEFAULT 'N'
)

-- Listing 10-25: INSTEAD OF Trigger for Logical Deletes
CREATE TRIGGER trd_MyTable ON MyTable INSTEAD OF DELETE
AS

IF @@ROWCOUNT = 0
  RETURN

UPDATE M
SET
  del = 'Y'
FROM
    MyTable AS M
  JOIN
    deleted AS D ON D.ID = M.ID
GO

-- Listing 10-26: Sample Tables and a View for Vertical Partitioning
CREATE TABLE First
(
  ID  int     NOT NULL PRIMARY KEY,
  xyz tinyint NOT NULL
)

CREATE TABLE Second
(
  ID  int     NOT NULL PRIMARY KEY
                       REFERENCES First (id),
  abc int     NOT NULL
)
GO

CREATE VIEW Whole
AS
  SELECT
    F.ID,
    F.xyz,
    S.abc
  FROM
      First  AS F
    JOIN
      Second AS S ON S.ID = F.ID
GO

-- Listing 10-27: INSTEAD OF Trigger to Support Vertical Partitioning
CREATE TRIGGER tri_Whole ON Whole INSTEAD OF INSERT
AS

IF @@ROWCOUNT = 0
  RETURN

INSERT First
SELECT
  ID,
  xyz
FROM
    inserted

INSERT Second
SELECT
  ID,
  abc
FROM
    inserted
GO

-- Listing 10-28: Using an INSTEAD OF Trigger to Handle a Data Feed
CREATE TABLE FeedTarget
(
  ID    int      NOT NULL PRIMARY KEY,
  Descr char (5) NOT NULL
)
GO

CREATE TRIGGER tri_FeedTarget ON FeedTarget INSTEAD OF INSERT
AS

IF @@ROWCOUNT = 0
  RETURN

UPDATE F             -- rows that already exist
SET
  Descr = I.Descr
FROM
    inserted   AS I
  JOIN
    FeedTarget AS F ON F.ID = I.ID

INSERT FeedTarget    -- new rows
SELECT
  ID,
  Descr
FROM
    inserted AS I
WHERE NOT EXISTS
(
  SELECT
    *
  FROM
      FeedTarget AS F
  WHERE
      F.ID = I.ID
)
GO

-- Listing 10-29: Test Script for the FeedTarget Table???
INSERT FeedTarget (ID, Descr) VALUES (1, 'a')
INSERT FeedTarget (ID, Descr) VALUES (2, 'b')
INSERT FeedTarget (ID, Descr) VALUES (3, 'c')
INSERT FeedTarget (ID, Descr) VALUES (1, 'd')
INSERT FeedTarget (ID, Descr) VALUES (1, 'e')

-- Listing 10-30: UPDATE/DELETE Trigger for Single-Row Audit
CREATE TRIGGER trud_AuditOrders ON Orders AFTER UPDATE, DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

-- clear out existing audit data for these OrderIDs
DELETE s
FROM
    deleted       AS D
  JOIN
    Orders_Shadow AS S ON S.OrderID = D.OrderID

-- add before image of rows
INSERT Orders_Shadow
(
  OrderID,
  CustomerID,
  EmployeeID,
  OrderDate,
  RequiredDate,
  ShippedDate,
  ShipVia,
  Freight,
  ShipName,
  ShipAddress,
  ShipCity,
  ShipRegion,
  ShipPostalCode,
  ShipCountry
)
SELECT
  OrderID,
  CustomerID,
  EmployeeID,
  OrderDate,
  RequiredDate,
  ShippedDate,
  ShipVia,
  Freight,
  ShipName,
  ShipAddress,
  ShipCity,
  ShipRegion,
  ShipPostalCode,
  ShipCountry
FROM
    deleted
GO

-- Listing 10-31: Update/Delete Trigger for Multi-Row Audit
CREATE TRIGGER trud_AuditOrders ON Orders AFTER UPDATE, DELETE
AS
IF @@ROWCOUNT = 0
  RETURN

-- add before image of rows
INSERT Orders_Shadow
(
  OrderID,
  CustomerID,
  EmployeeID,
  OrderDate,
  RequiredDate,
  ShippedDate,
  ShipVia,
  Freight,
  ShipName,
  ShipAddress,
  ShipCity,
  ShipRegion,
  ShipPostalCode,
  ShipCountry
)
SELECT
  OrderID,
  CustomerID,
  EmployeeID,
  OrderDate,
  RequiredDate,
  ShippedDate,
  ShipVia,
  Freight,
  ShipName,
  ShipAddress,
  ShipCity,
  ShipRegion,
  ShipPostalCode,
  ShipCountry
FROM
    deleted
GO

-- Listing 10-32: Trigger to Manage Last Update Auditing Information
CREATE TRIGGER triu_MyTable ON MyTable FOR INSERT, UPDATE
AS
IF @@ROWCOUNT = 0
  RETURN

UPDATE m
SET
  LastUpdateDate = GETDATE (),
  LastUpdateUser = SUSER_SNAME ()
FROM
    inserted AS I
  JOIN
    MyTable  AS M ON M.PK_ID = I.PK_ID
GO

-- SQL Puzzle
CREATE TABLE Customers
(
  CustomerID   int          NOT NULL
                            IDENTITY (1, 1)
                            PRIMARY KEY,
  CustomerName varchar (30) NOT NULL,
  Address      varchar (50) NOT NULL,
  Phone        varchar (12) NOT NULL,
  EmployeeID   sysname      NOT NULL
)
GO

CREATE TABLE PendingDeleteCustomers
(
  CustomerID   int          NOT NULL
                            PRIMARY KEY,
  CustomerName varchar (30) NOT NULL,
  Address      varchar (50) NOT NULL,
  Phone        varchar (12) NOT NULL,
  EmployeeID   sysname      NOT NULL
)
GO

